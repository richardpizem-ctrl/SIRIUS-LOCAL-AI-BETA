from runtime5.logging_5 import log5


class SystemHooks5:
    """
    Lightweight system hook layer for Runtime 5.x.
    Provides:
    - degraded mode notifications
    - recovery notifications
    - error notifications
    - integration point for future Self‑Repair Layer
    """

    @staticmethod
    def on_error(message: str):
        """
        Triggered whenever an error is recorded.
        """
        log5(f"[SystemHooks5] ERROR HOOK: {message}")

    @staticmethod
    def on_degraded():
        """
        Triggered when Runtime enters degraded mode.
        """
        log5("[SystemHooks5] ENTERING DEGRADED MODE")

    @staticmethod
    def on_recovery():
        """
        Triggered when Runtime exits degraded mode.
        """
        log5("[SystemHooks5] RECOVERY: Runtime back to normal state")
