import urllib.request
import urllib.error
import gzip
import io
import zlib
from runtime5.logging_5 import log5

# Optional brotli support
try:
    import brotli
except ImportError:
    brotli = None

# Optional Zstandard support
try:
    import zstandard as zstd
except ImportError:
    zstd = None


class EnvoyClient5:
    """
    ENVOY Client 5.x
    Safe external fetcher with:
    - timeout
    - gzip/deflate/brotli/zstd decompression
    - autodetection for missing headers
    - browser-like User-Agent to avoid Cloudflare fallback
    - sanitization
    - deterministic error handling
    """

    @staticmethod
    def fetch(url: str, timeout: int = 5) -> dict:
        log5(f"[EnvoyClient5] Fetching URL: {url}")

        try:
            # Browser-like UA to avoid Cloudflare fallback
            req = urllib.request.Request(
                url,
                headers={
                    "User-Agent":
                        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                        "AppleWebKit/537.36 (KHTML, like Gecko) "
                        "Chrome/124.0.0.0 Safari/537.36",
                    "Accept-Encoding": "gzip, deflate, br, zstd"
                }
            )

            with urllib.request.urlopen(req, timeout=timeout) as response:
                raw = response.read()
                headers = dict(response.headers)
                status = response.status

            if raw is None:
                raw = b""

            encoding = headers.get("Content-Encoding", "").lower()

            # --------------------------------------------------------
            # EXPLICIT DECOMPRESSION
            # --------------------------------------------------------

            # --- GZIP ---
            if encoding == "gzip":
                try:
                    raw = gzip.decompress(raw)
                    log5("[EnvoyClient5] GZIP decompression OK")
                except Exception as e:
                    log5(f"[EnvoyClient5] GZIP decompression FAILED: {e}")

            # --- DEFLATE ---
            elif encoding == "deflate":
                try:
                    raw = zlib.decompress(raw, -zlib.MAX_WBITS)
                    log5("[EnvoyClient5] DEFLATE decompression OK")
                except Exception as e:
                    log5(f"[EnvoyClient5] DEFLATE decompression FAILED: {e}")

            # --- BROTLI ---
            elif encoding == "br":
                if brotli:
                    try:
                        raw = brotli.decompress(raw)
                        log5("[EnvoyClient5] BROTLI decompression OK")
                    except Exception as e:
                        log5(f"[EnvoyClient5] BROTLI decompression FAILED: {e}")
                else:
                    log5("[EnvoyClient5] BROTLI detected but brotli module missing")

            # --- ZSTD ---
            elif encoding in ("zstd", "zst"):
                if zstd:
                    try:
                        dctx = zstd.ZstdDecompressor()
                        raw = dctx.decompress(raw)
                        log5("[EnvoyClient5] ZSTD decompression OK")
                    except Exception as e:
                        log5(f"[EnvoyClient5] ZSTD decompression FAILED: {e}")
                else:
                    log5("[EnvoyClient5] ZSTD detected but zstandard module missing")

            # --------------------------------------------------------
            # AUTODETECT (python.org often omits Content-Encoding)
            # --------------------------------------------------------

            # Try BROTLI autodetect
            if brotli:
                try:
                    raw_test = brotli.decompress(raw)
                    raw = raw_test
                    log5("[EnvoyClient5] BROTLI autodetect OK")
                except Exception:
                    pass

            # Try ZSTD autodetect
            if zstd:
                try:
                    dctx = zstd.ZstdDecompressor()
                    raw_test = dctx.decompress(raw)
                    raw = raw_test
                    log5("[EnvoyClient5] ZSTD autodetect OK")
                except Exception:
                    pass

            # Try DEFLATE autodetect
            try:
                raw_test = zlib.decompress(raw, -zlib.MAX_WBITS)
                raw = raw_test
                log5("[EnvoyClient5] DEFLATE autodetect OK")
            except Exception:
                pass

            # Try GZIP autodetect
            try:
                raw_test = gzip.decompress(raw)
                raw = raw_test
                log5("[EnvoyClient5] GZIP autodetect OK")
            except Exception:
                pass

            # --------------------------------------------------------
            # LOG RAW LENGTH
            # --------------------------------------------------------
            log5(f"[EnvoyClient5] RAW BYTES LENGTH: {len(raw)}")

            # Try decode text
            try:
                text = raw.decode("utf-8", errors="ignore")
            except Exception:
                text = None

            return {
                "status": "ok",
                "url": url,
                "status_code": status,
                "headers": headers,
                "content": raw[:5000],
                "text": text,
                "notes": "Fetched successfully (sanitized + decompressed)."
            }

        except urllib.error.HTTPError as e:
            return {"status": "http-error", "url": url, "code": e.code}

        except urllib.error.URLError as e:
            return {"status": "network-error", "url": url, "reason": str(e.reason)}

        except Exception as e:
            return {"status": "error", "url": url, "reason": str(e)}
