from runtime5.logging_5 import log5
from runtime5.kg_export_import_5 import KGExportImport5


class SystemHooks5:
    """
    Lightweight system hook layer for Runtime 5.x.
    Provides:
    - degraded mode notifications
    - recovery notifications
    - error notifications
    - autosave on shutdown
    """

    @staticmethod
    def on_error(message: str):
        """
        Triggered whenever an error is recorded.
        """
        log5(f"[SystemHooks5] ERROR HOOK: {message}")

    @staticmethod
    def on_degraded():
        """
        Triggered when Runtime enters degraded mode.
        """
        log5("[SystemHooks5] ENTERING DEGRADED MODE")

    @staticmethod
    def on_recovery():
        """
        Triggered when Runtime exits degraded mode.
        """
        log5("[SystemHooks5] RECOVERY: Runtime back to normal state")

    # --------------------------------------------------------
    # AUTOSAVE — called when Runtime shuts down
    # --------------------------------------------------------
    @staticmethod
    def on_shutdown(runtime):
        """
        Automatically saves the Knowledge Graph when Runtime shuts down.
        """
        try:
            filename = "autosave_kg.json"
            exporter = KGExportImport5(runtime.kg)
            result = exporter.export_to_file(filename)

            entities = result.get("entities", 0)
            relations = result.get("relations", 0)

            log5(
                f"[SystemHooks5] AUTOSAVE completed → {filename} "
                f"({entities} entities, {relations} relations)"
            )

        except Exception as e:
            log5(f"[SystemHooks5] AUTOSAVE ERROR: {e}")
