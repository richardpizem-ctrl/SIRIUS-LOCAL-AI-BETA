# runtime5/kg_search_5.py
# SIRIUS LOCAL AI – KG SEARCH 5.x
# Fulltext search across entity attributes and relations

from __future__ import annotations
from typing import List, Dict, Any
from runtime5.logging_5 import log5
from runtime5.error_handler_5 import ErrorHandler5


class KGSearch5:
    """
    Fulltext search engine for SIRIUS Knowledge Graph 5.x.
    Searches:
      - entity name
      - attributes (title, summary, content, ...)
      - relations (optional)
    Returns:
      - list of matches sorted by relevance score
    """

    def __init__(self, kg):
        self.kg = kg
        log5("[KGSearch5] Initialized KG SEARCH module.")

    # --------------------------------------------------------
    # PUBLIC API
    # --------------------------------------------------------
    def search(self, query: str) -> List[Dict[str, Any]]:
        return ErrorHandler5.safe_execute(
            lambda: self._search_internal(query),
            context=query,
            fallback=[]
        )

    # --------------------------------------------------------
    # INTERNAL
    # --------------------------------------------------------
    def _search_internal(self, query: str) -> List[Dict[str, Any]]:
        q = query.strip().lower()
        if not q:
            return []

        results = []

        # ----------------------------------------------------
        # Iterate over all entities
        # ----------------------------------------------------
        for key, entity in self.kg.entities.items():
            score = 0
            matches = []

            # -------------------------
            # 1) Match entity name
            # -------------------------
            if q in entity.name.lower():
                score += 5
                matches.append("name")

            # -------------------------
            # 2) Match attributes
            # -------------------------
            for attr_key, attr_val in (entity.attributes or {}).items():
                if not isinstance(attr_val, str):
                    continue

                if q in attr_val.lower():
                    score += 10
                    matches.append(f"attr:{attr_key}")

            # -------------------------
            # 3) Match relations (optional)
            # -------------------------
            for rel in self.kg.relations:
                if rel.source.lower() == key or rel.target.lower() == key:
                    if q in rel.relation.lower():
                        score += 2
                        matches.append(f"rel:{rel.relation}")

            # -------------------------
            # Save result if relevant
            # -------------------------
            if score > 0:
                results.append({
                    "entity": entity.name,
                    "score": score,
                    "matches": matches,
                    "attributes": entity.attributes,
                })

        # ----------------------------------------------------
        # Sort by score (descending)
        # ----------------------------------------------------
        results.sort(key=lambda x: x["score"], reverse=True)

        log5(f"[KGSearch5] Search '{query}' → {len(results)} results")
        return results
