# runtime5/kg_view_5.py

from runtime5.logging_5 import log5

class KGView5:
    """
    KG View 5.x
    Displays all entities stored in the Knowledge Graph.
    """

    @staticmethod
    def view_all(kg):
        """
        Returns a structured list of all KG entities.
        """
        try:
            entities = kg.get_all_entities()
        except Exception as e:
            log5(f"[KGView5] ERROR: {e}")
            return {"status": "error", "notes": "KG retrieval failed."}

        if not entities:
            return {"status": "empty", "notes": "Knowledge Graph is empty."}

        output = []
        for url, data in entities.items():
            title = data.get("title", "(no title)")
            summary = data.get("summary", "(no summary)")
            content = data.get("content", "(no content)")

            output.append({
                "url": url,
                "title": title,
                "summary": summary[:200],   # short preview
                "content_preview": content[:200]
            })

        log5("[KGView5] Displayed all KG entities")
        return {"status": "ok", "count": len(output), "entities": output}
