# runtime5/envoy_execution_layer_5.py

import requests
from runtime5.logging_5 import log5
from runtime5.error_handler_5 import ErrorHandler5
from runtime5.health_monitor_5 import HealthMonitor5


class EnvoyExecutionLayer5:
    """
    ENVOY EXECUTION LAYER 5.x
    - Performs safe HTTP GET
    - Normalizes output
    - Stores RAW only in quarantine/cache
    - Returns ONLY normalized data to workflow
    - Uses shared runtime components (NO NEW INSTANCES)
    """

    def __init__(self, runtime):
        # Shared runtime components
        self.runtime = runtime
        self.quarantine = runtime.quarantine
        self.permission = runtime.permission_layer
        self.normalizer = runtime.envoy_normalizer

        log5("[EnvoyExecutionLayer5] Initialized ENVOY Execution Layer 5.x (shared runtime)")

    # --------------------------------------------------------
    # MAIN EXECUTION
    # --------------------------------------------------------
    def execute(self, request: dict):
        url = request.get("entity")
        log5(f"[EnvoyExecutionLayer5] Executing ENVOY request: {url}")

        # -----------------------------------------------------
        # 1. PERMISSION CHECK (double-check)
        # -----------------------------------------------------
        decision = self.permission.check_url(url)

        if not decision.allowed:
            log5(f"[EnvoyExecutionLayer5] DENIED: {decision.reason}")
            return {
                "status": "envoy-denied",
                "error": decision.reason,
                "degraded": HealthMonitor5.is_degraded()
            }

        # -----------------------------------------------------
        # 2. SAFE HTTP GET
        # -----------------------------------------------------
        def _exec():
            log5(f"[EnvoyExecutionLayer5] Performing HTTP GET: {url}")
            response = requests.get(url, timeout=10)

            log5(f"[EnvoyExecutionLayer5] HTTP status: {response.status_code}")

            # RAW response (large data) — store ONLY in quarantine/cache
            raw_data = {
                "status_code": response.status_code,
                "headers": dict(response.headers),
                "content": response.content,
                "text": response.text,
            }

            # Store RAW in quarantine (safe storage, not workflow)
            self.quarantine.store_raw(url, raw_data)

            # -------------------------------------------------
            # 3. NORMALIZATION (small, safe)
            # -------------------------------------------------
            normalized = self.normalizer.normalize(raw_data)

            # Workflow dostane iba normalized
            return {
                "status": "envoy-success",
                "url": url,
                "normalized": normalized,
                "degraded": HealthMonitor5.is_degraded()
            }

        return ErrorHandler5.safe_execute(
            _exec,
            context={"url": url},
            fallback={
                "status": "envoy-error",
                "error": "ENVOY execution failed.",
                "degraded": HealthMonitor5.is_degraded()
            }
        )
