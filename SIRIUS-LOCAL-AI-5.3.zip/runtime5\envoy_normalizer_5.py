# runtime5/envoy_normalizer_5.py
# Modern ENVOY normalizer for Runtime 5.x
# Extracts text from HTML, JSON hydration, meta tags, fallback blocks
# Now includes LEVEL 1 (Metadata) output

import re
import json
import datetime
from bs4 import BeautifulSoup, Comment
from runtime5.logging_5 import log5

MAX_CONTENT = 20000


class EnvoyNormalizer5:
    """
    ENVOY Response Normalizer 5.x
    Modern HTML → text extractor.
    Handles:
      - classic HTML
      - React/SPA hydration JSON
      - inline JS text
      - meta descriptions
      - fallback <noscript>
      - LEVEL 1 metadata output
    """

    def __init__(self):
        log5("[EnvoyNormalizer5] Initialized normalizer 5.x")

    def normalize(self, response: dict) -> dict:
        log5("[EnvoyNormalizer5] Normalizing ENVOY response")

        if not response:
            return {"status": "error", "notes": "Empty response"}

        if response.get("status") != "ok":
            return {
                "status": response.get("status"),
                "url": response.get("url"),
                "notes": response.get("notes"),
                "title": None,
                "summary": None,
                "content": None,
                "level1": None
            }

        raw = response.get("content", b"")

        # Decode bytes → UTF‑8 text
        try:
            html = raw.decode("utf-8", errors="ignore")
        except Exception:
            html = str(raw)

        soup = BeautifulSoup(html, "html.parser")

        # --------------------------------------------------------
        # TITLE EXTRACTION
        # --------------------------------------------------------
        title = None

        if soup.title and soup.title.string:
            title = soup.title.string.strip()

        if not title:
            h1 = soup.find("h1")
            if h1:
                title = h1.get_text(strip=True)

        # --------------------------------------------------------
        # META DESCRIPTION
        # --------------------------------------------------------
        meta_desc = soup.find("meta", attrs={"name": "description"})
        if meta_desc and meta_desc.get("content"):
            meta_text = meta_desc["content"].strip()
        else:
            meta_text = ""

        # --------------------------------------------------------
        # OPEN GRAPH DESCRIPTION
        # --------------------------------------------------------
        og_desc = soup.find("meta", property="og:description")
        if og_desc and og_desc.get("content"):
            og_text = og_desc["content"].strip()
        else:
            og_text = ""

        # --------------------------------------------------------
        # NOSCRIPT FALLBACK
        # --------------------------------------------------------
        noscript_text = ""
        for ns in soup.find_all("noscript"):
            noscript_text += " " + ns.get_text(" ", strip=True)

        # --------------------------------------------------------
        # JSON HYDRATION EXTRACTION
        # --------------------------------------------------------
        hydration_text = ""

        for script in soup.find_all("script"):
            # JSON hydration blocks
            if script.get("type") in ("application/json", "application/ld+json"):
                try:
                    data = json.loads(script.string or "")
                    hydration_text += " " + self._extract_json_text(data)
                except Exception:
                    pass

            # Inline JS with text strings
            if script.string:
                matches = re.findall(r"['\"]([^'\"]{5,})['\"]", script.string)
                for m in matches:
                    hydration_text += " " + m

        # --------------------------------------------------------
        # REMOVE SCRIPT/STYLE TAGS (after extracting JSON)
        # --------------------------------------------------------
        for tag in soup(["script", "style"]):
            tag.decompose()

        # --------------------------------------------------------
        # REMOVE COMMENTS
        # --------------------------------------------------------
        for c in soup.find_all(string=lambda t: isinstance(t, Comment)):
            c.extract()

        # --------------------------------------------------------
        # CLASSIC TEXT EXTRACTION
        # --------------------------------------------------------
        classic_text = soup.get_text(" ", strip=True)
        classic_text = re.sub(r"\s+", " ", classic_text).strip()

        # --------------------------------------------------------
        # MERGE ALL SOURCES
        # --------------------------------------------------------
        full_text = " ".join([
            meta_text,
            og_text,
            noscript_text,
            hydration_text,
            classic_text
        ])

        full_text = re.sub(r"\s+", " ", full_text).strip()

        log5(f"[EnvoyNormalizer5] RAW TEXT LENGTH: {len(full_text)}")

        # Remove duplicated title
        if title and full_text.lower().startswith(title.lower()):
            full_text = full_text[len(title):].strip()

        # Final clean
        full_text = re.sub(r"\s+", " ", full_text).strip()

        log5(f"[EnvoyNormalizer5] CLEAN TEXT LENGTH: {len(full_text)}")

        # Summary + content
        summary = full_text[:300] if full_text else ""
        content = full_text[:MAX_CONTENT] if full_text else ""

        # --------------------------------------------------------
        # LEVEL 1 METADATA OBJECT
        # --------------------------------------------------------
        level1 = {
            "level": 1,
            "type": "web_metadata",
            "url": response.get("url"),
            "title": title,
            "summary": summary,
            "timestamp": datetime.datetime.utcnow().isoformat(),
            "source": "ENVOY",
            "meta": {
                "description": meta_text,
                "og_description": og_text,
                "language": soup.html.get("lang") if soup.html else None,
                "charset": soup.meta.get("charset") if soup.meta else None
            }
        }

        # --------------------------------------------------------
        # FINAL OUTPUT
        # --------------------------------------------------------
        return {
            "status": "ok",
            "url": response.get("url"),
            "type": "html",
            "title": title,
            "summary": summary,
            "content": content,
            "level1": level1,
            "notes": "Normalized HTML response (modern extractor + Level 1 metadata)."
        }

    # --------------------------------------------------------
    # JSON TEXT EXTRACTOR (recursive)
    # --------------------------------------------------------
    def _extract_json_text(self, obj):
        text = ""

        if isinstance(obj, dict):
            for v in obj.values():
                text += " " + self._extract_json_text(v)

        elif isinstance(obj, list):
            for item in obj:
                text += " " + self._extract_json_text(item)

        elif isinstance(obj, str):
            if len(obj) > 5:
                text += " " + obj

        return text.strip()
