# runtime5_cli.py
# SIRIUS LOCAL AI – Runtime 5.3 Command Line Interface
# Clean, deterministic, ENVOY Approval Pipeline

from __future__ import annotations
import sys
import os
import json
import time
import base64

from runtime5.runtime_core import RuntimeCore
from runtime5.runtime_config import RuntimeConfig
from runtime5.health_monitor_5 import HealthMonitor5
from runtime5.repair_core import RepairCore
from runtime5.logging_5 import log5


# --------------------------------------------------------
# COLOR CODES
# --------------------------------------------------------
class Color:
    RESET = "\033[0m"
    RED = "\033[91m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    CYAN = "\033[96m"
    MAGENTA = "\033[95m"
    BLUE = "\033[94m"


class Runtime5CLI:
    """
    SIRIUS LOCAL AI — Command Line Interface (Runtime 5.3)
    """

    def __init__(self):
        self.logger = log5
        self.config = RuntimeConfig()

        # Create core runtime
        self.health_monitor = HealthMonitor5
        self.runtime = RuntimeCore()

        # Inject components manually
        self.runtime.health = self.health_monitor
        self.runtime.logger = self.logger

        # Workflow engine
        self.workflow_engine = self.runtime.workflow

        # System Agent – použijeme ten, ktorý už vytvoril RuntimeCore
        self.system_agent = self.runtime.system_agent

        self.repair_core = RepairCore(logger=self.logger)

        self.logger("[Runtime5CLI] Initialized (v5.3.0)")

    # --------------------------------------------------------
    # MAIN ENTRY
    # --------------------------------------------------------
    def run_interactive(self):
        """
        Always interactive mode.
        """
        print(f"{Color.CYAN}Runtime5 CLI ready.{Color.RESET}")

        while True:
            try:
                user_input = input(f"{Color.CYAN}>>> {Color.RESET}").strip()
            except (EOFError, KeyboardInterrupt):
                print("\nExiting Runtime5 CLI.")
                try:
                    self.runtime.shutdown()
                except Exception as e:
                    print(f"Shutdown error: {e}")
                break

            if user_input.lower() in ("exit", "quit"):
                print("Exiting Runtime5 CLI.")
                try:
                    self.runtime.shutdown()
                except Exception as e:
                    print(f"Shutdown error: {e}")
                break

            self._handle_command(user_input)

    def _handle_command(self, user_input):

        # --------------------------------------------------------
        # POLICY RELOAD
        # --------------------------------------------------------
        if user_input.lower() == "policy-reload":
            self.runtime.permission_layer.policy_engine.load()
            self._print_result({"status": "ok", "notes": "Policies reloaded."})
            return

        # --------------------------------------------------------
        # POLICY TEST <URL>
        # --------------------------------------------------------
        if user_input.lower().startswith("policy-test "):
            url = user_input[12:].strip()
            result = self.runtime.permission_layer.policy_engine.evaluate(url)
            self._print_result(result)
            return

        # --------------------------------------------------------
        # ENVOY EXECUTE (APPROVED ONLY)
        # --------------------------------------------------------
        if user_input.lower() == "envoy-exec":
            result = self.system_agent.envoy_execute_next()
            self._print_result(result)
            return

        # --------------------------------------------------------
        # ENVOY HISTORY
        # --------------------------------------------------------
        if user_input.lower() == "envoy-history":
            hist = self.system_agent.envoy_history()
            print("--------------------------------------------------")
            if not hist:
                print(f"{Color.YELLOW}No ENVOY history.{Color.RESET}")
            else:
                print(f"{Color.CYAN}ENVOY Execution History:{Color.RESET}")
                for item in hist:
                    ts = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(item["timestamp"]))
                    print(f" - {item['url']} | {item['type']} | {item['length']} bytes | {ts}")
            print("--------------------------------------------------")
            return

        # --------------------------------------------------------
        # ENVOY HISTORY CLEAR
        # --------------------------------------------------------
        if user_input.lower() == "envoy-history-clear":
            result = self.system_agent.envoy_history_clear()
            self._print_result(result)
            return

        # --------------------------------------------------------
        # ENVOY PENDING
        # --------------------------------------------------------
        if user_input.lower() == "envoy-pending":
            pending = self.system_agent.envoy_pending()
            print("--------------------------------------------------")
            if not pending:
                print(f"{Color.YELLOW}No pending ENVOY requests.{Color.RESET}")
            else:
                print(f"{Color.CYAN}Pending ENVOY requests:{Color.RESET}")
                for item in pending:
                    print(" -", item.get("entity"))
            print("--------------------------------------------------")
            return

        # --------------------------------------------------------
        # ENVOY APPROVED
        # --------------------------------------------------------
        if user_input.lower() == "envoy-approved":
            approved = self.system_agent.envoy_approved()
            print("--------------------------------------------------")
            if not approved:
                print(f"{Color.YELLOW}No approved ENVOY requests.{Color.RESET}")
            else:
                print(f"{Color.GREEN}Approved ENVOY requests:{Color.RESET}")
                for item in approved:
                    print(" -", item.get("entity"))
            print("--------------------------------------------------")
            return

        # --------------------------------------------------------
        # ENVOY REJECTED
        # --------------------------------------------------------
        if user_input.lower() == "envoy-rejected":
            rejected = self.system_agent.envoy_rejected()
            print("--------------------------------------------------")
            if not rejected:
                print(f"{Color.YELLOW}No rejected ENVOY requests.{Color.RESET}")
            else:
                print(f"{Color.RED}Rejected ENVOY requests:{Color.RESET}")
                for item in rejected:
                    print(" -", item.get("entity"))
            print("--------------------------------------------------")
            return

        # --------------------------------------------------------
        # ENVOY APPROVE <URL>
        # --------------------------------------------------------
        if user_input.lower().startswith("envoy-approve "):
            url = user_input[14:].strip()
            result = self.system_agent.envoy_approve(url)
            self._print_result(result)
            return

        # --------------------------------------------------------
        # ENVOY REJECT <URL>
        # --------------------------------------------------------
        if user_input.lower().startswith("envoy-reject "):
            url = user_input[13:].strip()
            result = self.system_agent.envoy_reject(url)
            self._print_result(result)
            return

        # --------------------------------------------------------
        # KG EXPORT <filename>
        # --------------------------------------------------------
        if user_input.lower().startswith("kg export "):
            from runtime5.kg_export_import_5 import KGExportImport5

            filename = user_input[10:].strip()
            if not filename:
                self._print_result({"status": "error", "error": "Missing filename."})
                return

            exporter = KGExportImport5(self.runtime.kg)
            result = exporter.export_to_file(filename)

            self._print_result(result)
            return

        # --------------------------------------------------------
        # KG IMPORT <filename>
        # --------------------------------------------------------
        if user_input.lower().startswith("kg import "):
            from runtime5.kg_export_import_5 import KGExportImport5

            filename = user_input[10:].strip()
            if not filename:
                self._print_result({"status": "error", "error": "Missing filename."})
                return

            importer = KGExportImport5(self.runtime.kg)
            result = importer.import_from_file(filename)

            self._print_result(result)
            return

        # --------------------------------------------------------
        # KG VIEW ALL  (must be BEFORE single view)
        # --------------------------------------------------------
        if user_input.lower().strip() == "kg view all":
            from runtime5.kg_view_5 import KGView5

            viewer = KGView5(self.runtime.kg)
            result = viewer.view_all(self.runtime.kg)

            print("--------------------------------------------------")
            print(json.dumps(result, indent=2, ensure_ascii=False))
            print("--------------------------------------------------")
            return

        # --------------------------------------------------------
        # KG VIEW (single entity)
        # --------------------------------------------------------
        if user_input.lower().startswith("kg view "):
            from runtime5.kg_view_5 import KGView5

            raw = user_input[7:].strip()
            if raw.startswith('"') and raw.endswith('"'):
                raw = raw[1:-1]

            viewer = KGView5(self.runtime.kg)
            result = viewer.view(raw)

            print("--------------------------------------------------")
            print(json.dumps(result, indent=2, ensure_ascii=False))
            print("--------------------------------------------------")
            return

        # --------------------------------------------------------
        # NORMAL RUNTIME PROCESSING
        # --------------------------------------------------------
        result = self.runtime.process({"input": user_input})
        self._print_result(result)

    # --------------------------------------------------------
    # HELPERS
    # --------------------------------------------------------
    def _print_result(self, result):
        print("--------------------------------------------------")
        print(f"{Color.BLUE}{result}{Color.RESET}")
        print("--------------------------------------------------")


if __name__ == "__main__":
    cli = Runtime5CLI()
    cli.run_interactive()
