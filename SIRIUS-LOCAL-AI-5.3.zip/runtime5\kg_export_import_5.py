# SIRIUS LOCAL AI — KG Export/Import Module 5.x (FIXED)

import json
from datetime import datetime

class KGExportImport5:
    def __init__(self, kg):
        self.kg = kg

    # --------------------------------------------------------
    # EXPORT KG → JSON
    # --------------------------------------------------------
    def export_to_file(self, filename: str):
        data = {
            "version": "5.x",
            "timestamp": datetime.utcnow().isoformat(),
            "entities": {},
            "relations": []
        }

        # Serialize entities
        for key, entity in self.kg.entities.items():
            data["entities"][key] = {
                "name": entity.name,
                "attributes": entity.attributes
            }

        # Serialize relations
        for rel in self.kg.relations:
            data["relations"].append({
                "source": rel.source,
                "relation": rel.relation,
                "target": rel.target
            })

        with open(filename, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

        return {
            "status": "ok",
            "exported_to": filename,
            "entities": len(self.kg.entities),
            "relations": len(self.kg.relations)
        }

    # --------------------------------------------------------
    # IMPORT KG ← JSON
    # --------------------------------------------------------
    def import_from_file(self, filename: str):
        try:
            with open(filename, "r", encoding="utf-8") as f:
                data = json.load(f)
        except FileNotFoundError:
            return {"status": "error", "error": f"File not found: {filename}"}
        except json.JSONDecodeError:
            return {"status": "error", "error": "Invalid JSON format."}

        # Clear current KG
        self.kg.entities.clear()
        self.kg.relations.clear()

        # Load entities
        for key, ent in data.get("entities", {}).items():
            self.kg.add_entity(
                name=key,
                attributes=ent.get("attributes", {})
            )

        # Load relations
        for rel in data.get("relations", []):
            self.kg.add_relation(
                rel["source"],
                rel["relation"],
                rel["target"]
            )

        loaded_entities = len(self.kg.entities)
        loaded_relations = len(self.kg.relations)

        return {
            "status": "ok",
            "loaded_entities": loaded_entities,
            "loaded_relations": loaded_relations,
            "current_entities": loaded_entities,
            "current_relations": loaded_relations,
            "file": filename
        }
