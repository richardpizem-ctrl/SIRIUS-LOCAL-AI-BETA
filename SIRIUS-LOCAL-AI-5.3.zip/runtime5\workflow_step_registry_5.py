# runtime5/workflow_step_registry_5.py

from runtime5.logging_5 import log5
from runtime5.workflow_steps_5 import WorkflowStepContinue5, EnvoyStepLevel1


class WorkflowStepRegistry5:
    """
    Central registry for workflow steps in Runtime 5.x
    """

    _steps = {}

    @classmethod
    def register(cls, name: str, step):
        cls._steps[name] = step
        log5(f"[WorkflowStepRegistry5] Registered step: {name}")

    @classmethod
    def get_step(cls, name: str):
        return cls._steps.get(name)

    @classmethod
    def init_defaults(cls):
        """
        Register core workflow steps.
        ENVOY steps are registered in WorkflowEngine5.
        """

        # 1) Default fallback step
        cls.register("WORKFLOW_CONTINUE", WorkflowStepContinue5())

        # 2) Level‑1 → KG store step
        cls.register("ENVOY_LEVEL1", EnvoyStepLevel1())

        log5("[WorkflowStepRegistry5] Default steps initialized")
