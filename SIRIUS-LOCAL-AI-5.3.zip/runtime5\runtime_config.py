# runtime5/runtime_config.py

class RuntimeConfig:
    """
    Lightweight configuration holder for Runtime 5.x.
    Provides:
    - default settings
    - toggles for degraded mode
    - developer flags
    """

    DEBUG = False
    ENABLE_SELF_REPAIR = True
    ENABLE_HEALTH_MONITOR = True
    ENABLE_WORKFLOW_LOGGING = True
    ENABLE_REASONING_LOGGING = True

    @staticmethod
    def load():
        """
        Placeholder for future config loading.
        Currently returns static defaults.
        """
        return {
            "debug": RuntimeConfig.DEBUG,
            "self_repair": RuntimeConfig.ENABLE_SELF_REPAIR,
            "health_monitor": RuntimeConfig.ENABLE_HEALTH_MONITOR,
            "workflow_logging": RuntimeConfig.ENABLE_WORKFLOW_LOGGING,
            "reasoning_logging": RuntimeConfig.ENABLE_REASONING_LOGGING,
        }
