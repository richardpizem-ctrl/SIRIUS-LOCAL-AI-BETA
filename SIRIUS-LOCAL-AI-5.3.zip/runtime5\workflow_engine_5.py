# runtime5/workflow_engine_5.py

from runtime5.workflow_step_registry_5 import WorkflowStepRegistry5
from runtime5.logging_5 import log5
from runtime5.health_monitor_5 import HealthMonitor5
from runtime5.system_hooks_5 import SystemHooks5
from runtime5.error_handler_5 import ErrorHandler5

# ENVOY steps
from runtime5.envoy_step_execute_5 import EnvoyStepExecute5
from runtime5.envoy_step_fetch_5 import EnvoyStepFetch5

# SYSTEM ACTION step (NEW)
from runtime5.workflow_step_system_action_5 import WorkflowStepSystemAction5


class WorkflowEngine5:
    """
    Workflow Engine 5.x
    """

    def __init__(self, runtime):
        # Shared runtime
        self.runtime = runtime
        self.quarantine = runtime.quarantine

        # Registry is unique per workflow engine
        self.registry = WorkflowStepRegistry5()

        # Register default steps
        self.registry.init_defaults()

        # Register ENVOY steps using shared runtime
        self.registry.register("ENVOY_FETCH", EnvoyStepFetch5(self.runtime))
        self.registry.register("ENVOY_EXECUTE", EnvoyStepExecute5(self.runtime))

        # SYSTEM_ACTION sa zaregistruje neskôr (keď už existuje system_agent)
        self.system_action_registered = False

        log5("[WorkflowEngine5] Initialized Workflow Engine 5.x")

    # --------------------------------------------------------
    # INTERNAL: ensure SYSTEM_ACTION exists
    # --------------------------------------------------------
    def _ensure_system_action(self):
        if not self.system_action_registered and hasattr(self.runtime, "system_agent"):
            self.registry.register("SYSTEM_ACTION", WorkflowStepSystemAction5(self.runtime))
            self.system_action_registered = True
            log5("[WorkflowEngine5] SYSTEM_ACTION registered")

    # --------------------------------------------------------
    # EXECUTION
    # --------------------------------------------------------
    def execute(self, reasoning_output: dict):
        log5("[WorkflowEngine5] Executing workflow step...")

        # ensure SYSTEM_ACTION exists
        self._ensure_system_action()

        def _exec():
            route = reasoning_output.get("route")
            mode = reasoning_output.get("mode")
            intent = reasoning_output.get("intent")

            # KG reasoning
            if route == "KG_REASONING":
                action = "RETURN_CONTEXT"

            # KG relations → SystemAgent
            elif route in ("KG_RELATE", "KG_RELATIONS"):
                action = "SYSTEM_ACTION"

            # ENVOY pipeline
            elif route == "ENVOY":

                if mode == "LEVEL1":
                    decision = self.runtime.permission_layer.policy_engine.evaluate(
                        reasoning_output.get("url")
                    )

                    log5(f"[WorkflowEngine5] Permission decision: {decision}")

                    if decision.get("decision") == "allow":
                        self.runtime.system_agent.envoy_approve(reasoning_output.get("url"))
                        return {
                            "action": "ENVOY_LEVEL1",
                            "status": "approved",
                            "notes": "URL approved automatically.",
                            "degraded": HealthMonitor5.is_degraded()
                        }

                    if decision.get("decision") == "manual":
                        self.runtime.system_agent.envoy_pending_add(reasoning_output.get("url"))
                        return {
                            "action": "ENVOY_LEVEL1",
                            "status": "pending",
                            "notes": "URL requires manual approval.",
                            "degraded": HealthMonitor5.is_degraded()
                        }

                    if decision.get("decision") == "deny":
                        self.runtime.system_agent.envoy_reject(reasoning_output.get("url"))
                        return {
                            "action": "ENVOY_LEVEL1",
                            "status": "denied",
                            "notes": "URL denied by policy.",
                            "degraded": HealthMonitor5.is_degraded()
                        }

                if mode == "FETCH":
                    action = "ENVOY_FETCH"
                elif mode == "EXECUTE":
                    action = "ENVOY_EXECUTE"
                else:
                    action = "ENVOY_FETCH"

            # SYSTEM AGENT (generic)
            elif route == "SYSTEM_AGENT":
                action = "SYSTEM_ACTION"

            # DEFAULT
            else:
                action = "WORKFLOW_CONTINUE"

            log5(f"[WorkflowEngine5] Selected action: {action}")

            step = self.registry.get_step(action)
            if not step:
                raise ValueError(f"Unknown workflow step: {action}")

            output = step.execute(reasoning_output)
            log5(f"[WorkflowEngine5] Step output: {output}")

            if action == "ENVOY_FETCH":
                HealthMonitor5.record_success()
                return {
                    "action": action,
                    "output": output,
                    "notes": "ENVOY_FETCH completed. Awaiting manual ENVOY_EXECUTE.",
                    "degraded": HealthMonitor5.is_degraded()
                }

            HealthMonitor5.record_success()

            return {
                "action": action,
                "output": output,
                "degraded": HealthMonitor5.is_degraded()
            }

        return ErrorHandler5.safe_execute(
            _exec,
            context={"reasoning_output": reasoning_output},
            fallback={
                "action": None,
                "output": None,
                "error": "WorkflowEngine5 failed.",
                "degraded": HealthMonitor5.is_degraded()
            }
        )
