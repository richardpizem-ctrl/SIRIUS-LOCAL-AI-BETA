# runtime5/envoy_quarantine_5.py
# SIRIUS LOCAL AI – ENVOY Quarantine 5.x
# Clean, deterministic, multi‑queue quarantine (pending/approved/rejected)

from runtime5.logging_5 import log5


class EnvoyQuarantine5:
    """
    ENVOY Quarantine 5.x
    - pending: waiting for approval
    - approved: ready for execution
    - rejected: blocked by user/policy
    - raw_store: RAW HTTP responses
    """

    def __init__(self):
        self.queue_pending = []
        self.queue_approved = []
        self.queue_rejected = []
        self.raw_store = {}
        log5("[EnvoyQuarantine5] Initialized quarantine store")

    # --------------------------------------------------------
    # ADD REQUEST (always goes to pending)
    # --------------------------------------------------------
    def add(self, request: dict):
        log5("[EnvoyQuarantine5] Quarantining ENVOY request → PENDING")
        self.queue_pending.append(request)

    # --------------------------------------------------------
    # APPROVE REQUEST
    # --------------------------------------------------------
    def approve(self, url: str):
        for req in self.queue_pending:
            if req.get("entity") == url:
                self.queue_pending.remove(req)
                self.queue_approved.append(req)
                log5(f"[EnvoyQuarantine5] APPROVED: {url}")
                return True
        return False

    # --------------------------------------------------------
    # REJECT REQUEST
    # --------------------------------------------------------
    def reject(self, url: str):
        for req in self.queue_pending:
            if req.get("entity") == url:
                self.queue_pending.remove(req)
                self.queue_rejected.append(req)
                log5(f"[EnvoyQuarantine5] REJECTED: {url}")
                return True
        return False

    # --------------------------------------------------------
    # POP NEXT APPROVED REQUEST
    # --------------------------------------------------------
    def pop_next(self):
        if not self.queue_approved:
            return None
        return self.queue_approved.pop(0)

    # --------------------------------------------------------
    # LISTS
    # --------------------------------------------------------
    def list_pending(self):
        return list(self.queue_pending)

    def list_approved(self):
        return list(self.queue_approved)

    def list_rejected(self):
        return list(self.queue_rejected)

    # --------------------------------------------------------
    # RAW STORE
    # --------------------------------------------------------
    def store_raw(self, url: str, raw_data: dict):
        log5(f"[EnvoyQuarantine5] Storing RAW response for: {url}")

        if len(self.raw_store) >= 10:
            oldest_key = next(iter(self.raw_store))
            del self.raw_store[oldest_key]

        self.raw_store[url] = raw_data

    def get_raw(self, url: str):
        return self.raw_store.get(url)
