# runtime5/kg_relations_5.py

from runtime5.logging_5 import log5
from runtime5.error_handler_5 import ErrorHandler5

class KGRelations5:
    """
    Relation manager for SIRIUS Runtime 5.x
    Provides:
    - add relation
    - list relations for entity
    """

    def __init__(self, kg):
        self.kg = kg

    def add_relation(self, source: str, relation: str, target: str):
        def _exec():
            self.kg.add_relation(source, relation, target)
            return {
                "status": "ok",
                "added": {
                    "source": source,
                    "relation": relation,
                    "target": target
                }
            }

        return ErrorHandler5.safe_execute(
            _exec,
            context={"source": source, "relation": relation, "target": target},
            fallback={"status": "error", "notes": "Failed to add relation."}
        )

    def list_relations(self, entity: str):
        def _exec():
            rels = self.kg.get_relations(entity)
            return {
                "status": "ok",
                "entity": entity,
                "count": len(rels),
                "relations": rels
            }

        return ErrorHandler5.safe_execute(
            _exec,
            context=entity,
            fallback={"status": "error", "notes": "Failed to list relations."}
        )
