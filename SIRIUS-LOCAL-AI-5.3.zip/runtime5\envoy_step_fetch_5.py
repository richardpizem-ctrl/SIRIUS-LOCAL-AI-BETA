# runtime5/envoy_step_fetch_5.py

from runtime5.logging_5 import log5


class EnvoyStepFetch5:
    """
    Workflow step: ENVOY_FETCH
    - Permission check (norm 5.x)
    - Quarantine storage
    """

    def __init__(self, runtime):
        # Shared runtime components
        self.runtime = runtime
        self.quarantine = runtime.quarantine
        self.permission = runtime.permission_layer

    def execute(self, reasoning):
        url = reasoning.get("entity")
        log5(f"[EnvoyStepFetch5] ENVOY_FETCH received URL: {url}")

        # -----------------------------------------------------
        # 1. PERMISSION CHECK (norm 5.x)
        # -----------------------------------------------------
        decision = self.permission.check_url(url)

        if not decision.allowed:
            log5(f"[EnvoyStepFetch5] Permission DENIED: {decision.reason}")
            return {
                "status": "envoy-denied",
                "reasoning": reasoning,
                "error": decision.reason,
                "notes": "ENVOY request blocked by PermissionLayer5.",
                "degraded": decision.to_dict().get("degraded", False)
            }

        log5("[EnvoyStepFetch5] Permission ALLOWED → storing in quarantine")

        # -----------------------------------------------------
        # 2. STORE REQUEST IN QUARANTINE (norm 5.x)
        # -----------------------------------------------------
        req = {"entity": url}
        self.quarantine.add(req)

        return {
            "status": "envoy-quarantined",
            "reasoning": reasoning,
            "notes": "Request stored in ENVOY quarantine (norm 5.x)."
        }
