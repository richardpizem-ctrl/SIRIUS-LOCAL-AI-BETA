# runtime5/envoy_step_execute_5.py

from runtime5.logging_5 import log5


class EnvoyStepExecute5:
    """
    Workflow step: ENVOY_EXECUTE
    - Executes ENVOY request (HTTP GET)
    - Normalizes response
    - Stores normalized entity into KG
    - Automatically generates KG relations (NEW)
    - Returns ONLY normalized data to workflow (no RAW)
    """

    def __init__(self, runtime):
        # Shared runtime components (NO NEW INSTANCES)
        self.runtime = runtime
        self.quarantine = runtime.quarantine
        self.execution = runtime.envoy_execution_layer
        self.permission = runtime.permission_layer
        self.kg = runtime.kg

    def execute(self, reasoning):
        url = reasoning.get("entity")
        log5(f"[EnvoyStepExecute5] ENVOY_EXECUTE received URL: {url}")

        # -----------------------------------------------------
        # 1. BUILD REQUEST FOR EXECUTION LAYER
        # -----------------------------------------------------
        req = {"entity": url}

        # -----------------------------------------------------
        # 2. EXECUTE ENVOY (returns ONLY normalized)
        # -----------------------------------------------------
        result = self.execution.execute(req)

        log5(f"[EnvoyStepExecute5] ENVOY_EXECUTE result: {result}")

        # -----------------------------------------------------
        # 3. STORE NORMALIZED RESULT INTO KG
        # -----------------------------------------------------
        if result.get("status") == "ok":
            normalized = result.get("normalized")
            if normalized:
                # Store entity
                self.kg.add_entity(url, normalized)

                # -----------------------------------------------------
                # 4. AUTOMATIC KG RELATIONS (NEW)
                # -----------------------------------------------------

                title = normalized.get("title")
                summary = normalized.get("summary")
                content = normalized.get("content")

                # 4.1 has_title
                if title:
                    self.kg.add_relation(url, "has_title", title)
                    log5(f"[KG] Auto relation: {url} -[has_title]-> {title}")

                # 4.2 has_type (simple heuristics)
                if "wikipedia.org" in url:
                    self.kg.add_relation(url, "has_type", "Website")
                    log5(f"[KG] Auto relation: {url} -[has_type]-> Website")

                elif url.endswith(".pdf"):
                    self.kg.add_relation(url, "has_type", "Document")
                    log5(f"[KG] Auto relation: {url} -[has_type]-> Document")

                elif url.endswith(".mp3"):
                    self.kg.add_relation(url, "has_type", "Audio")
                    log5(f"[KG] Auto relation: {url} -[has_type]-> Audio")

                elif url.endswith(".mp4"):
                    self.kg.add_relation(url, "has_type", "Video")
                    log5(f"[KG] Auto relation: {url} -[has_type]-> Video")

                else:
                    # Default fallback
                    self.kg.add_relation(url, "has_type", "WebResource")
                    log5(f"[KG] Auto relation: {url} -[has_type]-> WebResource")

                # 4.3 category (simple heuristics)
                if title and "Wikipedia" in title:
                    self.kg.add_relation(title, "category", "Encyclopedia")
                    log5(f"[KG] Auto relation: {title} -[category]-> Encyclopedia")

        # -----------------------------------------------------
        # 5. RETURN CLEAN OUTPUT TO WORKFLOW
        # -----------------------------------------------------
        return {
            "status": result.get("status"),
            "reasoning": reasoning,
            "normalized": result.get("normalized"),
            "notes": "ENVOY execution + normalization + auto-KG-relations completed (norm 5.x)."
        }
