from typing import Any, Dict

from runtime5.kg_core import KnowledgeGraph
from runtime5.kg_reasoner import KGReasoner
from runtime5.kg_router import KGRouter
from runtime5.logging_5 import log5

from runtime5.error_handler_5 import ErrorHandler5
from runtime5.health_monitor_5 import HealthMonitor5
from runtime5.system_hooks_5 import SystemHooks5


class ReasoningEngine5:
    """
    Reasoning Engine 5.x
    """

    def __init__(self, kg: KnowledgeGraph, reasoner: KGReasoner, router: KGRouter):
        self.kg = kg
        self.reasoner = reasoner
        self.router = router

        log5("[ReasoningEngine5] Initialized reasoning engine.")

    # --------------------------------------------------------
    # INTERNAL: ENVOY ROUTING
    # --------------------------------------------------------
    def _detect_envoy(self, intent: str, entity: str) -> bool:
        text = f"{intent} {entity}".lower()

        triggers = [
            "http://",
            "https://",
            " url ",
            "fetch ",
            "online",
            "download",
        ]

        return any(t in text for t in triggers)

    # --------------------------------------------------------
    # MAIN ENTRYPOINT
    # --------------------------------------------------------
    def process(self, intent: Any, entity: str) -> Dict[str, Any]:

        log5(f"[ReasoningEngine5] Starting reasoning for intent={intent}, entity={entity!r}")

        def _exec():

            raw = entity.strip()
            if not raw:
                raw = str(intent).strip()

            # URL extraction
            if raw.startswith("fetch "):
                e = raw.replace("fetch ", "", 1).strip()
            else:
                e = raw

            intent_lower = str(intent).lower()

            # --------------------------------------------------------
            # SPECIAL CASE: KG RELATIONS (NEW)
            # --------------------------------------------------------
            if intent_lower == "kg-relate":
                log5("[ReasoningEngine5] KG-RELATE routing")
                return {
                    "intent": intent,
                    "entity": raw,
                    "route": "KG_RELATE",
                    "degraded": HealthMonitor5.is_degraded()
                }

            if intent_lower == "kg-relations":
                log5("[ReasoningEngine5] KG-RELATIONS routing")
                return {
                    "intent": intent,
                    "entity": raw,
                    "route": "KG_RELATIONS",
                    "degraded": HealthMonitor5.is_degraded()
                }

            # --------------------------------------------------------
            # SPECIAL CASE: KG VIEW
            # --------------------------------------------------------
            if intent_lower.startswith("kg view"):
                extracted = raw.split(" ", 2)[-1].strip()

                if extracted.startswith('"') and extracted.endswith('"'):
                    extracted = extracted[1:-1]

                log5(f"[ReasoningEngine5] KG VIEW routing for entity: {extracted}")

                data = self.kg.get_entity(extracted)

                if not data:
                    return {
                        "intent": intent,
                        "entity": extracted,
                        "route": "KG_VIEW",
                        "error": f"Entity '{extracted}' not found in Knowledge Graph.",
                        "degraded": HealthMonitor5.is_degraded()
                    }

                return {
                    "intent": intent,
                    "entity": extracted,
                    "route": "KG_VIEW",
                    "result": data,
                    "degraded": HealthMonitor5.is_degraded()
                }

            # --------------------------------------------------------
            # KG OVERRIDE (parents, relations)
            # --------------------------------------------------------
            if intent_lower.startswith("kg "):
                parts = raw.split(" ", 2)

                if len(parts) >= 3:
                    extracted = parts[2].strip()
                else:
                    extracted = raw

                if extracted.startswith('"') and extracted.endswith('"'):
                    extracted = extracted[1:-1]

                e = extracted
                route = "KG_REASONING"
                log5(
                    f"[ReasoningEngine5] KG override routing for intent '{intent}', "
                    f"entity extracted: {e}"
                )

            # --------------------------------------------------------
            # ENVOY routing (EARLY RETURN)
            # --------------------------------------------------------
            elif self._detect_envoy(intent, e):
                log5(f"[ReasoningEngine5] ENVOY routing triggered for '{intent} {e}'")

                url = e.strip().replace("fetch ", "", 1).strip()

                payload = {
                    "intent": intent,
                    "entity": url,
                    "route": "ENVOY",
                    "mode": "LEVEL1",
                    "operation": "fetch",
                    "url": url,
                    "degraded": HealthMonitor5.is_degraded()
                }

                log5(f"[ReasoningEngine5] ENVOY payload: {payload}")
                return payload

            # --------------------------------------------------------
            # DEFAULT routing
            # --------------------------------------------------------
            else:
                route = self.router.route_intent(intent)
                log5(f"[ReasoningEngine5] Routed intent '{intent}' → {route}")

            # KG Reasoning (parents)
            if route == "KG_REASONING":

                parents = self.reasoner.infer_all_parents(e)
                parent = self.reasoner.infer_parent(e)

                payload = {
                    "intent": intent,
                    "entity": e,
                    "route": None,
                    "parent": parent,
                    "parent_chain": parents,
                    "degraded": HealthMonitor5.is_degraded()
                }

                log5(f"[ReasoningEngine5] KG reasoning payload: {payload}")
                return payload

            # ENVOY / SYSTEM / WORKFLOW path
            payload = {
                "intent": intent,
                "entity": e,
                "route": route,
                "notes": "Non-KG reasoning path. Extend with system/automation logic.",
                "degraded": HealthMonitor5.is_degraded()
            }

            log5(f"[ReasoningEngine5] Non-KG reasoning payload: {payload}")
            return payload

        return ErrorHandler5.safe_execute(
            _exec,
            context={"intent": intent, "entity": entity},
            fallback={
                "intent": intent,
                "entity": entity,
                "route": None,
                "result": None,
                "error": "ReasoningEngine5 failed.",
                "degraded": HealthMonitor5.is_degraded()
            }
        )
