# runtime5/envoy_raw_cache_5.py
# SIRIUS LOCAL AI – ENVOY RAW Cache 5.x

from runtime5.logging_5 import log5


class EnvoyRawCache5:
    """
    ENVOY RAW Cache 5.x
    - Lightweight in-memory cache for RAW HTTP responses
    - Indexed by URL
    - Limited size to protect memory
    """

    def __init__(self, max_items: int = 10):
        self.max_items = max_items
        self.store = {}
        log5(f"[EnvoyRawCache5] Initialized RAW cache (max_items={max_items})")

    def put(self, url: str, raw_data: dict):
        log5(f"[EnvoyRawCache5] Caching RAW response for: {url}")

        if len(self.store) >= self.max_items:
            oldest_key = next(iter(self.store))
            del self.store[oldest_key]

        self.store[url] = raw_data

    def get(self, url: str):
        return self.store.get(url)

    def list_urls(self):
        return list(self.store.keys())
