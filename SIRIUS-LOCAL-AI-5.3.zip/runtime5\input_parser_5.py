# runtime5/input_parser_5.py
# SIRIUS LOCAL AI – Input Parser 5.x
# Čisté oddelenie: intent / entity / args

from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, List
from runtime5.logging_5 import log5
from runtime5.error_handler_5 import ErrorHandler5


@dataclass
class ParsedInput5:
    raw: str
    intent: str
    entity: str
    args: Dict[str, Any]


class InputParser5:
    """
    Input Parser 5.x
    Úloha:
      - zobrať raw text (napr. 'fetch https://example.com')
      - oddeliť intent, entity, args
      - normalizovať špeciálne príkazy (kg query, kg view, fetch, atď.)
    """

    def __init__(self):
        log5("[InputParser5] Initialized Input Parser 5.x")

    # --------------------------------------------------------
    # PUBLIC API
    # --------------------------------------------------------
    def parse(self, text: str) -> ParsedInput5:
        return ErrorHandler5.safe_execute(
            lambda: self._parse_internal(text),
            context=text,
            fallback=ParsedInput5(
                raw=text,
                intent=text.strip(),
                entity=text.strip(),
                args={}
            )
        )

    # --------------------------------------------------------
    # INTERNAL
    # --------------------------------------------------------
    def _parse_internal(self, text: str) -> ParsedInput5:
        raw = text.strip()
        lower = raw.lower()

        # Empty input
        if not raw:
            return ParsedInput5(raw=raw, intent="", entity="", args={})

        # ----------------------------------------------------
        # 0) KG RELATIONS COMMANDS (NEW)
        # ----------------------------------------------------
        if lower.startswith("kg-relate"):
            entity = raw[len("kg-relate"):].strip()
            return ParsedInput5(
                raw=raw,
                intent="kg-relate",
                entity=entity,
                args={}
            )

        if lower.startswith("kg-relations"):
            entity = raw[len("kg-relations"):].strip()
            return ParsedInput5(
                raw=raw,
                intent="kg-relations",
                entity=entity,
                args={}
            )

        # ----------------------------------------------------
        # 1) KG COMMANDS (kg query / kg view / kg ...)
        # ----------------------------------------------------
        if lower.startswith("kg "):
            parts = raw.split(" ", 2)

            if len(parts) == 1:
                intent = "kg"
                entity = ""
            elif len(parts) == 2:
                intent = f"kg {parts[1]}"
                entity = ""
            else:
                intent = f"kg {parts[1]}"
                entity_raw = parts[2].strip()
                if entity_raw.startswith('"') and entity_raw.endswith('"'):
                    entity_raw = entity_raw[1:-1]
                entity = entity_raw

            return ParsedInput5(
                raw=raw,
                intent=intent,
                entity=entity,
                args={}
            )

        # ----------------------------------------------------
        # 2) FETCH / ENVOY STYLE
        # ----------------------------------------------------
        if lower.startswith("fetch "):
            parts = raw.split(" ", 1)
            intent = "fetch"
            entity = parts[1].strip() if len(parts) > 1 else ""
            return ParsedInput5(
                raw=raw,
                intent=intent,
                entity=entity,
                args={}
            )

        # ----------------------------------------------------
        # 3) SIMPLE ONE-WORD INTENT
        # ----------------------------------------------------
        tokens: List[str] = raw.split(" ", 1)

        if len(tokens) == 1:
            return ParsedInput5(
                raw=raw,
                intent=tokens[0],
                entity="",
                args={}
            )

        # ----------------------------------------------------
        # 4) DEFAULT: first token = intent, rest = entity
        # ----------------------------------------------------
        intent = tokens[0]
        entity = tokens[1].strip()

        return ParsedInput5(
            raw=raw,
            intent=intent,
            entity=entity,
            args={}
        )
