from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QTextEdit, QLineEdit, QPushButton
)
from PySide6.QtCore import Qt

from ui.orb_widget import OrbWidget


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("SIRIUS LOCAL AI – CHAT MODE")
        self.setMinimumSize(700, 500)

        container = QWidget()
        layout = QVBoxLayout(container)

        # ORB hore
        self.orb = OrbWidget()
        layout.addWidget(self.orb, alignment=Qt.AlignCenter)

        # Výstup (odpovede)
        self.output = QTextEdit()
        self.output.setReadOnly(True)
        self.output.setStyleSheet("font-size: 14px;")
        layout.addWidget(self.output)

        # Input + tlačidlo
        input_layout = QHBoxLayout()
        self.input = QLineEdit()
        self.input.setPlaceholderText("Napíš príkaz pre SIRIUS...")
        send_btn = QPushButton("SEND")
        send_btn.clicked.connect(self.process_input)

        input_layout.addWidget(self.input)
        input_layout.addWidget(send_btn)

        layout.addLayout(input_layout)

        self.setCentralWidget(container)

    def process_input(self):
        text = self.input.text().strip()
        if not text:
            return

        # Zobrazíme, čo napísal používateľ
        self.output.append(f"TY: {text}")

        # Jednoduchá odpoveď (zatím placeholder)
        self.output.append("SIRIUS: Príkaz prijatý.")

        # Vyčisti input
        self.input.clear()
