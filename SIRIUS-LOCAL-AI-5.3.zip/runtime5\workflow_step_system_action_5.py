# runtime5/workflow_step_system_action_5.py
# Handles KG_RELATE and KG_RELATIONS

from runtime5.logging_5 import log5

class WorkflowStepSystemAction5:
    def __init__(self, runtime):
        self.runtime = runtime
        self.agent = runtime.system_agent

    def execute(self, reasoning_output):
        route = reasoning_output.get("route")
        raw = reasoning_output.get("entity", "")

        # KG_RELATE
        if route == "KG_RELATE":
            log5("[SystemAction] Executing KG_RELATE")
            return self.agent.kg_relate(raw)

        # KG_RELATIONS
        if route == "KG_RELATIONS":
            log5("[SystemAction] Executing KG_RELATIONS")
            return self.agent.kg_relations(raw)

        return {"status": "error", "notes": "Unknown SYSTEM_ACTION route."}
