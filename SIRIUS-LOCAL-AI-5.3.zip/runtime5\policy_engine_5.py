# runtime5/policy_engine_5.py
# SIRIUS LOCAL AI – ENVOY Policy Engine 5.x

import json
import re
from runtime5.logging_5 import log5


class PolicyEngine5:
    """
    ENVOY Policy Engine 5.x
    Evaluates ENVOY requests against JSON-defined rules.
    """

    def __init__(self, policy_file):
        self.policy_file = policy_file
        self.rules = []
        self.load()

    # --------------------------------------------------------
    # LOAD RULES
    # --------------------------------------------------------
    def load(self):
        try:
            with open(self.policy_file, "r", encoding="utf-8") as f:
                self.rules = json.load(f)
            log5(f"[PolicyEngine5] Loaded {len(self.rules)} rules.")
        except Exception as e:
            log5(f"[PolicyEngine5] ERROR loading rules: {e}")
            self.rules = []

    # --------------------------------------------------------
    # EVALUATE URL
    # --------------------------------------------------------
    def evaluate(self, url: str):
        """
        Returns:
            { "effect": "allow" | "deny" | "warn", "reason": str }
        """
        for rule in self.rules:
            effect = rule.get("effect")
            pattern = rule.get("pattern")
            reason = rule.get("reason", "No reason provided.")

            if not pattern:
                continue

            try:
                if re.search(pattern, url, re.IGNORECASE):
                    return {"effect": effect, "reason": reason}
            except re.error:
                log5(f"[PolicyEngine5] Invalid regex: {pattern}")

        return {"effect": "allow", "reason": "No matching rule."}
