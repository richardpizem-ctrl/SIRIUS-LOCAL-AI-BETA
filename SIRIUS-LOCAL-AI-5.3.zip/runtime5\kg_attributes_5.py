# runtime5/kg_attributes_5.py

from runtime5.logging_5 import log5
from runtime5.error_handler_5 import ErrorHandler5

class KGAttributes5:
    """
    Attribute manager for SIRIUS Runtime 5.x
    Provides:
    - set attribute
    - get attributes
    - delete attribute
    """

    def __init__(self, kg):
        self.kg = kg

    def set_attribute(self, entity: str, key: str, value: str):
        def _exec():
            ent = self.kg.get_entity(entity)
            if not ent:
                return {"status": "error", "notes": f"Entity '{entity}' not found."}

            ent.attributes[key] = value
            return {
                "status": "ok",
                "entity": entity,
                "set": {key: value}
            }

        return ErrorHandler5.safe_execute(
            _exec,
            context={"entity": entity, "key": key},
            fallback={"status": "error", "notes": "Failed to set attribute."}
        )

    def get_attributes(self, entity: str):
        def _exec():
            ent = self.kg.get_entity(entity)
            if not ent:
                return {"status": "error", "notes": f"Entity '{entity}' not found."}

            return {
                "status": "ok",
                "entity": entity,
                "attributes": ent.attributes
            }

        return ErrorHandler5.safe_execute(
            _exec,
            context=entity,
            fallback={"status": "error", "notes": "Failed to get attributes."}
        )

    def delete_attribute(self, entity: str, key: str):
        def _exec():
            ent = self.kg.get_entity(entity)
            if not ent:
                return {"status": "error", "notes": f"Entity '{entity}' not found."}

            if key in ent.attributes:
                del ent.attributes[key]
                return {
                    "status": "ok",
                    "entity": entity,
                    "deleted": key
                }

            return {
                "status": "error",
                "notes": f"Attribute '{key}' not found."
            }

        return ErrorHandler5.safe_execute(
            _exec,
            context={"entity": entity, "key": key},
            fallback={"status": "error", "notes": "Failed to delete attribute."}
        )
