# runtime5/kg_view_5.py

from runtime5.kg_core import KnowledgeGraph
from runtime5.kg_query import KGQuery
from runtime5.logging_5 import log5
from runtime5.error_handler_5 import ErrorHandler5


class KGView5:
    """
    KG VIEW module for SIRIUS Runtime 5.x
    Provides:
    - pretty view of entity
    - shows attributes (title, summary, content, ...)
    - shows all relations
    - global view of all entities (view_all)
    """

    def __init__(self, kg: KnowledgeGraph):
        self.kg = kg
        self.query = KGQuery(kg)
        log5("[KGView5] Initialized KG VIEW module.")

    def view(self, entity: str):
        """
        Returns a structured view of a single entity.
        """

        def _exec():
            key = entity.strip().lower()

            ent = self.kg.get_entity(entity)
            if not ent:
                log5(f"[KGView5] Entity '{entity}' not found.")
                return {
                    "entity": entity,
                    "exists": False,
                    "error": "Entity not found in KG."
                }

            # Attributes (title, summary, content, ...)
            attributes = ent.attributes or {}

            title = attributes.get("title")
            summary = attributes.get("summary")
            content = attributes.get("content")

            # Relations
            relations = self.kg.get_relations(entity)

            return {
                "entity": entity,
                "exists": True,
                "title": title,
                "summary": summary,
                "content": content,
                "attributes": attributes,
                "relations": relations
            }

        return ErrorHandler5.safe_execute(
            _exec,
            context=entity,
            fallback={"entity": entity, "exists": False, "error": "KGView failed."}
        )

    # --------------------------------------------------------
    # GLOBAL VIEW OF ALL ENTITIES (FIXED)
    # --------------------------------------------------------
    @staticmethod
    def view_all(kg):
        """
        Returns a list of all entities stored in the KG.
        """

        try:
            entities = kg.get_all_entities()
        except Exception as e:
            log5(f"[KGView5] ERROR in view_all: {e}")
            return {
                "status": "error",
                "notes": "Failed to retrieve KG entities."
            }

        if not entities:
            return {
                "status": "empty",
                "notes": "Knowledge Graph contains no entities."
            }

        output = []
        for key, entity in entities.items():

            # entity is KGEntity, not dict
            attributes = entity.attributes or {}

            title = attributes.get("title", "(no title)")
            summary = attributes.get("summary", "")
            content = attributes.get("content", "")

            preview = summary[:200] if summary else content[:200]

            output.append({
                "url": entity.name,
                "title": title,
                "preview": preview
            })

        log5(f"[KGView5] view_all returned {len(output)} entities")

        return {
            "status": "ok",
            "count": len(output),
            "entities": output
        }
