# runtime5/system_agent_5.py
# SIRIUS LOCAL AI – System Agent 5.x

import time
import re
from urllib.parse import urljoin, urlparse

from runtime5.logging_5 import log5
from runtime5.envoy_client_5 import EnvoyClient5
from runtime5.envoy_normalizer_5 import EnvoyNormalizer5
from runtime5.error_handler_5 import ErrorHandler5


class SystemAgent5:

    def __init__(self, kg, quarantine):
        self.kg = kg
        self.quarantine = quarantine
        self.history = []
        log5("[SystemAgent5] Initializing system agent")

    # --------------------------------------------------------
    # KG RELATE
    # --------------------------------------------------------
    def kg_relate(self, raw: str):
        try:
            parts = raw.split(" ", 2)
            if len(parts) < 3:
                return {"status": "error", "notes": "Invalid kg-relate syntax."}

            source = parts[0].strip().strip('"')
            relation = parts[1].strip()
            target = parts[2].strip().strip('"')

            out = self.kg.add_relation(source, relation, target)
            return {"status": "ok", "added": out}

        except Exception as e:
            return {"status": "error", "notes": str(e)}

    # --------------------------------------------------------
    # KG RELATIONS
    # --------------------------------------------------------
    def kg_relations(self, raw: str):
        try:
            entity = raw.strip().strip('"')
            rels = self.kg.get_relations(entity)
            return {"status": "ok", "entity": entity, "relations": rels}
        except Exception as e:
            return {"status": "error", "notes": str(e)}

    # --------------------------------------------------------
    # HISTORY
    # --------------------------------------------------------
    def _record_history(self, url, result):
        entry = {
            "url": url,
            "timestamp": time.time(),
            "type": result.get("type"),
            "status": result.get("status"),
            "length": result.get("length") or len(result.get("content", "")),
        }
        self.history.append(entry)

    def envoy_history(self):
        return list(reversed(self.history))

    def envoy_history_clear(self):
        self.history.clear()
        return {"status": "ok", "notes": "ENVOY history cleared."}

    # --------------------------------------------------------
    # PENDING / APPROVE / REJECT
    # --------------------------------------------------------
    def envoy_pending_add(self, url: str):
        ok = self.quarantine.add_pending(url)
        if ok:
            log5(f"[SystemAgent5] Added to PENDING: {url}")
            return {"status": "ok", "pending": url}
        return {"status": "error", "notes": f"Failed to add pending: {url}"}

    def envoy_approve(self, url: str):
        ok = self.quarantine.approve(url)
        if ok:
            log5(f"[SystemAgent5] Approved ENVOY request: {url}")
            return {"status": "ok", "approved": url}
        return {"status": "error", "notes": f"URL not found in pending: {url}"}

    def envoy_reject(self, url: str):
        ok = self.quarantine.reject(url)
        if ok:
            log5(f"[SystemAgent5] Rejected ENVOY request: {url}")
            return {"status": "ok", "rejected": url}
        return {"status": "error", "notes": f"URL not found in pending: {url}"}

    def envoy_pending(self):
        return self.quarantine.list_pending()

    def envoy_approved(self):
        return self.quarantine.list_approved()

    def envoy_rejected(self):
        return self.quarantine.list_rejected()

    # --------------------------------------------------------
    # EXECUTE NEXT
    # --------------------------------------------------------
    def envoy_execute_next(self):
        return ErrorHandler5.safe_execute(
            self._exec_internal,
            context="envoy_execute_next",
            fallback={"status": "error", "notes": "SystemAgent5 failed."}
        )

    # --------------------------------------------------------
    # INTERNAL EXECUTION
    # --------------------------------------------------------
    def _exec_internal(self):
        req = self.quarantine.pop_next()
        if not req:
            return {"status": "empty", "notes": "No APPROVED ENVOY requests."}

        url = req.get("entity")
        log5(f"[SystemAgent5] Executing APPROVED ENVOY request: {url}")

        # FETCH
        raw_response = EnvoyClient5.fetch(url)

        # NORMALIZE
        normalizer = EnvoyNormalizer5()
        normalized = normalizer.normalize(raw_response)

        if normalized.get("status") == "ok":

            title = normalized.get("title")
            summary = normalized.get("summary")
            content = normalized.get("content")

            # STORE ENTITY
            self.kg.add_entity(
                name=url,
                attributes={"title": title, "summary": summary, "content": content}
            )
            log5(f"[SystemAgent5] Stored entity in KG: {url}")

            # has_title
            if title:
                self.kg.add_relation(url, "has_title", title)

            # has_type
            if "wikipedia.org" in url:
                self.kg.add_relation(url, "has_type", "Website")
            else:
                self.kg.add_relation(url, "has_type", "WebResource")

            # category
            if title and "Wikipedia" in title:
                self.kg.add_relation(title, "category", "Encyclopedia")

            # -----------------------------------------------------
            # DOMAIN RELATION
            # -----------------------------------------------------
            parsed = urlparse(url)
            domain = parsed.netloc.lower()

            if domain.startswith("www."):
                domain = domain[4:]

            self.kg.add_relation(url, "domain", domain)
            log5(f"[KG] Auto relation: {url} -[domain]-> {domain}")

            # -----------------------------------------------------
            # CONTENT KEYWORDS (mentions)
            # -----------------------------------------------------
            if content:
                text = content.lower()
                text = re.sub(r"[^a-z0-9 ]+", " ", text)
                words = text.split()

                STOPWORDS = {
                    "the","and","for","are","with","that","this","from","was","were",
                    "have","has","had","but","not","you","your","their","about","into",
                    "also","can","will","would","could","should","they","them","its",
                    "over","under","than","then","there","here","what","when","where",
                    "which","while","been","being","because","such","only","other",
                    "more","most","some","any","all","each","many","much","very",
                    "free","online","hosted","around","world"
                }

                filtered = [w for w in words if len(w) > 3 and w not in STOPWORDS]

                freq = {}
                for w in filtered:
                    freq[w] = freq.get(w, 0) + 1

                top_keywords = sorted(freq, key=freq.get, reverse=True)[:10]

                for kw in top_keywords:
                    self.kg.add_relation(url, "mentions", kw)
                    log5(f"[KG] Auto relation: {url} -[mentions]-> {kw}")

            # -----------------------------------------------------
            # links_to + linked_from (FILTERED)
            # -----------------------------------------------------
            html = raw_response.get("text") or ""

            # 🔥 OPRAVENÝ REGEX — 100% FUNKČNÝ
            links = re.findall(r'href=["\'](.*?)["\']', html, flags=re.IGNORECASE)

            STATIC_EXT = (
                ".png", ".jpg", ".jpeg", ".gif", ".svg",
                ".ico", ".css", ".js", ".webp", ".avif"
            )

            for link in links:
                if not link or link.startswith("#") or link.startswith("javascript:"):
                    continue

                if link.lower().endswith(STATIC_EXT):
                    continue

                abs_url = urljoin(url, link)

                # Skip Wikipedia language subdomains except EN
                if re.match(r"https://[a-z\-]+\.wikipedia\.org/?$", abs_url) and not abs_url.startswith("https://en."):
                    continue

                # FORWARD
                self.kg.add_relation(url, "links_to", abs_url)

                # REVERSE
                self.kg.add_relation(abs_url, "linked_from", url)

        # HISTORY
        self._record_history(url, normalized)

        return {"status": "executed", "request": req, "result": normalized}
