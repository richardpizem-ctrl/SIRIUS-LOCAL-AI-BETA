from runtime5.logging_5 import log5
from runtime5.health_monitor_5 import HealthMonitor5
from runtime5.workflow_engine_5 import WorkflowEngine5
from runtime5.reasoning_engine_5 import ReasoningEngine5
from runtime5.system_hooks_5 import SystemHooks5
from runtime5.kg_core import KnowledgeGraph
from runtime5.input_parser_5 import InputParser5

# NEW – shared KG stack
from runtime5.kg_query import KGQuery
from runtime5.kg_reasoner import KGReasoner
from runtime5.kg_router import KGRouter

# NEW – System Agent 5.x
from runtime5.system_agent_5 import SystemAgent5

# NEW – shared ENVOY quarantine
from runtime5.envoy_quarantine_5 import EnvoyQuarantine5

# NEW – Permission Layer 5.x
from runtime5.envoy_permission_layer_5 import PermissionLayer5

# NEW – ENVOY Execution Layer 5.x (shared)
from runtime5.envoy_execution_layer_5 import EnvoyExecutionLayer5

# NEW – ENVOY Normalizer 5.x (shared)
from runtime5.envoy_normalizer_5 import EnvoyNormalizer5

# NEW – ENVOY Client 5.x (shared)
from runtime5.envoy_client_5 import EnvoyClient5


class RuntimeCore:
    """
    Central orchestrator for Runtime 5.x.
    """

    def __init__(self):
        log5("[RuntimeCore] Initializing Runtime 5.x")

        # -----------------------------------------------------
        # 0. PERMISSION LAYER (single instance)
        # -----------------------------------------------------
        self.permission_layer = PermissionLayer5()

        # -----------------------------------------------------
        # 1. KNOWLEDGE GRAPH (single instance)
        # -----------------------------------------------------
        self.kg = KnowledgeGraph()

        # -----------------------------------------------------
        # 2. SHARED KG STACK (single instances)
        # -----------------------------------------------------
        self.kg_query = KGQuery(self.kg)
        self.kg_reasoner = KGReasoner(self.kg, self.kg_query)
        self.kg_router = KGRouter(self.kg, self.kg_reasoner)

        # -----------------------------------------------------
        # 3. SHARED ENVOY QUARANTINE (single instance)
        # -----------------------------------------------------
        self.quarantine = EnvoyQuarantine5()

        # -----------------------------------------------------
        # 4. SHARED ENVOY COMPONENTS (single instances)
        # -----------------------------------------------------
        self.envoy_client = EnvoyClient5()
        self.envoy_normalizer = EnvoyNormalizer5()
        self.envoy_execution_layer = EnvoyExecutionLayer5(self)

        # -----------------------------------------------------
        # 5. CORE COMPONENTS
        # -----------------------------------------------------
        self.health = HealthMonitor5
        self.workflow = WorkflowEngine5(self)

        # System Agent 5.x – dostane KG + karanténu
        self.system_agent = SystemAgent5(
            kg=self.kg,
            quarantine=self.quarantine
        )

        # ReasoningEngine5 dostane reasoner + router
        self.reasoner = ReasoningEngine5(
            kg=self.kg,
            reasoner=self.kg_reasoner,
            router=self.kg_router
        )

        # Input Parser 5.x
        self.parser = InputParser5()

        log5("[RuntimeCore] Initialization complete")

        # -----------------------------------------------------
        # AUTOLOAD KG (if autosave exists)
        # -----------------------------------------------------
        try:
            import os
            autosave_file = "autosave_kg.json"

            if os.path.exists(autosave_file):
                from runtime5.kg_export_import_5 import KGExportImport5
                loader = KGExportImport5(self.kg)
                result = loader.import_from_file(autosave_file)

                loaded = result.get("loaded_entities", 0)

                log5(
                    f"[RuntimeCore] AUTOLOAD completed → {autosave_file} "
                    f"({loaded} entities)"
                )
            else:
                log5("[RuntimeCore] AUTOLOAD skipped (no autosave file).")

        except Exception as e:
            log5(f"[RuntimeCore] AUTOLOAD ERROR: {e}")

    # ---------------------------------------------------------
    # MAIN EXECUTION ENTRY
    # ---------------------------------------------------------
    def process(self, data: dict):
        """
        Pipeline:
        1. Parse input (InputParser5)
        2. ReasoningEngine5.process()
        3. WorkflowEngine5.execute()
        """

        raw_input = data.get("input", "")
        log5(f"[RuntimeCore] Processing input: {raw_input}")

        # 1. PARSE INPUT
        parsed = self.parser.parse(raw_input)
        intent = parsed.intent
        entity = parsed.entity

        log5(f"[RuntimeCore] Parsed intent='{intent}', entity='{entity}'")

        # 2. REASONING
        reasoning_output = self.reasoner.process(
            intent=intent,
            entity=entity
        )

        # 3. WORKFLOW
        wf_output = self.workflow.execute(reasoning_output)

        # Degraded mode awareness
        if self.health.is_degraded():
            SystemHooks5.on_degraded()
        else:
            SystemHooks5.on_recovery()

        return wf_output

    # ---------------------------------------------------------
    # SHUTDOWN HOOK — AUTOSAVE
    # ---------------------------------------------------------
    def shutdown(self):
        """
        Called when Runtime5 is shutting down.
        Triggers autosave via SystemHooks5.
        """
        SystemHooks5.on_shutdown(self)
        log5("[RuntimeCore] Shutdown complete.")
