# runtime5/repair_core.py
# Self‑Repair Layer 1.0 – Core Logic

from runtime5.logging_5 import log5
from runtime5.health_monitor_5 import HealthMonitor5


class RepairCore:
    """
    Core of the Self‑Repair Layer 1.0.
    Handles:
        - integrity checks
        - workflow recovery
        - degraded mode recovery
        - triggering repair actions
    """

    def __init__(self, logger=None):
        self.logger = logger

    def run(self, health_monitor=None, workflow_engine=None):
        log5("[RepairCore] Starting repair cycle")

        if health_monitor is None:
            health_monitor = HealthMonitor5

        # 1. Check degraded mode
        degraded = health_monitor.is_degraded()
        if degraded:
            log5("[RepairCore] System is in degraded mode → attempting recovery")
        else:
            log5("[RepairCore] System is healthy → no repair needed")
            return {"status": "ok", "repair": "not_required"}

        # 2. Attempt workflow recovery
        if workflow_engine:
            try:
                workflow_engine.reset()
                log5("[RepairCore] Workflow engine reset successful")
            except Exception as e:
                log5(f"[RepairCore] Workflow reset failed: {e}")

        # 3. Attempt health recovery
        try:
            health_monitor.recover()
            log5("[RepairCore] HealthMonitor recovery successful")
        except Exception as e:
            log5(f"[RepairCore] HealthMonitor recovery failed: {e}")

        return {
            "status": "repaired",
            "repair": "attempted",
            "degraded_before": degraded,
            "degraded_after": health_monitor.is_degraded(),
        }
