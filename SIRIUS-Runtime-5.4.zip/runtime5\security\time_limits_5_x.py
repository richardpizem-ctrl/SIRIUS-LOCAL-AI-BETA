import time
import logging

logger = logging.getLogger("TimeLimits5.x")


class TimeLimits5_x:
    """
    Inteligentné časové limity pre Runtime 5.x
    - Denné limity
    - Nočný zákaz
    - Školský režim
    - Varovania
    - Enforcement
    """

    def __init__(self, config=None):
        self.config = config or {}
        self.sessions = {}  # {identity: start_timestamp}
        logger.info("[TimeLimits5.x] Initialized")

    def start_session(self, identity: str):
        self.sessions[identity] = time.time()
        logger.info(f"[TimeLimits5.x] Session started for {identity}")

    def get_elapsed_minutes(self, identity: str) -> float:
        if identity not in self.sessions:
            return 0
        return (time.time() - self.sessions[identity]) / 60

    def is_night_block(self, identity: str) -> bool:
        cfg = self.config.get(identity, {})
        hour = time.localtime().tm_hour

        night_start = cfg.get("night_start", 22)
        night_end = cfg.get("night_end", 6)

        if night_start <= hour or hour < night_end:
            return True
        return False

    def is_daily_limit_reached(self, identity: str) -> bool:
        cfg = self.config.get(identity, {})
        limit = cfg.get("daily_minutes", 0)

        if limit == 0:
            return False

        elapsed = self.get_elapsed_minutes(identity)
        return elapsed >= limit

    def is_school_limit_reached(self, identity: str, school_mode: bool) -> bool:
        if not school_mode:
            return False

        cfg = self.config.get(identity, {})
        limit = cfg.get("school_mode_limit", 0)

        if limit == 0:
            return False

        elapsed = self.get_elapsed_minutes(identity)
        return elapsed >= limit

    def should_warn(self, identity: str, threshold=5) -> bool:
        cfg = self.config.get(identity, {})
        limit = cfg.get("daily_minutes", 0)

        if limit == 0:
            return False

        remaining = limit - self.get_elapsed_minutes(identity)
        return 0 < remaining <= threshold

    def should_block(self, identity: str, school_mode: bool) -> bool:
        if self.is_night_block(identity):
            logger.warning(f"[TimeLimits5.x] NIGHT BLOCK for {identity}")
            return True

        if self.is_daily_limit_reached(identity):
            logger.warning(f"[TimeLimits5.x] DAILY LIMIT reached for {identity}")
            return True

        if self.is_school_limit_reached(identity, school_mode):
            logger.warning(f"[TimeLimits5.x] SCHOOL LIMIT reached for {identity}")
            return True

        return False
