# runtime5/envoy_permission_layer_5.py
# ENVOY Permission Layer 5.x + Policy Engine 5.x

from urllib.parse import urlparse
from runtime5.logging_5 import log5
from runtime5.error_handler_5 import ErrorHandler5
from runtime5.health_monitor_5 import HealthMonitor5
from runtime5.policy_engine_5 import PolicyEngine5   # ← NOVÝ IMPORT

# ⭐ OPRAVENÝ IMPORT SECURITY FAMILY 5.x
from runtime5.security.security_family_5_x import SecurityFamily5_x as SecurityFamily5


class PermissionDecision:
    """
    Simple ALLOW / DENY decision object.
    """

    def __init__(self, allowed: bool, reason: str = "", level: str = "INFO"):
        self.allowed = allowed
        self.reason = reason
        self.level = level

    def to_dict(self):
        return {
            "allowed": self.allowed,
            "reason": self.reason,
            "level": self.level,
            "degraded": HealthMonitor5.is_degraded()
        }


class PermissionLayer5:
    """
    ENVOY Permission Layer 5.x

    Zodpovedá za:
    - rozhodnutie ALLOW / DENY pre URL / akcie
    - whitelist / blacklist
    - Policy Engine 5.x
    - audit log
    """

    # Povolené protokoly
    ALLOWED_SCHEMES = {"http", "https"}

    # Zakázané prípony súborov (rizikové)
    BLOCKED_EXTENSIONS = {
        ".exe", ".bat", ".cmd", ".scr", ".ps1",
        ".msi", ".dll", ".com"
    }

    # Základný whitelist domén
    WHITELIST_DOMAINS = {
        "example.com",
        "github.com",
        "raw.githubusercontent.com",
        "pypi.org",
        "iana.org",

        # ---- POVOLENÉ DOMÉNY ----
        "wikipedia.org",
        "www.wikipedia.org",

        "httpbin.org",
        "www.httpbin.org",

        # ---- NOVÉ POVOLENÉ DOMÉNY (python.org) ----
        "python.org",
        "www.python.org",
    }

    # Základný blacklist domén
    BLACKLIST_DOMAINS = {
        "malware.test",
        "phishing.test",
    }

    def __init__(self):
        log5("[PermissionLayer5] Initialized ENVOY Permission Layer 5.x")

        # --------------------------------------------------------
        # LOAD POLICY ENGINE
        # --------------------------------------------------------
        self.policy_engine = PolicyEngine5("policies_envoy.json")
        log5("[PermissionLayer5] PolicyEngine5 loaded.")

        # ⭐ SECURITY FAMILY 5.x – OPRAVENÁ INICIALIZÁCIA
        self.security = SecurityFamily5("config/security_identity.json")

    # --------------------------------------------------------
    # PUBLIC: MAIN CHECK
    # --------------------------------------------------------
    def check_url(self, url: str) -> PermissionDecision:
        """
        Hlavný vstup pre ENVOY URL fetch.
        Vráti ALLOW / DENY + dôvod.
        """

        def _exec():
            parsed = urlparse(url)

            scheme = parsed.scheme.lower()
            netloc = parsed.netloc.lower()
            path = parsed.path.lower()

            log5(f"[PermissionLayer5] Checking URL permission for: {url}")

            # --------------------------------------------------------
            # 0) POLICY ENGINE
            # --------------------------------------------------------
            policy = self.policy_engine.evaluate(url)

            if policy["effect"] == "deny":
                reason = f"POLICY DENY: {policy['reason']}"
                log5(f"[PermissionLayer5] DENY: {reason}")
                return PermissionDecision(False, reason, level="WARN")

            if policy["effect"] == "warn":
                log5(f"[PermissionLayer5] POLICY WARNING: {policy['reason']} (allowed)")
                # pokračujeme ďalej, ale logujeme

            # --------------------------------------------------------
            # 1) Protokol
            # --------------------------------------------------------
            if scheme not in self.ALLOWED_SCHEMES:
                reason = f"Scheme '{scheme}' is not allowed."
                log5(f"[PermissionLayer5] DENY: {reason}")
                return PermissionDecision(False, reason, level="WARN")

            # --------------------------------------------------------
            # 2) Blacklist domén
            # --------------------------------------------------------
            if netloc in self.BLACKLIST_DOMAINS:
                reason = f"Domain '{netloc}' is explicitly blocked."
                log5(f"[PermissionLayer5] DENY: {reason}")
                return PermissionDecision(False, reason, level="WARN")

            # --------------------------------------------------------
            # 3) Rizikové prípony
            # --------------------------------------------------------
            for ext in self.BLOCKED_EXTENSIONS:
                if path.endswith(ext):
                    reason = f"File extension '{ext}' is blocked for security reasons."
                    log5(f"[PermissionLayer5] DENY: {reason}")
                    return PermissionDecision(False, reason, level="WARN")

            # --------------------------------------------------------
            # 4) Whitelist
            # --------------------------------------------------------
            if self.WHITELIST_DOMAINS and netloc not in self.WHITELIST_DOMAINS:
                reason = f"Domain '{netloc}' is not in whitelist."
                log5(f"[PermissionLayer5] DENY: {reason}")
                return PermissionDecision(False, reason, level="INFO")

            # --------------------------------------------------------
            # 5) OK
            # --------------------------------------------------------
            reason = f"URL '{url}' allowed by PermissionLayer5."
            log5(f"[PermissionLayer5] ALLOW: {reason}")
            return PermissionDecision(True, reason, level="INFO")

        return ErrorHandler5.safe_execute(
            _exec,
            context={"url": url},
            fallback=PermissionDecision(
                False,
                reason="PermissionLayer5 failed – denying by default.",
                level="ERROR"
            )
        )

    # --------------------------------------------------------
    # OPTIONAL: GENERIC ACTION CHECK
    # --------------------------------------------------------
    def check_action(self, action: str, context: dict | None = None) -> PermissionDecision:
        """
        Generic action permission check.
        Môžeš použiť pre systémové akcie, downloady, atď.
        """

        def _exec():
            a = action.strip().lower()
            log5(f"[PermissionLayer5] Checking action permission for: {a}")

            blocked_keywords = {"unsafe", "danger", "root", "admin_override"}

            if any(k in a for k in blocked_keywords):
                reason = f"Action '{action}' contains blocked keyword."
                log5(f"[PermissionLayer5] DENY: {reason}")
                return PermissionDecision(False, reason, level="WARN")

            reason = f"Action '{action}' allowed by PermissionLayer5."
            log5(f"[PermissionLayer5] ALLOW: {reason}")
            return PermissionDecision(True, reason, level="INFO")

        return ErrorHandler5.safe_execute(
            _exec,
            context={"action": action, "context": context or {}},
            fallback=PermissionDecision(
                False,
                reason="PermissionLayer5 failed – denying action by default.",
                level="ERROR"
            )
        )
