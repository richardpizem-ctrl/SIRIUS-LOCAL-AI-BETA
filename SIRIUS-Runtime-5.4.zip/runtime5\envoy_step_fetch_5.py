# runtime5/envoy_step_fetch_5.py

from runtime5.logging_5 import log5
from runtime5.envoy_client_5 import EnvoyClient5


class EnvoyStepFetch5:
    """
    ENVOY_FETCH – plná funkčná verzia pre Runtime 5.4
    - vykoná HTTP GET (bez KG integrácie)
    - uloží RAW do karantény
    - normalizuje HTML cez EnvoyNormalizer5
    - vráti čistý normalizovaný objekt
    """

    def __init__(self, runtime):
        self.runtime = runtime
        self.quarantine = runtime.quarantine
        self.normalizer = runtime.envoy_normalizer

    def execute(self, reasoning_output):
        url = reasoning_output.get("url", "").strip()

        log5(f"[ENVOY_FETCH] Received URL: {url}")

        if not url:
            return {
                "status": "error",
                "error": "Missing URL for ENVOY_FETCH."
            }

        # --------------------------------------------------------
        # 1. HTTP GET (bez KG, bez EXECUTE logiky)
        # --------------------------------------------------------
        log5(f"[ENVOY_FETCH] Performing HTTP GET: {url}")
        raw_response = EnvoyClient5.fetch(url)

        # raw_response môže byť:
        # - {"status": "ok", "url": ..., "content": bytes}
        # - {"status": "http-error", ...}
        # - {"status": "network-error", ...}
        # - {"status": "error", ...}

        # --------------------------------------------------------
        # 2. Uloženie RAW do karantény (bez blokovania)
        # --------------------------------------------------------
        try:
            if hasattr(self.quarantine, "store_raw"):
                self.quarantine.store_raw(url, raw_response)
        except Exception as e:
            log5(f"[ENVOY_FETCH] Quarantine store_raw failed: {e}")

        # --------------------------------------------------------
        # 3. Normalizácia HTML / RAW
        # --------------------------------------------------------
        normalized = self.normalizer.normalize(raw_response)
        log5(f"[ENVOY_FETCH] Normalized output ready")

        # --------------------------------------------------------
        # 4. Návratový objekt pre workflow
        # --------------------------------------------------------
        return {
            "status": "fetch_ready",
            "url": url,
            "normalized": normalized,
            "notes": "ENVOY_FETCH completed (HTTP GET + normalization)."
        }
