class WorkflowStepBase:
    """
    Base class for all workflow steps in Runtime 5.x.
    Provides a consistent interface.
    """

    name = "BASE_STEP"

    def execute(self, payload: dict):
        raise NotImplementedError("Workflow step must implement execute()")
