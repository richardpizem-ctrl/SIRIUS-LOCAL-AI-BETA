# runtime5/envoy_normalizer_5.py
# Modern ENVOY normalizer for Runtime 5.x
# Extracts text from HTML, JSON hydration, meta tags, fallback blocks
# Now includes LEVEL 1 (Metadata) output
# SAFE VERSION – odolný voči:
#  - response ako dict (EnvoyClient5)
#  - response ako čistý string (URL alebo HTML)
#  - binárny / komprimovaný obsah (brotli bez knižnice, atď.)

import re
import json
import datetime
from typing import Any, Dict, Union

from bs4 import BeautifulSoup, Comment
from runtime5.logging_5 import log5

MAX_CONTENT = 20000


class EnvoyNormalizer5:
    """
    ENVOY Response Normalizer 5.x (SAFE VERSION)
    Modern HTML → text extractor.
    Handles:
      - classic HTML
      - React/SPA hydration JSON
      - inline JS text
      - meta descriptions
      - fallback <noscript>
      - LEVEL 1 metadata output
      - SAFE fallback pre binárny / komprimovaný obsah
      - SAFE fallback pre string input
    """

    def __init__(self):
        log5("[EnvoyNormalizer5] Initialized normalizer 5.x")

    # --------------------------------------------------------
    # PUBLIC API
    # --------------------------------------------------------
    def normalize(self, response: Union[Dict[str, Any], str]) -> Dict[str, Any]:
        log5("[EnvoyNormalizer5] Normalizing ENVOY response")

        # ----------------------------------------------------
        # CASE 1: response je čistý string (URL alebo HTML)
        # ----------------------------------------------------
        if isinstance(response, str):
            log5("[EnvoyNormalizer5] Received RAW STRING → wrapping safely")

            html = response or ""
            html = html.strip()

            if not html:
                return {
                    "status": "error",
                    "url": None,
                    "type": "html",
                    "title": None,
                    "summary": "",
                    "content": "",
                    "level1": None,
                    "notes": "Empty string input (SAFE VERSION)."
                }

            # Ak to vyzerá ako URL, nerobíme HTML parsing, len safe wrap
            if self._looks_like_url(html):
                summary = html[:300]
                content = html[:MAX_CONTENT]

                level1 = {
                    "level": 1,
                    "type": "web_metadata",
                    "url": None,
                    "title": None,
                    "summary": summary,
                    "timestamp": datetime.datetime.utcnow().isoformat(),
                    "source": "ENVOY",
                    "meta": {
                        "description": "",
                        "og_description": "",
                        "language": None,
                        "charset": None,
                    },
                }

                return {
                    "status": "ok",
                    "url": None,
                    "type": "html",
                    "title": None,
                    "summary": summary,
                    "content": content,
                    "level1": level1,
                    "notes": "Normalized HTML response (SAFE VERSION, URL-like string).",
                }

            # Inak to berieme ako raw HTML text
            return self._normalize_html_text(html, url=None, safe_note="SAFE VERSION (raw string)")

        # ----------------------------------------------------
        # CASE 2: očakávaný dict z EnvoyClient5
        # ----------------------------------------------------
        if not isinstance(response, dict):
            return {
                "status": "error",
                "url": None,
                "type": "html",
                "title": None,
                "summary": "",
                "content": "",
                "level1": None,
                "notes": "Invalid response type for EnvoyNormalizer5 (expected dict or str).",
            }

        if not response:
            return {
                "status": "error",
                "url": None,
                "type": "html",
                "title": None,
                "summary": "",
                "content": "",
                "level1": None,
                "notes": "Empty response dict.",
            }

        status = response.get("status")
        url = response.get("url")

        # Ak fetch nebol OK, len preposielame status
        if status != "ok":
            return {
                "status": status,
                "url": url,
                "type": None,
                "title": None,
                "summary": None,
                "content": None,
                "level1": None,
                "notes": response.get("notes") or response.get("reason") or "Non-OK ENVOY response.",
            }

        # Preferuj 'text' z EnvoyClient5, ak existuje
        html = response.get("text")
        raw = response.get("content", b"")

        # Ak text nie je, skús dekódovať content
        if not html:
            if isinstance(raw, (bytes, bytearray)):
                try:
                    html = raw.decode("utf-8", errors="ignore")
                except Exception:
                    html = ""
            else:
                html = str(raw or "")

        html = html or ""
        html = html.strip()

        if not html:
            # Žiadny text – pravdepodobne binárny obsah
            return self._binary_fallback(url=url, raw=raw, note="No decodable text (SAFE VERSION).")

        # Detekcia binárneho / komprimovaného bordelu
        if self._looks_binary(html):
            return self._binary_fallback(url=url, raw=raw, note="Binary/compressed-looking text (SAFE VERSION).")

        # Normálne HTML spracovanie
        return self._normalize_html_text(html, url=url, safe_note=None)

    # --------------------------------------------------------
    # INTERNAL: URL detector
    # --------------------------------------------------------
    def _looks_like_url(self, text: str) -> bool:
        t = text.strip().lower()
        if t.startswith("http://") or t.startswith("https://"):
            return True
        if " " in t:
            return False
        if "." in t and "/" in t:
            return True
        return False

    # --------------------------------------------------------
    # INTERNAL: binary detector
    # --------------------------------------------------------
    def _looks_binary(self, text: str) -> bool:
        # Pozrieme prvých pár stoviek znakov
        sample = text[:400]
        if not sample:
            return False

        non_printable = 0
        for ch in sample:
            code = ord(ch)
            # povolené: bežné whitespace + tlačiteľné ASCII
            if code in (9, 10, 13):  # \t, \n, \r
                continue
            if 32 <= code <= 126:
                continue
            non_printable += 1

        # Ak je veľa netlačiteľných znakov, berieme to ako binárne
        return non_printable > 10

    # --------------------------------------------------------
    # INTERNAL: binary fallback
    # --------------------------------------------------------
    def _binary_fallback(self, url: str, raw: Any, note: str) -> Dict[str, Any]:
        length = 0
        if isinstance(raw, (bytes, bytearray)):
            length = len(raw)
        else:
            try:
                length = len(str(raw))
            except Exception:
                length = 0

        summary = f"[binary or compressed content, {length} bytes]"
        content = summary

        level1 = {
            "level": 1,
            "type": "web_metadata",
            "url": url,
            "title": None,
            "summary": summary,
            "timestamp": datetime.datetime.utcnow().isoformat(),
            "source": "ENVOY",
            "meta": {
                "description": "",
                "og_description": "",
                "language": None,
                "charset": None,
            },
        }

        return {
            "status": "ok",
            "url": url,
            "type": "binary",
            "title": None,
            "summary": summary,
            "content": content,
            "level1": level1,
            "notes": f"Normalized HTML response (SAFE VERSION, {note})",
        }

    # --------------------------------------------------------
    # INTERNAL: main HTML normalization
    # --------------------------------------------------------
    def _normalize_html_text(self, html: str, url: str, safe_note: str = None) -> Dict[str, Any]:
        from bs4 import MarkupResemblesLocatorWarning
        import warnings

        # Potlačíme warning pri URL-like vstupoch
        warnings.filterwarnings("ignore", category=MarkupResemblesLocatorWarning)

        soup = BeautifulSoup(html, "html.parser")

        # --------------------------------------------------------
        # TITLE EXTRACTION
        # --------------------------------------------------------
        title = None

        if soup.title and soup.title.string:
            title = soup.title.string.strip()

        if not title:
            h1 = soup.find("h1")
            if h1:
                title = h1.get_text(strip=True)

        # --------------------------------------------------------
        # META DESCRIPTION
        # --------------------------------------------------------
        meta_desc = soup.find("meta", attrs={"name": "description"})
        if meta_desc and meta_desc.get("content"):
            meta_text = meta_desc["content"].strip()
        else:
            meta_text = ""

        # --------------------------------------------------------
        # OPEN GRAPH DESCRIPTION
        # --------------------------------------------------------
        og_desc = soup.find("meta", property="og:description")
        if og_desc and og_desc.get("content"):
            og_text = og_desc["content"].strip()
        else:
            og_text = ""

        # --------------------------------------------------------
        # NOSCRIPT FALLBACK
        # --------------------------------------------------------
        noscript_text = ""
        for ns in soup.find_all("noscript"):
            noscript_text += " " + ns.get_text(" ", strip=True)

        # --------------------------------------------------------
        # JSON HYDRATION EXTRACTION
        # --------------------------------------------------------
        hydration_text = ""

        for script in soup.find_all("script"):
            # JSON hydration blocks
            if script.get("type") in ("application/json", "application/ld+json"):
                try:
                    data = json.loads(script.string or "")
                    hydration_text += " " + self._extract_json_text(data)
                except Exception:
                    pass

            # Inline JS with text strings
            if script.string:
                matches = re.findall(r"['\"]([^'\"]{5,})['\"]", script.string)
                for m in matches:
                    hydration_text += " " + m

        # --------------------------------------------------------
        # REMOVE SCRIPT/STYLE TAGS (after extracting JSON)
        # --------------------------------------------------------
        for tag in soup(["script", "style"]):
            tag.decompose()

        # --------------------------------------------------------
        # REMOVE COMMENTS
        # --------------------------------------------------------
        for c in soup.find_all(string=lambda t: isinstance(t, Comment)):
            c.extract()

        # --------------------------------------------------------
        # CLASSIC TEXT EXTRACTION
        # --------------------------------------------------------
        classic_text = soup.get_text(" ", strip=True)
        classic_text = re.sub(r"\s+", " ", classic_text).strip()

        # --------------------------------------------------------
        # MERGE ALL SOURCES
        # --------------------------------------------------------
        full_text = " ".join(
            [
                meta_text,
                og_text,
                noscript_text,
                hydration_text,
                classic_text,
            ]
        )

        full_text = re.sub(r"\s+", " ", full_text).strip()

        log5(f"[EnvoyNormalizer5] RAW TEXT LENGTH: {len(full_text)}")

        # Remove duplicated title
        if title and full_text.lower().startswith(title.lower()):
            full_text = full_text[len(title) :].strip()

        # Final clean
        full_text = re.sub(r"\s+", " ", full_text).strip()

        log5(f"[EnvoyNormalizer5] CLEAN TEXT LENGTH: {len(full_text)}")

        # Summary + content
        summary = full_text[:300] if full_text else ""
        content = full_text[:MAX_CONTENT] if full_text else ""

        # --------------------------------------------------------
        # LEVEL 1 METADATA OBJECT
        # --------------------------------------------------------
        level1 = {
            "level": 1,
            "type": "web_metadata",
            "url": url,
            "title": title,
            "summary": summary,
            "timestamp": datetime.datetime.utcnow().isoformat(),
            "source": "ENVOY",
            "meta": {
                "description": meta_text,
                "og_description": og_text,
                "language": soup.html.get("lang") if soup.html else None,
                "charset": soup.meta.get("charset") if soup.meta else None,
            },
        }

        note = "Normalized HTML response (modern extractor + Level 1 metadata)."
        if safe_note:
            note = f"Normalized HTML response ({safe_note})."

        # --------------------------------------------------------
        # FINAL OUTPUT
        # --------------------------------------------------------
        return {
            "status": "ok",
            "url": url,
            "type": "html",
            "title": title,
            "summary": summary,
            "content": content,
            "level1": level1,
            "notes": note,
        }

    # --------------------------------------------------------
    # JSON TEXT EXTRACTOR (recursive)
    # --------------------------------------------------------
    def _extract_json_text(self, obj: Any) -> str:
        text = ""

        if isinstance(obj, dict):
            for v in obj.values():
                text += " " + self._extract_json_text(v)

        elif isinstance(obj, list):
            for item in obj:
                text += " " + self._extract_json_text(item)

        elif isinstance(obj, str):
            if len(obj) > 5:
                text += " " + obj

        return text.strip()
