import logging
from typing import Any, Dict

from runtime5.kg.kg_core_5 import KnowledgeGraph5

logger = logging.getLogger("KGQuery5")


class KGQuery5:
    """
    Spracovanie KG dotazov pre Runtime 5.x
    """

    def __init__(self, kg: KnowledgeGraph5):
        self.kg = kg
        logger.info("[KGQuery5] Initialized")

    # ⭐ NOVÁ FUNKCIA – KG NEIGHBORS
    def neighbors(self, entity: str) -> Dict[str, Any]:
        """
        Vráti všetky outgoing a incoming relácie pre danú entitu.
        """
        if entity not in self.kg.entities:
            return {"error": "entity_not_found", "entity": entity}

        # Outgoing hrany (entity → target)
        outgoing = self.kg.relations.get(entity, [])

        # Incoming hrany (source → entity)
        incoming = []
        for src, rels in self.kg.relations.items():
            for r in rels:
                if r["target"] == entity:
                    incoming.append({
                        "source": src,
                        "relation": r["relation"]
                    })

        return {
            "entity": entity,
            "outgoing": outgoing,
            "incoming": incoming
        }

    def handle_query(self, query: Dict[str, Any]) -> Dict[str, Any]:
        qtype = query.get("type")

        if qtype == "facts_about":
            subject = query.get("subject")
            facts = self.kg.get_facts(subject)
            return {"type": qtype, "subject": subject, "facts": facts}

        if qtype == "relations_from":
            subject = query.get("subject")
            rels = self.kg.get_relations_from(subject)
            return {"type": qtype, "subject": subject, "relations": rels}

        if qtype == "relations_between":
            subject = query.get("subject")
            obj = query.get("object")
            rels = self.kg.get_relations_between(subject, obj)
            return {"type": qtype, "subject": subject, "object": obj, "relations": rels}

        if qtype == "why_related":
            a = query.get("a")
            b = query.get("b")
            paths = self.kg.paths_between(a, b)
            return {"type": qtype, "a": a, "b": b, "paths": paths}

        if qtype == "expand_concept":
            concept = query.get("concept")

            facts = self.kg.get_facts(concept)
            rels = self.kg.get_relations_from(concept)

            return {
                "type": qtype,
                "concept": concept,
                "facts": facts,
                "relations": rels,
            }

        # fallback: raw
        return {"type": "unknown", "query": query}
