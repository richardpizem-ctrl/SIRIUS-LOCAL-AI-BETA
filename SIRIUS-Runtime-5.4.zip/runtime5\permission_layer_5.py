# runtime5/permission_layer_5.py

from runtime5.logging_5 import log5
from runtime5.error_handler_5 import ErrorHandler5
from runtime5.health_monitor_5 import HealthMonitor5


class PermissionPolicyEngine5:
    """
    Very simple deterministic policy engine for ENVOY LEVEL1.
    Decides:
    - allow
    - manual
    - deny
    """

    def evaluate(self, url: str):
        def _exec():
            if not url:
                return {"decision": "deny"}

            u = url.lower()

            # Auto-allow safe domains
            if any(x in u for x in ("example.com", "wikipedia.org", "github.com")):
                return {"decision": "allow"}

            # Manual approval for unknown domains
            if "." in u:
                return {"decision": "manual"}

            # Everything else denied
            return {"decision": "deny"}

        return ErrorHandler5.safe_execute(
            _exec,
            context=url,
            fallback={"decision": "deny"}
        )


class PermissionLayer5:
    """
    Permission Layer 5.x
    Provides:
    - policy engine
    - future expansion for user rules
    """

    def __init__(self, runtime):
        self.runtime = runtime
        self.policy_engine = PermissionPolicyEngine5()
        log5("[PermissionLayer5] Initialized permission layer.")
