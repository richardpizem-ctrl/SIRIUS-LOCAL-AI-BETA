import json
import base64
import os
import logging
from pathlib import Path
from hashlib import pbkdf2_hmac, sha256
from datetime import datetime
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import hmac

from runtime5.security.security_family_5_x import SecurityFamily5_x

logger = logging.getLogger("Vault5_0")


class Vault5_0:
    def __init__(self, config_path: str, vault_path: str, master_password: str):
        self.security = SecurityFamily5_x(config_path)
        self.vault_path = Path(vault_path)
        self.checksum_path = Path(str(vault_path) + ".checksum")
        self.signature_path = Path(str(vault_path) + ".sig")
        self.master_password = master_password

        self.key = self._derive_key(master_password)
        self.hmac_key = self._derive_hmac_key(master_password)

        # self‑repair guard
        self._repair_attempted = False

        logger.info("[Vault5.0] Initialized")

        if not self.vault_path.exists():
            self._save_vault({})
        else:
            if not self._verify_checksum():
                logger.error("[Vault5.0] CHECKSUM FAILED – vault corrupted")
                # try self‑repair immediately
                if not self._self_repair():
                    raise ValueError("CORRUPTED")

            self._ensure_signature()

    # -----------------------------
    # INTERNAL CRYPTO
    # -----------------------------
    def _derive_key(self, password: str) -> bytes:
        salt = b"SIRIUS_VAULT_SALT_5_0"
        return pbkdf2_hmac("sha256", password.encode(), salt, 200_000, dklen=32)

    def _derive_hmac_key(self, password: str) -> bytes:
        salt = b"SIRIUS_VAULT_HMAC_5_0"
        return pbkdf2_hmac("sha256", password.encode(), salt, 200_000, dklen=32)

    def _encrypt(self, plaintext: str) -> dict:
        aes = AESGCM(self.key)
        nonce = os.urandom(12)
        ciphertext = aes.encrypt(nonce, plaintext.encode(), None)
        return {
            "nonce": base64.b64encode(nonce).decode(),
            "ciphertext": base64.b64encode(ciphertext).decode()
        }

    def _decrypt(self, data: dict) -> str:
        aes = AESGCM(self.key)
        nonce = base64.b64decode(data["nonce"])
        ciphertext = base64.b64decode(data["ciphertext"])
        return aes.decrypt(nonce, ciphertext, None).decode()

    # -----------------------------
    # CHECKSUM
    # -----------------------------
    def _compute_checksum(self, data: dict) -> str:
        raw = json.dumps(data, sort_keys=True).encode()
        return sha256(raw).hexdigest()

    def _save_checksum(self, data: dict):
        checksum = self._compute_checksum(data)
        with self.checksum_path.open("w", encoding="utf-8") as f:
            f.write(checksum)

    def _verify_checksum(self) -> bool:
        if not self.checksum_path.exists():
            return False
        try:
            with self.vault_path.open("r", encoding="utf-8") as f:
                data = json.load(f)
            with self.checksum_path.open("r", encoding="utf-8") as f:
                stored = f.read().strip()
            return stored == self._compute_checksum(data)
        except Exception:
            return False

    # -----------------------------
    # SIGNATURE (HMAC)
    # -----------------------------
    def _compute_signature(self, data: dict) -> str:
        raw = json.dumps(data, sort_keys=True).encode()
        return hmac.new(self.hmac_key, raw, sha256).hexdigest()

    def _save_signature(self, data: dict):
        sig = self._compute_signature(data)
        with self.signature_path.open("w", encoding="utf-8") as f:
            f.write(sig)

    def _verify_signature(self) -> bool:
        if not self.signature_path.exists():
            return False
        try:
            with self.vault_path.open("r", encoding="utf-8") as f:
                data = json.load(f)
            with self.signature_path.open("r", encoding="utf-8") as f:
                stored = f.read().strip()
            expected = self._compute_signature(data)
            return hmac.compare_digest(stored, expected)
        except Exception:
            return False

    def _ensure_signature(self):
        if not self.signature_path.exists():
            try:
                with self.vault_path.open("r", encoding="utf-8") as f:
                    data = json.load(f)
                self._save_signature(data)
                logger.warning("[Vault5.0] SIGNATURE CREATED (initialization)")
            except Exception:
                logger.error("[Vault5.0] SIGNATURE INIT FAILED")
                raise ValueError("CORRUPTED")
        else:
            if not self._verify_signature():
                logger.error("[Vault5.0] SIGNATURE FAILED – TAMPERED")
                # try self‑repair
                if not self._self_repair():
                    raise ValueError("CORRUPTED")

    # -----------------------------
    # AUTO BACKUP
    # -----------------------------
    def _auto_backup(self):
        backup_dir = Path("vault/backups")
        backup_dir.mkdir(parents=True, exist_ok=True)

        timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        backup_path = backup_dir / f"vault_auto_{timestamp}.json"

        vault = self._load_vault_raw()
        with backup_path.open("w", encoding="utf-8") as f:
            json.dump(vault, f, indent=2)

        logger.info(f"[Vault5.0] AUTO BACKUP -> {backup_path}")

    # -----------------------------
    # SELF‑REPAIR LAYER
    # -----------------------------
    def _self_repair(self) -> bool:
        """
        Try to repair vault from latest backup.
        Returns True if repair succeeded, False otherwise.
        """
        if self._repair_attempted:
            logger.error("[Vault5.0] SELF_REPAIR already attempted – aborting")
            return False

        self._repair_attempted = True

        backup_dir = Path("vault/backups")
        if not backup_dir.exists():
            logger.error("[Vault5.0] SELF_REPAIR: no backup directory")
            return False

        candidates = []
        for p in backup_dir.glob("*.json"):
            # accept both auto and manual backups
            candidates.append(p)

        if not candidates:
            logger.error("[Vault5.0] SELF_REPAIR: no backup files found")
            return False

        # pick latest by modification time
        latest = max(candidates, key=lambda p: p.stat().st_mtime)

        try:
            with latest.open("r", encoding="utf-8") as f:
                data = json.load(f)

            # restore vault from backup
            with self.vault_path.open("w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)

            # regenerate checksum + signature
            self._save_checksum(data)
            self._save_signature(data)

            logger.warning(f"[Vault5.0] SELF_REPAIR SUCCESS from {latest}")
            return True
        except Exception as e:
            logger.error(f"[Vault5.0] SELF_REPAIR FAILED: {e}")
            return False

    # -----------------------------
    # VAULT LOAD/SAVE
    # -----------------------------
    def _load_vault_raw(self) -> dict:
        with self.vault_path.open("r", encoding="utf-8") as f:
            return json.load(f)

    def _load_vault(self) -> dict:
        data = self._load_vault_raw()

        if not self._verify_checksum():
            logger.error("[Vault5.0] CHECKSUM MISMATCH – CORRUPTED")
            if not self._self_repair():
                raise ValueError("CORRUPTED")
            data = self._load_vault_raw()

        if not self._verify_signature():
            logger.error("[Vault5.0] SIGNATURE MISMATCH – TAMPERED")
            if not self._self_repair():
                raise ValueError("CORRUPTED")
            data = self._load_vault_raw()

        return data

    def _save_vault(self, data: dict):
        with self.vault_path.open("w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        self._save_checksum(data)
        self._save_signature(data)

    # -----------------------------
    # PUBLIC API
    # -----------------------------
    def write(self, key: str, value: str, context: dict | None = None) -> str:
        if self.security.check("vault_access", context) != "ALLOW":
            return "DENIED"

        vault = self._load_vault()
        vault[key] = self._encrypt(value)
        self._save_vault(vault)
        self._auto_backup()
        return "OK"

    def read(self, key: str, context: dict | None = None) -> str:
        if self.security.check("vault_access", context) not in ("ALLOW", "READ"):
            return "DENIED"

        vault = self._load_vault()
        if key not in vault:
            return "NOT_FOUND"

        return self._decrypt(vault[key])

    def delete(self, key: str, context: dict | None = None) -> str:
        if self.security.check("vault_access", context) != "ALLOW":
            return "DENIED"

        vault = self._load_vault()
        if key not in vault:
            return "NOT_FOUND"

        del vault[key]
        self._save_vault(vault)
        self._auto_backup()
        return "OK"

    def list(self, context: dict | None = None) -> list:
        if self.security.check("vault_access", context) not in ("ALLOW", "READ"):
            return []
        return list(self._load_vault().keys())

    def exists(self, key: str, context: dict | None = None) -> bool:
        if self.security.check("vault_access", context) not in ("ALLOW", "READ"):
            return False
        return key in self._load_vault()

    def rotate_key(self, new_master_password: str, context: dict | None = None) -> str:
        if self.security.check("vault_access", context) != "ALLOW":
            return "DENIED"

        vault = self._load_vault()
        plaintexts = {k: self._decrypt(enc) for k, enc in vault.items()}

        self.key = self._derive_key(new_master_password)
        self.hmac_key = self._derive_hmac_key(new_master_password)
        self.master_password = new_master_password

        new_vault = {k: self._encrypt(v) for k, v in plaintexts.items()}
        self._save_vault(new_vault)
        self._auto_backup()
        return "OK"

    def export_vault(self, export_path: str, context: dict | None = None) -> str:
        if self.security.check("vault_access", context) != "ALLOW":
            return "DENIED"

        vault = self._load_vault()
        with open(export_path, "w", encoding="utf-8") as f:
            json.dump(vault, f, indent=2)
        return "OK"

    def import_vault(self, import_path: str, context: dict | None = None) -> str:
        if self.security.check("vault_access", context) != "ALLOW":
            return "DENIED"

        if not os.path.exists(import_path):
            return "NOT_FOUND"

        with open(import_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        if not isinstance(data, dict):
            return "INVALID"

        self._save_vault(data)
        self._auto_backup()
        return "OK"

    def backup(self, context: dict | None = None) -> str:
        if self.security.check("vault_access", context) != "ALLOW":
            return "DENIED"
        self._auto_backup()
        return "OK"

    # -----------------------------
    # CLEAR VAULT (SECURE WIPE)
    # -----------------------------
    def clear_vault(self, context: dict | None = None) -> str:
        if self.security.check("vault_access", context) != "ALLOW":
            logger.warning("[Vault5.0] CLEAR_VAULT DENIED for identity")
            return "DENIED"

        self._auto_backup()

        empty = {}
        self._save_vault(empty)

        logger.info("[Vault5.0] CLEAR_VAULT OK – vault wiped")
        return "OK"
