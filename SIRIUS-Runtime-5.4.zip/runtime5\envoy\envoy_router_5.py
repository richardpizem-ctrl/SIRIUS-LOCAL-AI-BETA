import logging
from runtime5.envoy.envoy_permission_5_x import EnvoyPermission5_x, EnvoyRequestContext
from runtime5.envoy.envoy_quarantine_5 import EnvoyQuarantine5

from runtime5.kg.kg_core_5 import KnowledgeGraph5
from runtime5.kg.kg_query_5 import KGQuery5
from runtime5.kg.kg_auto_linker_5 import KGAutoLinker5

logger = logging.getLogger("EnvoyRouter5")

# Singleton, aby všetky komponenty používali ten istý router + KG
_ROUTER_SINGLETON = None


class EnvoyRouter5:
    """
    ENVOY router pre Runtime 5.x
    - Permission Layer
    - Karanténa
    - KG backend (KnowledgeGraph5 + KGQuery5 + KGAutoLinker5)
    """

    def __init__(self, config_path: str):
        global _ROUTER_SINGLETON

        # Ak už existuje jedna inštancia, zdieľame ju
        if _ROUTER_SINGLETON is not None:
            self.permission = _ROUTER_SINGLETON.permission
            self.quarantine = _ROUTER_SINGLETON.quarantine
            self.kg = _ROUTER_SINGLETON.kg
            self.kg_query = _ROUTER_SINGLETON.kg_query
            self.kg_auto_linker = _ROUTER_SINGLETON.kg_auto_linker
            return

        # Prvé vytvorenie routera
        self.permission = EnvoyPermission5_x(config_path)
        self.quarantine = EnvoyQuarantine5()
        self.kg = KnowledgeGraph5()
        self.kg_query = KGQuery5(self.kg)
        self.kg_auto_linker = KGAutoLinker5(self.kg)

        _ROUTER_SINGLETON = self
        logger.info("[EnvoyRouter5] Initialized")

    def route(self, action: str, identity: str | None, payload: dict):
        # Bezpečnostná kontrola payloadu
        if payload is None or not isinstance(payload, dict):
            logger.error("[EnvoyRouter5] route() missing or invalid payload")
            return {"status": "ERROR", "reason": "invalid_payload"}

        ctx = EnvoyRequestContext(
            action=action,
            identity=identity,
            channel=payload.get("channel", "LOCAL"),
            source=payload.get("source", "SYSTEM_AGENT"),
            risk=payload.get("risk", "LOW"),
            extra=payload
        )

        decision = self.permission.check(action, identity, ctx)

        if decision == "DENY":
            self.quarantine.add(action, identity, payload, "Permission DENY")
            logger.warning(f"[EnvoyRouter5] DENIED action={action} identity={identity}")
            return {"status": "DENIED"}

        if decision == "REVIEW":
            self.quarantine.add(action, identity, payload, "Permission REVIEW")
            logger.info(f"[EnvoyRouter5] REVIEW_REQUIRED action={action} identity={identity}")
            return {"status": "REVIEW_REQUIRED"}

        if decision == "LOG_ONLY":
            logger.info(f"[EnvoyRouter5] LOG_ONLY action={action} identity={identity}")

        return self._execute(action, payload)

    def _execute(self, action: str, payload: dict):
        """
        Execution layer:
        - KG akcie
        - ostatné akcie (placeholder)
        """
        logger.info(f"[EnvoyRouter5] EXECUTE action={action}")

        # ----------------------------------------
        # KG: ADD FACT
        # ----------------------------------------
        if action == "kg.add_fact":
            subject = payload.get("subject")
            fact = payload.get("fact")
            value = payload.get("value")

            if subject is None:
                logger.error("[EnvoyRouter5] kg.add_fact missing subject")
                return {"status": "ERROR", "reason": "missing_subject"}

            self.kg.add_fact(subject, fact, value)

            return {"status": "OK", "action": action, "payload": payload}

        # ----------------------------------------
        # KG: ADD RELATION
        # ----------------------------------------
        if action == "kg.add_relation":
            subject = payload.get("subject")
            relation = payload.get("relation")
            obj = payload.get("object")

            if subject is None or relation is None or obj is None:
                logger.error("[EnvoyRouter5] kg.add_relation missing fields")
                return {"status": "ERROR", "reason": "missing_fields"}

            self.kg.add_relation(subject, relation, obj)

            if self.kg_auto_linker is not None:
                self.kg_auto_linker.process_new_relation(subject, relation, obj)

            return {"status": "OK", "action": action, "payload": payload}

        # ----------------------------------------
        # KG: QUERY
        # ----------------------------------------
        if action == "kg.query":
            query = payload.get("query")

            if query is None:
                logger.error("[EnvoyRouter5] kg.query missing query")
                return {"status": "ERROR", "reason": "missing_query"}

            result = self.kg_query.handle_query(query)

            return {"status": "OK", "action": action, "payload": payload, "result": result}

        # ----------------------------------------
        # ⭐ KG: NEIGHBORS (NOVÉ)
        # ----------------------------------------
        if action == "kg.neighbors":
            entity = payload.get("entity")

            if entity is None:
                logger.error("[EnvoyRouter5] kg.neighbors missing entity")
                return {"status": "ERROR", "reason": "missing_entity"}

            result = self.kg_query.neighbors(entity)

            return {
                "status": "OK",
                "action": action,
                "entity": entity,
                "neighbors": result
            }

        # ----------------------------------------
        # UNKNOWN ACTION
        # ----------------------------------------
        logger.warning(f"[EnvoyRouter5] UNKNOWN ACTION: {action}")
        return {"status": "ERROR", "reason": "unknown_action", "action": action, "payload": payload}
