# runtime5/compare_engine_5.py

from typing import Dict, Any
from runtime5.logging_5 import log5


class CompareEngine5:
    """
    Compare Engine 5.x
    - vstup: args["objects"] = [obj1, obj2]
    - výstup: štruktúrované porovnanie objektov
    """

    def __init__(self):
        log5("[CompareEngine5] Initialized compare engine 5.x")

        # Lokálna databáza vlastností pre porovnávanie
        self.db = {
            "tesla": {
                "type": "elektrické auto",
                "pros": ["nízka spotreba", "autopilot", "tichý chod"],
                "cons": ["vyššia cena", "dlhšie nabíjanie", "závislosť od nabíjačiek"]
            },
            "bmw": {
                "type": "prémiové auto",
                "pros": ["kvalitné spracovanie", "silné motory", "komfort"],
                "cons": ["vyššia spotreba", "vyššia cena servisu"]
            },
            "iphone": {
                "type": "smartfón",
                "pros": ["ekosystém", "dlhá podpora", "kvalitné fotoaparáty"],
                "cons": ["vyššia cena", "uzavretý systém"]
            },
            "samsung": {
                "type": "smartfón",
                "pros": ["široká ponuka modelov", "otvorený systém", "rýchle nabíjanie"],
                "cons": ["kratšia podpora", "kolísavá kvalita modelov"]
            }
        }

    def compare(self, entity: str, args: Dict[str, Any]) -> Dict[str, Any]:
        """
        Hlavná porovnávacia metóda.
        Očakáva args["objects"] = [obj1, obj2]
        """

        objects = args.get("objects", [])

        # Kontrola vstupu
        if not isinstance(objects, list):
            return {
                "status": "error",
                "reason": "Invalid input: 'objects' must be a list.",
                "objects": objects
            }

        if len(objects) < 2:
            return {
                "status": "error",
                "reason": "Compare requires at least two objects.",
                "objects": objects
            }

        # Extrakcia objektov
        left = str(objects[0]).lower().strip()
        right = str(objects[1]).lower().strip()

        # Ak objekt nie je v databáze
        if left not in self.db or right not in self.db:
            summary = f"Porovnanie '{left}' vs '{right}' nie je v databáze."
            result = {
                "status": "ok",
                "objects": {"left": left, "right": right},
                "summary": summary,
                "details": {
                    "left": {"pros": [], "cons": []},
                    "right": {"pros": [], "cons": []}
                }
            }
            log5(f"[CompareEngine5] Compare result: {result}")
            return result

        L = self.db[left]
        R = self.db[right]

        # Summary generátor
        summary = (
            f"{left.capitalize()} je {L['type']}, "
            f"{right.capitalize()} je {R['type']}. "
            f"{left.capitalize()} má výhody: {', '.join(L['pros'])}. "
            f"{right.capitalize()} má výhody: {', '.join(R['pros'])}."
        )

        result = {
            "status": "ok",
            "objects": {"left": left, "right": right},
            "summary": summary,
            "details": {
                "left": {"pros": L["pros"], "cons": L["cons"]},
                "right": {"pros": R["pros"], "cons": R["cons"]}
            }
        }

        log5(f"[CompareEngine5] Compare result: {result}")
        return result
