# runtime5/behavior_filter_5.py

from runtime5.logging_5 import log5


class BehaviorFilterResult:
    def __init__(self, allowed: bool, reason: str = None, rule_id: str = None):
        self.allowed = allowed
        self.reason = reason
        self.rule_id = rule_id

    def to_dict(self):
        return {
            "allowed": self.allowed,
            "reason": self.reason,
            "rule_id": self.rule_id
        }


class BehaviorFilter5:
    """
    Behaviorálny firewall pre Runtime 5.x
    - kontroluje vstupný text
    - aplikuje sadu pravidiel
    - rozhodne: ALLOW / DENY / FLAG
    - teraz podporuje aj context_score z ContextualBehaviorEngine5
    """

    def __init__(self):
        log5("[BehaviorFilter5] Initialized behavior filter 5.x")

        # jednoduché, ale rozšíriteľné pravidlá
        self.blocklist = [
            # hard deny – sem môžeš dopĺňať konkrétne výrazy
            {"id": "BF_HATE", "type": "deny", "match": ["zabij", "zabiť", "nenávidím ťa"]},
            {"id": "BF_SELF_HARM", "type": "deny", "match": ["ublížiť si", "chcem zomrieť"]},
        ]

        self.flaglist = [
            # soft flag – len označí, ale neblokuje
            {"id": "BF_AGGRESSIVE", "type": "flag", "match": ["si debil", "si idiot"]},
        ]

    def _matches_any(self, text: str, patterns: list) -> tuple | None:
        t = text.lower()
        for rule in patterns:
            for m in rule["match"]:
                if m.lower() in t:
                    return rule
        return None

    # ---------------------------------------------------------
    # ⭐ OPRAVENÁ VERZIA – teraz prijíma context_score
    # ---------------------------------------------------------
    def check_input(self, text: str, context_score: int = 100) -> BehaviorFilterResult:
        """
        Hlavný vstupný bod.
        """
        if not text or not text.strip():
            return BehaviorFilterResult(allowed=True)

        # 1) hard deny
        deny_rule = self._matches_any(text, self.blocklist)
        if deny_rule:
            log5(f"[BehaviorFilter5] DENY by rule {deny_rule['id']}")
            return BehaviorFilterResult(
                allowed=False,
                reason="BehaviorFilter5 blocked this input.",
                rule_id=deny_rule["id"]
            )

        # 2) soft flag (len log, ale povolí)
        flag_rule = self._matches_any(text, self.flaglist)
        if flag_rule:
            log5(f"[BehaviorFilter5] FLAG by rule {flag_rule['id']}")

        # 3) ⭐ context_score – ak je nízky, blokujeme
        if context_score < 40:
            log5(f"[BehaviorFilter5] DENY by context_score={context_score}")
            return BehaviorFilterResult(
                allowed=False,
                reason="Low context score (aggressive or risky input).",
                rule_id="BF_CONTEXT"
            )

        # 4) default allow
        return BehaviorFilterResult(allowed=True)
