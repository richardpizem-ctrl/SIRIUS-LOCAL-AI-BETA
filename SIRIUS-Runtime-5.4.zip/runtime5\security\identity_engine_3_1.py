import json
import logging
from pathlib import Path

logger = logging.getLogger("IdentityEngine3_1")


class IdentityEngine3_1:
    def __init__(self, config_path: str):
        self.config_path = Path(config_path)
        self.identities = {}
        self.default_identity = "OWNER"
        self._load_config()
        logger.info("[IdentityEngine3.1] Initialized")

    def _load_config(self):
        if not self.config_path.exists():
            logger.warning(f"[IdentityEngine3.1] Config not found: {self.config_path}, using defaults")
            self.identities = {
                "OWNER": {"description": "Primary device owner", "level": 3},
                "FAMILY": {"description": "Trusted family member", "level": 2},
                "STRANGER": {"description": "Untrusted user", "level": 1},
            }
            self.default_identity = "OWNER"
            return

        with self.config_path.open("r", encoding="utf-8") as f:
            data = json.load(f)

        self.identities = data.get("identities", {})
        self.default_identity = data.get("default_identity", "OWNER")

        logger.info(f"[IdentityEngine3.1] Loaded identities: {list(self.identities.keys())}")

    def get_identity(self, context: dict | None = None) -> str:
        identity = self.default_identity
        logger.debug(f"[IdentityEngine3.1] Resolved identity: {identity}")
        return identity

    def is_known_identity(self, identity: str) -> bool:
        return identity in self.identities

    def get_level(self, identity: str) -> int:
        if identity not in self.identities:
            return 0
        return int(self.identities[identity].get("level", 0))
