# SIRIUS LOCAL AI – Input Parser 5.x

from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any
from runtime5.logging_5 import log5
from runtime5.error_handler_5 import ErrorHandler5
from runtime5.parser_d import ParserD


@dataclass
class ParsedInput5:
    raw: str
    intent: str
    entity: str
    args: Dict[str, Any]


class InputParser5:

    def __init__(self):
        log5("[InputParser5] Initialized Input Parser 5.x")
        self.parser_d = ParserD()

    def parse(self, text: str) -> ParsedInput5:
        return ErrorHandler5.safe_execute(
            lambda: self._parse_internal(text),
            context=text,
            fallback=ParsedInput5(
                raw=text,
                intent=text.strip(),
                entity=text.strip(),
                args={}
            )
        )

    def _parse_internal(self, text: str) -> ParsedInput5:
        raw = text.strip()
        lower = raw.lower()

        if not raw:
            return ParsedInput5(raw=raw, intent="", entity="", args={})

        # ----------------------------------------------------
        # COMPARE – manuálna extrakcia objektov
        # ----------------------------------------------------
        if lower.startswith("porovnaj "):
            rest = raw[9:].strip()

            tmp = rest.replace(" vs ", " a ").replace(" versus ", " a ").replace(",", " a ")
            parts = [p.strip() for p in tmp.split(" a ") if p.strip()]

            if len(parts) >= 2:
                return ParsedInput5(
                    raw=raw,
                    intent="compare",
                    entity=rest,
                    args={"objects": parts}
                )

            parsed = self.parser_d.parse(raw)
            return ParsedInput5(
                raw=raw,
                intent=parsed["intent"],
                entity=parsed["normalized"],
                args=parsed["entities"]
            )

        # ----------------------------------------------------
        # KG RELATIONS
        # ----------------------------------------------------
        if lower.startswith("kg-relate"):
            entity = raw[len("kg-relate"):].strip()
            return ParsedInput5(raw, "kg-relate", entity, {})

        if lower.startswith("kg-relations"):
            entity = raw[len("kg-relations"):].strip()
            return ParsedInput5(raw, "kg-relations", entity, {})

        # ----------------------------------------------------
        # ⭐ NATÍVNE KG PRÍKAZY
        # ----------------------------------------------------

        # kg-neighbors URL
        if lower.startswith("kg-neighbors"):
            parts = raw.split(maxsplit=1)
            entity = parts[1] if len(parts) > 1 else ""
            return ParsedInput5(raw, "kg.neighbors", entity, {})

        # kg-query TEXT
        if lower.startswith("kg-query"):
            parts = raw.split(maxsplit=1)
            entity = parts[1] if len(parts) > 1 else ""
            return ParsedInput5(raw, "kg.query", entity, {})

        # kg-add FACT VALUE
        if lower.startswith("kg-add "):
            parts = raw.split(maxsplit=2)
            fact = parts[1] if len(parts) > 1 else ""
            value = parts[2] if len(parts) > 2 else ""
            return ParsedInput5(raw, "kg.add_fact", fact, {"value": value})

        # kg-add-relation A REL B
        if lower.startswith("kg-add-relation"):
            parts = raw.split()
            if len(parts) >= 4:
                return ParsedInput5(
                    raw,
                    "kg.add_relation",
                    parts[1],
                    {"relation": parts[2], "target": parts[3]}
                )
            return ParsedInput5(raw, "kg.add_relation", "", {})

        # ----------------------------------------------------
        # ⭐ KG PATHFINDER
        # ----------------------------------------------------
        if lower.startswith("kg-path"):
            parts = raw.split()
            if len(parts) >= 3:
                return ParsedInput5(
                    raw,
                    "kg.path",
                    parts[1],
                    {"target": parts[2]}
                )
            return ParsedInput5(raw, "kg.path", "", {})

        # ----------------------------------------------------
        # GENERICKÉ KG PRÍKAZY
        # ----------------------------------------------------
        if lower.startswith("kg "):
            parts = raw.split(" ", 2)
            if len(parts) == 1:
                return ParsedInput5(raw, "kg", "", {})
            elif len(parts) == 2:
                return ParsedInput5(raw, f"kg {parts[1]}", "", {})
            else:
                entity = parts[2].strip().strip('"')
                return ParsedInput5(raw, f"kg {parts[1]}", entity, {})

        # ----------------------------------------------------
        # ⭐ KG-LIGHT (NEW)
        # ----------------------------------------------------
        if lower.startswith("kg-light"):
            parts = raw.split(maxsplit=1)
            entity = parts[1] if len(parts) > 1 else ""
            return ParsedInput5(raw, "kg.light", entity, {})

        # ----------------------------------------------------
        # FETCH
        # ----------------------------------------------------
        if lower.startswith("fetch "):
            parts = raw.split(" ", 1)
            entity = parts[1].strip() if len(parts) > 1 else ""
            return ParsedInput5(raw, "fetch", entity, {})

        # ----------------------------------------------------
        # ⭐ EXECUTE (NOVÉ)
        # ----------------------------------------------------
        if lower.startswith("execute "):
            parts = raw.split(" ", 1)
            entity = parts[1].strip() if len(parts) > 1 else ""
            return ParsedInput5(raw, "execute", entity, {})

        # ----------------------------------------------------
        # DEFAULT → PARSER D
        # ----------------------------------------------------
        parsed = self.parser_d.parse(raw)
        return ParsedInput5(
            raw=raw,
            intent=parsed["intent"],
            entity=parsed["normalized"],
            args=parsed["entities"]
        )
