# runtime5/workflow_step_kg_light_5.py
# SIRIUS LOCAL AI – Workflow Step: KG Light 5.x

from runtime5.logging_5 import log5

class WorkflowStepKGLight5:
    """
    Jednoduchý workflow krok pre KG-LIGHT.
    Zavolá modul KGLight5 a vráti entity + neighbors.
    """

    def __init__(self, runtime):
        self.kg_light = runtime.kg_light

    def execute(self, reasoning):
        entity = reasoning.get("entity", "")
        log5(f"[KGLightStep5] Looking up entity: {entity}")
        return self.kg_light.lookup(entity)
