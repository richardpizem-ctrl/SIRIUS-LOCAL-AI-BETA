from typing import Any, Dict

from runtime5.kg_core import KnowledgeGraph
from runtime5.kg_reasoner import KGReasoner
from runtime5.kg_router import KGRouter
from runtime5.logging_5 import log5

from runtime5.error_handler_5 import ErrorHandler5
from runtime5.health_monitor_5 import HealthMonitor5


class ReasoningEngine5:
    """
    Stabilizovaná verzia Reasoning Engine 5.x
    """

    def __init__(self, kg: KnowledgeGraph, reasoner: KGReasoner, router: KGRouter):
        self.kg = kg
        self.reasoner = reasoner
        self.router = router

        log5("[ReasoningEngine5] Initialized reasoning engine.")

    # --------------------------------------------------------
    # INTERNAL: ENVOY ROUTING
    # --------------------------------------------------------
    def _detect_envoy(self, intent: str, entity: str) -> bool:
        if not intent or not entity:
            return False

        text = f"{intent} {entity}".lower()

        triggers = [
            "http://",
            "https://",
            " url ",
            "fetch ",
            "online",
            "download",
        ]

        return any(t in text for t in triggers)

    # --------------------------------------------------------
    # MAIN ENTRYPOINT
    # --------------------------------------------------------
    def process(self, intent: Any, entity: str, args: Dict[str, Any] = None) -> Dict[str, Any]:

        log5(f"[ReasoningEngine5] Starting reasoning for intent={intent}, entity={entity!r}")

        if args is None:
            args = {}

        def _exec():

            raw = (entity or "").strip()
            if not raw:
                raw = str(intent or "").strip()

            if not raw:
                return {
                    "intent": intent,
                    "entity": entity,
                    "args": args,
                    "route": None,
                    "error": "Empty intent/entity.",
                    "degraded": HealthMonitor5.is_degraded()
                }

            text = raw.lower()
            intent_lower = str(intent or "").lower()

            # --------------------------------------------------------
            # TESTOVACÍ TRIGGER PRE SELF‑REPAIR
            # --------------------------------------------------------
            if text == "vyvolaj chybu":
                raise Exception("TestError")

            # --------------------------------------------------------
            # ⭐ SYSTEM ACTIONS
            # --------------------------------------------------------
            system_actions = {
                "enable stranger mode": "enable_stranger_mode",
                "disable stranger mode": "disable_stranger_mode",
                "enable school mode": "enable_school_mode",
                "disable school mode": "disable_school_mode",
                "enable safe mode": "enable_safe_mode",
                "disable safe mode": "disable_safe_mode",
            }

            for phrase, action in system_actions.items():
                if phrase in text:
                    return {
                        "intent": "system_action",
                        "entity": action,
                        "args": args,
                        "route": "SYSTEM_ACTION",
                        "notes": "System action routing.",
                        "degraded": False
                    }

            # --------------------------------------------------------
            # ⭐ KG-LIGHT (NEW) — MUSÍ BYŤ NAD NATIVE KG COMMANDS
            # --------------------------------------------------------
            if intent_lower == "kg.light":
                return {
                    "intent": intent,
                    "entity": raw,
                    "args": args,
                    "route": "KG_LIGHT",
                    "notes": "KG Light lookup.",
                    "degraded": False
                }

            # --------------------------------------------------------
            # ⭐ NATIVE KG COMMANDS
            # --------------------------------------------------------
            if intent_lower.startswith("kg."):
                return {
                    "intent": intent,
                    "entity": raw,
                    "args": args,
                    "route": "KG",
                    "operation": intent_lower,
                    "degraded": False
                }

            if intent_lower == "kg-relate":
                return {
                    "intent": intent,
                    "entity": raw,
                    "args": args,
                    "route": "KG_RELATE",
                    "degraded": HealthMonitor5.is_degraded()
                }

            if intent_lower == "kg-relations":
                return {
                    "intent": intent,
                    "entity": raw,
                    "args": args,
                    "route": "KG_RELATIONS",
                    "degraded": HealthMonitor5.is_degraded()
                }

            if intent_lower.startswith("kg view"):
                extracted = raw.split(" ", 2)[-1].strip()

                if extracted.startswith('"') and extracted.endswith('"'):
                    extracted = extracted[1:-1]

                data = self.kg.get_entity(extracted)

                if not data:
                    return {
                        "intent": intent,
                        "entity": extracted,
                        "args": args,
                        "route": "KG_VIEW",
                        "error": f"Entity '{extracted}' not found in Knowledge Graph.",
                        "degraded": HealthMonitor5.is_degraded()
                    }

                return {
                    "intent": intent,
                    "entity": extracted,
                    "args": args,
                    "route": "KG_VIEW",
                    "result": data,
                    "degraded": HealthMonitor5.is_degraded()
                }

            if intent_lower.startswith("kg "):
                parts = raw.split(" ", 2)
                extracted = parts[2].strip() if len(parts) >= 3 else raw

                if extracted.startswith('"') and extracted.endswith('"'):
                    extracted = extracted[1:-1]

                return {
                    "intent": intent,
                    "entity": extracted,
                    "args": args,
                    "route": "KG_REASONING",
                    "degraded": HealthMonitor5.is_degraded()
                }

            # --------------------------------------------------------
            # ⭐ ENVOY FETCH
            # --------------------------------------------------------
            if intent_lower == "fetch":
                url = raw.replace("fetch ", "", 1).strip()
                return {
                    "intent": intent,
                    "entity": url,
                    "args": args,
                    "route": "ENVOY",
                    "mode": "FETCH",
                    "operation": "fetch",
                    "url": url,
                    "degraded": HealthMonitor5.is_degraded()
                }

            # --------------------------------------------------------
            # ⭐ ENVOY EXECUTE
            # --------------------------------------------------------
            if intent_lower == "execute":
                url = raw.replace("execute ", "", 1).strip()
                return {
                    "intent": intent,
                    "entity": url,
                    "args": args,
                    "route": "ENVOY",
                    "mode": "EXECUTE",
                    "operation": "execute",
                    "url": url,
                    "degraded": HealthMonitor5.is_degraded()
                }

            # --------------------------------------------------------
            # CUSTOM ROUTING
            # --------------------------------------------------------
            if intent_lower == "compare":
                return {
                    "intent": intent,
                    "entity": raw,
                    "args": args,
                    "route": "COMPARE",
                    "notes": "Compare reasoning path.",
                    "degraded": False
                }

            if intent_lower == "info":
                return {
                    "intent": intent,
                    "entity": raw,
                    "args": args,
                    "route": "INFO",
                    "notes": "Informational reasoning path.",
                    "degraded": False
                }

            if intent_lower == "command":
                return {
                    "intent": intent,
                    "entity": raw,
                    "args": args,
                    "route": "COMMAND",
                    "notes": "Command → ENVOY execution path.",
                    "degraded": False
                }

            if intent_lower == "list":
                return {
                    "intent": intent,
                    "entity": raw,
                    "args": args,
                    "route": "LIST",
                    "notes": "List / enumeration reasoning path.",
                    "degraded": False
                }

            if intent_lower == "debug":
                return {
                    "intent": intent,
                    "entity": raw,
                    "args": args,
                    "route": "DEBUG",
                    "notes": "Debug / diagnostics reasoning path.",
                    "degraded": False
                }

            # --------------------------------------------------------
            # DEFAULT
            # --------------------------------------------------------
            route = self.router.route_intent(intent)

            return {
                "intent": intent,
                "entity": raw,
                "args": args,
                "route": route,
                "notes": "Non-KG reasoning path.",
                "degraded": HealthMonitor5.is_degraded()
            }

        return ErrorHandler5.safe_execute(
            _exec,
            context={"intent": intent, "entity": entity},
            fallback={
                "intent": intent,
                "entity": entity,
                "args": args,
                "route": None,
                "result": None,
                "error": "ReasoningEngine5 failed.",
                "degraded": HealthMonitor5.is_degraded()
            }
        )
