class FamilyMode5:
    """
    Family Mode 5.x
    Zodpovedá za:
    - pravidlá pre deti
    - bezpečné správanie
    - obmedzenia obsahu
    - základné povolenia

    API kontrakt je stabilný:
    - evaluate(user_ctx, request_ctx) -> dict
    """

    def __init__(self, config=None):
        self.config = config or {}

        # základné nastavenia
        self.blocked_keywords = [
            "porno", "sex", "violence", "kill", "shoot", "drugs"
        ]

        self.allowed_categories = [
            "education", "school", "learning", "kids"
        ]

        # režimy
        self.school_mode = False
        self.safe_mode = False

    # ---------------------------------------------------------
    # TOGGLES
    # ---------------------------------------------------------
    def enable_school_mode(self):
        self.school_mode = True

    def disable_school_mode(self):
        self.school_mode = False

    def enable_safe_mode(self):
        self.safe_mode = True

    def disable_safe_mode(self):
        self.safe_mode = False

    # ---------------------------------------------------------
    # MAIN EVALUATION
    # ---------------------------------------------------------
    def evaluate(self, user_ctx, request_ctx):
        """
        user_ctx = informácie o používateľovi (role, vek, identity)
        request_ctx = informácie o požiadavke (text, intent, entity)
        """

        text = (request_ctx.get("input") or "").lower()

        # 1) SchoolMode – povolené len vzdelávacie veci
        if self.school_mode:
            if not any(cat in text for cat in self.allowed_categories):
                return {
                    "mode": "family",
                    "allowed": False,
                    "reason": "SchoolMode: only educational content allowed"
                }

        # 2) SafeMode – blokuje nebezpečné slová
        if self.safe_mode:
            for word in self.blocked_keywords:
                if word in text:
                    return {
                        "mode": "family",
                        "allowed": False,
                        "reason": f"SafeMode: blocked keyword '{word}'"
                    }

        # 3) Default allow
        return {
            "mode": "family",
            "allowed": True,
            "reason": "FamilyMode5 allow"
        }
