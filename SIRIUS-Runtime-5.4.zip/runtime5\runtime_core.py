# runtime5/runtime_core.py

from runtime5.logging_5 import log5
from runtime5.health_monitor_5 import HealthMonitor5
from runtime5.workflow_engine_5 import WorkflowEngine5
from runtime5.reasoning_engine_5 import ReasoningEngine5
from runtime5.system_hooks_5 import SystemHooks5
from runtime5.kg_core import KnowledgeGraph
from runtime5.input_parser_5 import InputParser5

from runtime5.kg_query import KGQuery
from runtime5.kg_reasoner import KGReasoner
from runtime5.kg_router import KGRouter

from runtime5.system_agent_5 import SystemAgent5
from runtime5.envoy_quarantine_5 import EnvoyQuarantine5
from runtime5.envoy_permission_layer_5 import PermissionLayer5
from runtime5.envoy_execution_layer_5 import EnvoyExecutionLayer5
from runtime5.envoy_normalizer_5 import EnvoyNormalizer5
from runtime5.envoy_client_5 import EnvoyClient5

from runtime5.self_repair_5 import SelfRepair5

from runtime5.security.security_family_5_x import SecurityFamily5_x as SecurityFamily5
from runtime5.behavior_filter_5 import BehaviorFilter5
from runtime5.security.family_safety_rules_5_x import FamilySafetyRules5_x

from runtime5.security.identity_engine_3_1 import IdentityEngine3_1

# ⭐ NOVÉ – Contextual Behavior Engine
from runtime5.contextual_behavior_engine_5 import ContextualBehaviorEngine5

# ⭐ NOVÉ – KG LIGHT
from runtime5.kg_light_5 import KGLight5


class RuntimeCore:
    """
    Central orchestrator for Runtime 5.x.
    """

    def __init__(self):
        log5("[RuntimeCore] Initializing Runtime 5.x")

        self.permission_layer = PermissionLayer5()

        self.kg = KnowledgeGraph()

        self.kg_query = KGQuery(self.kg)
        self.kg_reasoner = KGReasoner(self.kg, self.kg_query)
        self.kg_router = KGRouter(self.kg, self.kg_reasoner)

        # ⭐ NOVÉ – KG LIGHT INIT
        self.kg_light = KGLight5(self.kg)

        self.quarantine = EnvoyQuarantine5()

        self.envoy_client = EnvoyClient5()
        self.envoy_normalizer = EnvoyNormalizer5()
        self.envoy_execution_layer = EnvoyExecutionLayer5(self)

        self.health = HealthMonitor5
        self.workflow = WorkflowEngine5(self)
        self.self_repair = SelfRepair5()

        self.system_agent = SystemAgent5(
            kg=self.kg,
            quarantine=self.quarantine
        )

        self.reasoner = ReasoningEngine5(
            kg=self.kg,
            reasoner=self.kg_reasoner,
            router=self.kg_router
        )

        self.parser = InputParser5()

        self.security = SecurityFamily5("config/security_identity.json")

        self.identity_engine = IdentityEngine3_1("config/security_identity.json")

        self.behavior_filter = BehaviorFilter5()

        self.family_safety = FamilySafetyRules5_x()

        # ⭐ NOVÉ – Context Engine
        self.context_engine = ContextualBehaviorEngine5()

        log5("[RuntimeCore] Initialization complete")

        # AUTOLOAD KG
        try:
            import os
            autosave_file = "autosave_kg.json"

            if os.path.exists(autosave_file):
                from runtime5.kg_export_import_5 import KGExportImport5
                loader = KGExportImport5(self.kg)
                result = loader.import_from_file(autosave_file)
                loaded = result.get("loaded_entities", 0)
                log5(f"[RuntimeCore] AUTOLOAD completed → {autosave_file} ({loaded} entities)")
            else:
                log5("[RuntimeCore] AUTOLOAD skipped (no autosave file).")

        except Exception as e:
            log5(f"[RuntimeCore] AUTOLOAD ERROR: {e}")

    # ---------------------------------------------------------
    # MAIN EXECUTION ENTRY
    # ---------------------------------------------------------
    def process(self, data: dict):
        raw_input = data.get("input", "")
        log5(f"[RuntimeCore] Processing input: {raw_input}")

        # ⭐ NOVÉ – Context scoring
        context = self.context_engine.analyze(raw_input)
        context_score = context["context_score"]

        # ⭐ BehaviorFilter dostáva context_score
        bf_result = self.behavior_filter.check_input(raw_input, context_score)

        # 🔥 1. BehaviorFilter tvrdý zákaz → okamžitý STOP
        if not bf_result.allowed:
            return {
                "status": "denied",
                "reason": bf_result.reason,
                "rule_id": bf_result.rule_id,
                "layer": "BehaviorFilter5"
            }

        # 🔥 2. BehaviorFilter FLAG → degraded režim
        if getattr(bf_result, "flag", None) == "degraded":
            self.self_repair.report_error(
                "BehaviorFilter5",
                Exception("BehaviorFilter flagged degraded state")
            )

        identity = self.identity_engine.get_identity()
        fs_result = self.family_safety.check(identity, raw_input)

        if not fs_result["allowed"]:
            return {
                "status": "denied",
                "reason": fs_result["reason"],
                "layer": "FamilySafetyRules5_x"
            }

        decision = self.security.check(
            action="runtime_input",
            context={"input": raw_input}
        )

        if decision == "DENY":
            return {
                "status": "denied",
                "reason": "SecurityFamily5.x blocked this request."
            }

        try:
            parsed = self.parser.parse(raw_input)
            intent = parsed.intent
            entity = parsed.entity
            args = parsed.args

            log5(f"[RuntimeCore] Parsed intent='{intent}', entity='{entity}'")

            reasoning_output = self.reasoner.process(
                intent=intent,
                entity=entity,
                args=args
            )

            # 🔥 PREPOJENIE REASONING → SELF‑REPAIR
            if reasoning_output.get("error"):
                self.self_repair.report_error(
                    "ReasoningEngine5.process",
                    Exception(reasoning_output["error"])
                )

            wf_output = self.workflow.execute(reasoning_output)

        except Exception as e:
            self.self_repair.report_error("RuntimeCore.process", e)
            wf_output = {
                "status": "error",
                "message": "Runtime prešiel do degraded stavu. Self-Repair 5.4 chybu zachytil.",
                "degraded": True
            }

        return wf_output

    # ---------------------------------------------------------
    # AUTOSAVE KG SNAPSHOT
    # ---------------------------------------------------------
    def autosave_kg(self, filename: str = "autosave_kg.json"):
        try:
            from runtime5.kg_export_import_5 import KGExportImport5
            saver = KGExportImport5(self.kg)
            saver.export_to_file(filename)
            log5(f"[RuntimeCore] AUTOSAVE completed → {filename}")
        except Exception as e:
            log5(f"[RuntimeCore] AUTOSAVE ERROR: {e}")

    # ---------------------------------------------------------
    # SHUTDOWN HOOK — AUTOSAVE
    # ---------------------------------------------------------
    def shutdown(self):
        self.autosave_kg()
        SystemHooks5.on_shutdown(self)
        log5("[RuntimeCore] Shutdown complete.")
