# runtime5/workflow_step_system_action_5.py

from runtime5.logging_5 import log5

class WorkflowStepSystemAction5:
    """
    Executes system-level actions such as:
    - enable_stranger_mode
    - disable_stranger_mode
    - enable_school_mode
    - disable_school_mode
    - enable_safe_mode
    - disable_safe_mode
    """

    def __init__(self, runtime):
        self.runtime = runtime
        self.family = runtime.family_safety

    def execute(self, reasoning_output: dict):
        action = reasoning_output.get("entity", "")
        log5(f"[WorkflowStepSystemAction5] Executing system action: {action}")

        # -----------------------------
        # STRANGER MODE
        # -----------------------------
        if action == "enable_stranger_mode":
            self.family.enable_stranger_mode()
            return {"status": "ok", "notes": "StrangerMode enabled."}

        if action == "disable_stranger_mode":
            self.family.disable_stranger_mode()
            return {"status": "ok", "notes": "StrangerMode disabled."}

        # -----------------------------
        # SCHOOL MODE
        # -----------------------------
        if action == "enable_school_mode":
            self.family.enable_school_mode()
            return {"status": "ok", "notes": "SchoolMode enabled."}

        if action == "disable_school_mode":
            self.family.disable_school_mode()
            return {"status": "ok", "notes": "SchoolMode disabled."}

        # -----------------------------
        # SAFE MODE
        # -----------------------------
        if action == "enable_safe_mode":
            self.family.enable_safe_mode()
            return {"status": "ok", "notes": "SafeMode enabled."}

        if action == "disable_safe_mode":
            self.family.disable_safe_mode()
            return {"status": "ok", "notes": "SafeMode disabled."}

        # -----------------------------
        # UNKNOWN ACTION
        # -----------------------------
        return {
            "status": "error",
            "notes": f"Unknown SYSTEM_ACTION route: {action}"
        }
