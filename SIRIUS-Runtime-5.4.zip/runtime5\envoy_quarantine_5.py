# runtime5/envoy_quarantine_5.py
# SIRIUS LOCAL AI – ENVOY Quarantine 5.4 (MINIMAL)

from runtime5.logging_5 import log5


class EnvoyQuarantine5:
    """
    ENVOY Quarantine 5.4 – MINIMAL VERSION
    Stores:
      - RAW HTTP responses (FETCH)
      - FLAGGED EXECUTE results
    """

    def __init__(self):
        self.raw_store = []     # list of {"url", "bytes", "data"}
        self.flag_store = []    # list of {"url", "reason", "payload"}
        log5("[EnvoyQuarantine5] Initialized minimal quarantine store")

    # --------------------------------------------------------
    # STORE RAW FETCH RESPONSE
    # --------------------------------------------------------
    def store_raw(self, url: str, raw):
        """
        raw môže byť:
        - bytes
        - dict {"raw": bytes, ...}
        - čokoľvek iné (fallback)
        """

        # 1) bytes
        if isinstance(raw, (bytes, bytearray)):
            entry = {
                "url": url,
                "bytes": len(raw),
                "data": raw[:5000]
            }
            self.raw_store.append(entry)
            log5(f"[EnvoyQuarantine5] Stored RAW bytes ({len(raw)} bytes) for: {url}")
            return

        # 2) dict s kľúčom "raw"
        if isinstance(raw, dict) and "raw" in raw:
            raw_bytes = raw["raw"]
            if isinstance(raw_bytes, (bytes, bytearray)):
                entry = {
                    "url": url,
                    "bytes": len(raw_bytes),
                    "data": raw_bytes[:5000]
                }
                self.raw_store.append(entry)
                log5(f"[EnvoyQuarantine5] Stored RAW dict ({len(raw_bytes)} bytes) for: {url}")
                return

        # 3) fallback – neznámy typ
        entry = {
            "url": url,
            "bytes": None,
            "data": str(raw)[:5000]
        }
        self.raw_store.append(entry)
        log5(f"[EnvoyQuarantine5] Stored RAW fallback for: {url}")

    # --------------------------------------------------------
    # STORE FLAGGED EXECUTE RESULT
    # --------------------------------------------------------
    def store_flag(self, url: str, reason: str, payload: dict):
        entry = {
            "url": url,
            "reason": reason,
            "payload": payload
        }
        self.flag_store.append(entry)
        log5(f"[EnvoyQuarantine5] Stored FLAG for: {url} ({reason})")

    # --------------------------------------------------------
    # GETTERS
    # --------------------------------------------------------
    def get_raw(self):
        return list(self.raw_store)

    def get_flags(self):
        return list(self.flag_store)
