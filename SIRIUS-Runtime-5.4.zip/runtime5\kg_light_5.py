# runtime5/kg_light_5.py
# SIRIUS LOCAL AI – KG Light 5.x

from runtime5.logging_5 import log5

class KGLight5:

    def __init__(self, kg):
        self.kg = kg
        log5("[KGLight5] Initialized KG Light module")

    def lookup(self, entity: str):
        data = self.kg.get_entity(entity)

        if not data:
            return {
                "status": "not_found",
                "entity": entity,
                "neighbors": [],
                "notes": "Entity not found in KG."
            }

        neighbors = self.kg.get_neighbors(entity)

        return {
            "status": "ok",
            "entity": entity,
            "data": data,
            "neighbors": neighbors,
            "notes": "KG Light lookup completed."
        }
