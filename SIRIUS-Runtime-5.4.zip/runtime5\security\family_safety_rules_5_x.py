from runtime5.logging_5 import log5

class FamilySafetyRules5_x:
    """
    Family Safety Rules 5.x
    - SchoolMode
    - StrangerMode
    - SafeMode
    - Restricted Commands
    """

    def __init__(self):
        self.school_mode = False
        self.stranger_mode = False
        self.safe_mode = False

        self.restricted_commands = [
            "delete", "shutdown", "format", "remove", "kill", "disable"
        ]

        log5("[FamilySafetyRules5_x] Initialized Family Safety Rules 5.x")

    # ---------------------------------------------------------
    # MODE TOGGLES
    # ---------------------------------------------------------
    def enable_school_mode(self):
        self.school_mode = True
        log5("[FamilySafetyRules5_x] SchoolMode ENABLED")

    def disable_school_mode(self):
        self.school_mode = False
        log5("[FamilySafetyRules5_x] SchoolMode DISABLED")

    def enable_stranger_mode(self):
        self.stranger_mode = True
        log5("[FamilySafetyRules5_x] StrangerMode ENABLED")

    def disable_stranger_mode(self):
        self.stranger_mode = False
        log5("[FamilySafetyRules5_x] StrangerMode DISABLED")

    def enable_safe_mode(self):
        self.safe_mode = True
        log5("[FamilySafetyRules5_x] SafeMode ENABLED")

    def disable_safe_mode(self):
        self.safe_mode = False
        log5("[FamilySafetyRules5_x] SafeMode DISABLED")

    # ---------------------------------------------------------
    # MAIN CHECK
    # ---------------------------------------------------------
    def check(self, identity: str, text: str):
        """
        identity = OWNER / FAMILY / CHILD / STRANGER
        """

        t = (text or "").lower()

        # StrangerMode
        if identity == "STRANGER" or self.stranger_mode:
            return {
                "allowed": False,
                "reason": "StrangerMode: restricted for unknown users."
            }

        # SchoolMode
        if self.school_mode:
            if any(word in t for word in ["hra", "game", "porno", "sex"]):
                return {
                    "allowed": False,
                    "reason": "SchoolMode: non-educational content blocked."
                }

        # Restricted commands
        for cmd in self.restricted_commands:
            if cmd in t:
                return {
                    "allowed": False,
                    "reason": f"Restricted command blocked: {cmd}"
                }

        # SafeMode fallback
        if self.safe_mode:
            if any(word in t for word in ["delete", "shutdown", "kill"]):
                return {
                    "allowed": False,
                    "reason": "SafeMode: dangerous command blocked."
                }

        return {"allowed": True}
