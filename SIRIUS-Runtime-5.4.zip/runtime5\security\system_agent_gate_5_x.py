import logging
from runtime5.security.security_family_5_x import SecurityFamily5_x

logger = logging.getLogger("SystemAgentGate5_x")


class SystemAgentGate5_x:
    def __init__(self, config_path: str):
        self.security = SecurityFamily5_x(config_path)
        logger.info("[SystemAgentGate5.x] Initialized")

    def authorize(self, action: str, context: dict | None = None) -> str:
        """
        Centrálna brána pre System Agent 5.
        Vráti: ALLOW / LIMITED / DENY
        """
        decision = self.security.check(action, context)

        logger.info(f"[SystemAgentGate5.x] ACTION={action} → DECISION={decision}")

        return decision
