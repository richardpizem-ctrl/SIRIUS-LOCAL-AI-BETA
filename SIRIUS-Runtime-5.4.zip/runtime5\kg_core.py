from runtime5.logging_5 import log5
from runtime5.health_monitor_5 import HealthMonitor5
from runtime5.error_handler_5 import ErrorHandler5


class KGEntity:
    def __init__(self, name: str, attributes=None):
        self.name = name
        self.attributes = attributes or {}

    def to_dict(self):
        return {
            "name": self.name,
            "attributes": self.attributes
        }


class KGRelation:
    def __init__(self, source: str, relation: str, target: str):
        self.source = source
        self.relation = relation
        self.target = target

    def to_dict(self):
        return {
            "source": self.source,
            "relation": self.relation,
            "target": self.target
        }


class KnowledgeGraph:
    """
    Knowledge Graph Core for Runtime 5.x
    Clean, dependency‑free, no circular imports.
    """

    def __init__(self):
        self.entities = {}      # key: url/name (lowercase)
        self.relations = []     # list of KGRelation
        self.relation_index = {}  # NEW INDEX
        log5("[KnowledgeGraph] Initialized KG Core 5.x")

    # --------------------------------------------------------
    # ENTITY MANAGEMENT
    # --------------------------------------------------------
    def add_entity(self, name: str, attributes=None):
        def _exec():
            key = name.strip().lower()

            if key in self.entities:
                log5(f"[KG] Entity '{name}' already exists. Updating attributes.")
                self.entities[key].attributes.update(attributes or {})
            else:
                self.entities[key] = KGEntity(name, attributes)
                log5(f"[KG] Added entity: {name}")

        return ErrorHandler5.safe_execute(_exec, context=name)

    def get_entity(self, name: str):
        key = name.strip().lower()
        return self.entities.get(key)

    def get_all_entities(self):
        return self.entities

    # --------------------------------------------------------
    # ⭐ NEW — GET NEIGHBORS
    # --------------------------------------------------------
    def get_neighbors(self, entity: str):
        """
        Returns all nodes directly connected to the given entity.
        Includes outgoing and incoming relations.
        """
        key = entity.strip().lower()

        if key not in self.entities:
            return []

        neighbors = []

        # outgoing edges
        for rel in self.relations:
            if rel.source.lower() == key:
                neighbors.append({
                    "direction": "out",
                    "relation": rel.relation,
                    "target": rel.target
                })

        # incoming edges
        for rel in self.relations:
            if rel.target.lower() == key:
                neighbors.append({
                    "direction": "in",
                    "relation": rel.relation,
                    "source": rel.source
                })

        log5(f"[KG] get_neighbors('{entity}') → {len(neighbors)} neighbors")
        return neighbors

    # --------------------------------------------------------
    # LEVEL 1 METADATA
    # --------------------------------------------------------
    def add_metadata(self, data: dict):
        def _exec():
            if not data:
                log5("[KG] add_metadata called with empty data.")
                return False

            url = data.get("url")
            if not url:
                log5("[KG] add_metadata missing URL.")
                return False

            key = url.strip().lower()

            attributes = {
                "type": data.get("type", "web_metadata"),
                "level": data.get("level", 1),
                "title": data.get("title"),
                "summary": data.get("summary"),
                "timestamp": data.get("timestamp"),
                "source": data.get("source"),
                "meta": data.get("meta", {})
            }

            if key in self.entities:
                self.entities[key].attributes.update(attributes)
                log5(f"[KG] Updated metadata for: {url}")
            else:
                self.entities[key] = KGEntity(url, attributes)
                log5(f"[KG] Added metadata entity: {url}")

            return True

        return ErrorHandler5.safe_execute(_exec, context=data)

    # --------------------------------------------------------
    # RELATIONS (FIXED — NOW ADDS ENTITIES)
    # --------------------------------------------------------
    def add_relation(self, source: str, relation: str, target: str):
        def _exec():
            if not source or not target:
                raise ValueError("Relation requires both source and target.")

            s = source.strip().lower()
            t = target.strip().lower()

            # ⭐ ALWAYS ADD ENTITIES
            if s not in self.entities:
                self.entities[s] = KGEntity(source, {})
                log5(f"[KG] Auto-added missing entity: {source}")

            if t not in self.entities:
                self.entities[t] = KGEntity(target, {})
                log5(f"[KG] Auto-added missing entity: {target}")

            # Prevent duplicates
            for r in self.relations:
                if r.source.lower() == s and r.relation == relation and r.target.lower() == t:
                    log5(f"[KG] Relation already exists: {source} -[{relation}]-> {target}")
                    return

            rel = KGRelation(source, relation, target)
            self.relations.append(rel)

            # INDEX
            if s not in self.relation_index:
                self.relation_index[s] = []
            self.relation_index[s].append(rel)

            if t not in self.relation_index:
                self.relation_index[t] = []
            self.relation_index[t].append(rel)

            log5(f"[KG] Added relation: {source} -[{relation}]-> {target}")

        return ErrorHandler5.safe_execute(
            _exec,
            context={"source": source, "relation": relation, "target": target}
        )

    def get_relations(self, entity: str):
        def _exec():
            key = entity.strip().lower()

            # Fast path
            if key in self.relation_index:
                rels = [r.to_dict() for r in self.relation_index[key]]
                log5(f"[KG] Query relations (indexed) for '{entity}': {len(rels)} found")
                return rels

            # Fallback
            results = [
                r.to_dict()
                for r in self.relations
                if r.source.lower() == key or r.target.lower() == key
            ]

            log5(f"[KG] Query relations (fallback) for '{entity}': {len(results)} found")
            return results

        return ErrorHandler5.safe_execute(_exec, context=entity, fallback=[])

    # --------------------------------------------------------
    # SNAPSHOT
    # --------------------------------------------------------
    def snapshot(self):
        return {
            "entities": {k: e.to_dict() for k, e in self.entities.items()},
            "relations": [r.to_dict() for r in self.relations],
            "degraded": HealthMonitor5.is_degraded()
        }

    # --------------------------------------------------------
    # EXPORT / IMPORT
    # --------------------------------------------------------
    def export_json(self):
        return {
            "entities": {
                name: {"attributes": ent.attributes}
                for name, ent in self.entities.items()
            },
            "relations": [r.to_dict() for r in self.relations]
        }

    def import_json(self, data):
        self.entities = {}
        self.relations = []
        self.relation_index = {}

        for name, ent in data.get("entities", {}).items():
            self.add_entity(name, ent.get("attributes", {}))

        for r in data.get("relations", []):
            self.add_relation(r["source"], r["relation"], r["target"])
