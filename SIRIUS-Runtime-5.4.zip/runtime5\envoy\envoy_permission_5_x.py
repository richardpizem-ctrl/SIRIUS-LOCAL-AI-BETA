import logging
from dataclasses import dataclass
from typing import Dict, Any, Literal

# ⭐ NOVÝ IMPORT – tvoja SecurityFamily5
from runtime5.security.security_family_5 import SecurityFamily5

logger = logging.getLogger("EnvoyPermission5_x")

Decision = Literal["ALLOW", "DENY", "REVIEW", "LOG_ONLY"]


@dataclass
class EnvoyRequestContext:
    action: str
    identity: str | None = None
    channel: str | None = None
    source: str | None = None
    risk: str | None = None
    extra: Dict[str, Any] | None = None


class EnvoyPermission5_x:
    def __init__(self, config_path: str):

        # ⭐ Použijeme tvoju SecurityFamily5
        self.security = SecurityFamily5()
        logger.info("[EnvoyPermission5.x] Initialized")

        self.default_policy: Dict[str, Dict[str, Decision]] = {

            # ------------------------------------
            # VAULT
            # ------------------------------------
            "vault.read": {
                "OWNER": "ALLOW",
                "FAMILY": "ALLOW",
                "CHILD": "DENY",
                "GUEST": "DENY",
                "UNKNOWN": "DENY",
            },
            "vault.write": {
                "OWNER": "ALLOW",
                "FAMILY": "REVIEW",
                "CHILD": "DENY",
                "GUEST": "DENY",
                "UNKNOWN": "DENY",
            },
            "vault.delete": {
                "OWNER": "ALLOW",
                "FAMILY": "REVIEW",
                "CHILD": "DENY",
                "GUEST": "DENY",
                "UNKNOWN": "DENY",
            },
            "vault.clear": {
                "OWNER": "ALLOW",
                "FAMILY": "DENY",
                "CHILD": "DENY",
                "GUEST": "DENY",
                "UNKNOWN": "DENY",
            },

            # ------------------------------------
            # SYSTEM
            # ------------------------------------
            "system.shutdown": {
                "OWNER": "ALLOW",
                "FAMILY": "REVIEW",
                "CHILD": "DENY",
                "GUEST": "DENY",
                "UNKNOWN": "DENY",
            },
            "system.exec": {
                "OWNER": "ALLOW",
                "FAMILY": "REVIEW",
                "CHILD": "DENY",
                "GUEST": "DENY",
                "UNKNOWN": "DENY",
            },

            # ------------------------------------
            # ENVOY
            # ------------------------------------
            "envoy.lan_sync": {
                "OWNER": "ALLOW",
                "FAMILY": "ALLOW",
                "CHILD": "DENY",
                "GUEST": "DENY",
                "UNKNOWN": "DENY",
            },
            "envoy.remote_call": {
                "OWNER": "REVIEW",
                "FAMILY": "DENY",
                "CHILD": "DENY",
                "GUEST": "DENY",
                "UNKNOWN": "DENY",
            },

            # ------------------------------------
            # KNOWLEDGE GRAPH (KG)
            # ------------------------------------
            "kg.add_fact": {
                "OWNER": "ALLOW",
                "FAMILY": "REVIEW",
                "CHILD": "DENY",
                "GUEST": "DENY",
                "UNKNOWN": "DENY",
            },
            "kg.add_relation": {
                "OWNER": "ALLOW",
                "FAMILY": "REVIEW",
                "CHILD": "DENY",
                "GUEST": "DENY",
                "UNKNOWN": "DENY",
            },
            "kg.query": {
                "OWNER": "ALLOW",
                "FAMILY": "ALLOW",
                "CHILD": "REVIEW",
                "GUEST": "DENY",
                "UNKNOWN": "DENY",
            },

            # ⭐ NOVÉ: KG NEIGHBORS
            "kg.neighbors": {
                "OWNER": "ALLOW",
                "FAMILY": "ALLOW",
                "CHILD": "DENY",
                "GUEST": "DENY",
                "UNKNOWN": "DENY",
            },
        }

    def _normalize_identity(self, identity: str | None) -> str:
        if not identity:
            return "UNKNOWN"
        ident = identity.upper()
        if ident in ("OWNER", "FAMILY", "CHILD", "GUEST"):
            return ident
        return "UNKNOWN"

    def _base_decision(self, action: str, identity: str) -> Decision:
        policy = self.default_policy.get(action)
        if not policy:
            return "REVIEW"
        return policy.get(identity, "DENY")

    def _apply_risk_adjustment(self, decision: Decision, risk: str | None) -> Decision:
        if risk is None:
            return decision
        r = risk.upper()
        if r == "LOW":
            return decision
        if r == "MEDIUM":
            if decision == "ALLOW":
                return "REVIEW"
            return decision
        if r == "HIGH":
            if decision in ("ALLOW", "REVIEW"):
                return "REVIEW"
            return "DENY"
        return decision

    def _apply_channel_constraints(self, decision: Decision, channel: str | None) -> Decision:
        if channel is None:
            return decision
        ch = channel.upper()
        if ch == "LOCAL":
            return decision
        if ch == "LAN":
            return decision
        if ch == "REMOTE":
            if decision == "ALLOW":
                return "REVIEW"
            return decision
        return decision

    def check(self, action: str, identity: str | None = None,
              context: dict | EnvoyRequestContext | None = None) -> Decision:

        ident = self._normalize_identity(identity)

        # ⭐ SECURITY FAMILY CHECK
        sf_decision = self.security.check_permission(ident, action)

        if sf_decision == "ALLOW":
            return "ALLOW"

        if sf_decision == "DENY":
            return "DENY"

        # ⭐ ak SecurityFamily nepozná → pokračujeme default policy
        if isinstance(context, EnvoyRequestContext):
            channel = context.channel
            risk = context.risk
        else:
            channel = (context or {}).get("channel") if isinstance(context, dict) else None
            risk = (context or {}).get("risk") if isinstance(context, dict) else None

        base = self._base_decision(action, ident)
        after_risk = self._apply_risk_adjustment(base, risk)
        final = self._apply_channel_constraints(after_risk, channel)

        logger.info(
            f"[EnvoyPermission5.x] action={action} identity={ident} "
            f"channel={channel} risk={risk} -> {final}"
        )
        return final
