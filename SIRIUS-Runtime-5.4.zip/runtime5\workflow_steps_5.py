from runtime5.logging_5 import log5
from runtime5.error_handler_5 import ErrorHandler5
from runtime5.envoy_step_fetch_5 import EnvoyStepFetch5
from runtime5.envoy_step_execute_5 import EnvoyStepExecute5
from runtime5.kg_core import KnowledgeGraph


# --------------------------------------------------------
# WORKFLOW CONTINUE (default fallback)
# --------------------------------------------------------
class WorkflowStepContinue5:
    """
    Minimal workflow step for WORKFLOW_CONTINUE.
    Does nothing, prevents workflow crashes.
    """

    name = "WORKFLOW_CONTINUE"

    def execute(self, reasoning_output: dict):
        log5("[WorkflowStepContinue5] Executing WORKFLOW_CONTINUE step")
        return {
            "status": "ok",
            "reasoning": reasoning_output,
            "notes": "No workflow action required."
        }


# --------------------------------------------------------
# ENVOY LEVEL 1 → KG STORE
# --------------------------------------------------------
class EnvoyStepLevel1:
    """
    Stores Level 1 metadata into the Knowledge Graph.
    Triggered after ENVOY_EXECUTE.
    """

    name = "ENVOY_LEVEL1"

    def execute(self, reasoning_output: dict):
        log5("[EnvoyStepLevel1] Executing ENVOY_LEVEL1 step")

        result = reasoning_output.get("result", {})
        level1 = result.get("level1")

        if not level1:
            log5("[EnvoyStepLevel1] No Level 1 metadata found.")
            return {
                "status": "no-level1",
                "notes": "No Level 1 metadata in reasoning output."
            }

        kg = KnowledgeGraph()
        kg.add_metadata(level1)

        log5(f"[EnvoyStepLevel1] Stored Level 1 metadata for URL: {level1.get('url')}")

        return {
            "status": "stored",
            "entity": level1.get("url"),
            "notes": "Level 1 metadata stored in KG."
        }


# --------------------------------------------------------
# KG NEIGHBORS – nový workflow krok
# --------------------------------------------------------
class WorkflowStepKGNeighbors5:
    """
    Workflow krok pre KG neighbors operáciu.
    Volá KGQuery5.neighbors(entity) a vráti výsledok.
    """

    name = "KG_NEIGHBORS"

    def __init__(self, kg_query):
        self.kg_query = kg_query
        log5("[WorkflowStepKGNeighbors5] Initialized")

    def execute(self, entity: str):
        log5(f"[WorkflowStepKGNeighbors5] Executing KG_NEIGHBORS for entity={entity}")

        if entity is None:
            log5("[WorkflowStepKGNeighbors5] Missing entity")
            return {"status": "ERROR", "reason": "missing_entity"}

        result = self.kg_query.neighbors(entity)

        return {
            "status": "OK",
            "entity": entity,
            "neighbors": result
        }


# --------------------------------------------------------
# REGISTRY
# --------------------------------------------------------
class WorkflowStepRegistry5:
    """
    Registers all workflow steps for Runtime 5.x
    """

    def __init__(self):
        self.steps = {}

    def register(self, name: str, step):
        self.steps[name] = step
        log5(f"[WorkflowStepRegistry5] Registered step: {name}")

    def get_step(self, name: str):
        return self.steps.get(name)

    def init_defaults(self):
        # Default fallback
        self.register("WORKFLOW_CONTINUE", WorkflowStepContinue5())

        # ENVOY steps
        self.register("ENVOY_FETCH", EnvoyStepFetch5())
        self.register("ENVOY_EXECUTE", EnvoyStepExecute5())

        # NEW: Level 1 → KG
        self.register("ENVOY_LEVEL1", EnvoyStepLevel1())

        # ⭐ NEW: KG NEIGHBORS
        # POZOR: kg_query musíš sem poslať z runtime_core pri inicializácii
        # (rovnako ako CompareEngine5, EnvoyFetch, EnvoyExecute)
        try:
            from runtime5.kg.kg_query_5 import KGQuery5
            kg = KnowledgeGraph()
            kg_query = KGQuery5(kg)
            self.register("KG_NEIGHBORS", WorkflowStepKGNeighbors5(kg_query))
        except Exception as e:
            log5(f"[WorkflowStepRegistry5] Failed to register KG_NEIGHBORS: {e}")

        log5("[WorkflowStepRegistry5] Default steps initialized")
