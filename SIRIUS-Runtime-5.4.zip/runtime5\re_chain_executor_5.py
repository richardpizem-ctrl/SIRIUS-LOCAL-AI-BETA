# runtime5/re_chain_executor_5.py

from runtime5.intent_resolver_5 import IntentResolver5
from runtime5.context_builder_5 import ContextBuilder5
from runtime5.reasoning_engine_5 import ReasoningEngine5
from runtime5.kg_core import KnowledgeGraph
from runtime5.kg_reasoner import KGReasoner
from runtime5.kg_router import KGRouter
from runtime5.logging_5 import log5

from runtime5.health_monitor_5 import HealthMonitor5
from runtime5.system_hooks_5 import SystemHooks5
from runtime5.error_handler_5 import ErrorHandler5


class REChainExecutor5:
    """
    Stabilizovaná reasoning pipeline pre Runtime 5.x.
    """

    def __init__(self, kg: KnowledgeGraph):
        self.kg = kg

        # Intent resolver
        self.intent_resolver = IntentResolver5()

        # Context builder
        self.context_builder = ContextBuilder5()

        # KG Reasoner + Router (NOVÉ)
        self.kg_reasoner = KGReasoner(kg)
        self.kg_router = KGRouter(kg)

        # ReasoningEngine5 teraz potrebuje 3 argumenty
        self.reasoning_engine = ReasoningEngine5(
            kg,
            self.kg_reasoner,
            self.kg_router
        )

        log5("[REChainExecutor5] Initialized reasoning pipeline.")

    # --------------------------------------------------------
    # EXECUTE PIPELINE
    # --------------------------------------------------------
    def execute(self, text: str):
        log5(f"[REChain] Input text: {text}")

        def _exec():
            # 1. Intent resolution
            intent = self.intent_resolver.resolve(text)
            log5(f"[REChain] Resolved intent: {intent}")

            # 2. Context building
            context = self.context_builder.build(text)
            log5(f"[REChain] Built context: {context}")

            # 3. Reasoning Engine execution
            result = self.reasoning_engine.process(intent, entity=text)
            log5(f"[REChain] Reasoning result: {result}")

            output = {
                "intent": intent,
                "context": context,
                "result": result,
                "degraded": HealthMonitor5.is_degraded()
            }

            log5(f"[REChain] Final reasoning output: {output}")
            HealthMonitor5.record_success()
            return output

        return ErrorHandler5.safe_execute(
            _exec,
            context={"input": text},
            fallback={
                "intent": None,
                "context": None,
                "result": None,
                "error": "Reasoning pipeline failed.",
                "degraded": HealthMonitor5.is_degraded()
            }
        )
