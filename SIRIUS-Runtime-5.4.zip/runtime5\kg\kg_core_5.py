import logging
from typing import Dict, List, Any

logger = logging.getLogger("KnowledgeGraph5")


class KnowledgeGraph5:
    """
    Jednoduchý in‑memory Knowledge Graph pre Runtime 5.x

    OPRAVENÁ ŠTRUKTÚRA:
        facts: {
            subject: value
        }

        relations: [
            {"subject": ..., "relation": ..., "object": ...}
        ]
    """

    def __init__(self):
        # Fakty: subject -> value
        self.facts: Dict[str, Any] = {}

        # Relácie: zoznam dictov
        self.relations: List[Dict[str, str]] = []

        logger.info("[KnowledgeGraph5] Initialized")

    # -----------------------------
    # FACTS
    # -----------------------------
    def add_fact(self, subject: str, fact: str, value: Any):
        """
        Uloží fakt v tvare:
            sky -> blue

        NIE:
            sky -> {"sky": "blue"}
        """
        logger.info(f"[KnowledgeGraph5] add_fact subject={subject} fact={fact} value={value}")
        self.facts[subject] = value

    def get_facts(self, subject: str) -> Dict[str, Any]:
        """
        Vráti fakty v tvare:
            {"sky": "blue"}
        """
        if subject in self.facts:
            return {subject: self.facts[subject]}
        return {}

    # -----------------------------
    # RELATIONS
    # -----------------------------
    def add_relation(self, subject: str, relation: str, obj: str):
        logger.info(f"[KnowledgeGraph5] add_relation {subject} -[{relation}]-> {obj}")
        self.relations.append({
            "subject": subject,
            "relation": relation,
            "object": obj
        })

    def get_relations_from(self, subject: str) -> List[Dict[str, str]]:
        return [
            r for r in self.relations
            if r["subject"] == subject
        ]

    def get_relations_between(self, subject: str, obj: str) -> List[Dict[str, str]]:
        return [
            r for r in self.relations
            if r["subject"] == subject and r["object"] == obj
        ]

    # ⭐ DOPLNENÉ — KRITICKÁ METÓDA PRE KGAutoLinker5 ⭐
    def get_relations(self, subject: str = None) -> List[Dict[str, str]]:
        """
        Vráti všetky relácie alebo len pre konkrétny subjekt.
        Toto potreboval AutoLinker, aby prestal hlásiť chybu.
        """
        if subject is None:
            return self.relations
        return [r for r in self.relations if r["subject"] == subject]

    # -----------------------------
    # SIMPLE REASONING HELPERS
    # -----------------------------
    def paths_between(self, a: str, b: str, max_depth: int = 3) -> List[List[Dict[str, str]]]:
        """
        Nájde jednoduché cesty medzi a a b (do max_depth).
        """
        paths: List[List[Dict[str, str]]] = []

        def dfs(current: str, target: str, depth: int, path: List[Dict[str, str]]):
            if depth > max_depth:
                return
            for r in self.relations:
                if r["subject"] == current:
                    new_path = path + [r]
                    if r["object"] == target:
                        paths.append(new_path)
                    else:
                        dfs(r["object"], target, depth + 1, new_path)

        dfs(a, b, 0, [])
        return paths
