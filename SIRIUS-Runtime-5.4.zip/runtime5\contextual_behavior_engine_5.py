# runtime5/contextual_behavior_engine_5.py

import re
from runtime5.logging_5 import log5

class ContextualBehaviorEngine5:
    """
    Context scoring engine for SIRIUS Runtime 5.x
    Produces:
    - context_score (0–100)
    - tone (neutral / positive / aggressive)
    - risk (low / medium / high)
    - intent_type (general / command / question / system)
    """

    def __init__(self):
        log5("[ContextualBehaviorEngine5] Initialized")

    # ---------------------------------------------------------
    # MAIN ENTRY
    # ---------------------------------------------------------
    def analyze(self, text: str) -> dict:
        t = text.lower().strip()

        # -----------------------------
        # TONE DETECTION
        # -----------------------------
        aggressive_words = ["fuck", "shit", "kokot", "debil", "idiot", "kurva"]
        positive_words = ["super", "ďakujem", "dobre", "ok", "jasné"]

        tone = "neutral"
        if any(w in t for w in aggressive_words):
            tone = "aggressive"
        elif any(w in t for w in positive_words):
            tone = "positive"

        # -----------------------------
        # RISK DETECTION
        # -----------------------------
        high_risk = ["kill", "suicide", "shoot", "porno", "drugs"]
        medium_risk = ["hack", "bypass", "exploit"]

        risk = "low"
        if any(w in t for w in high_risk):
            risk = "high"
        elif any(w in t for w in medium_risk):
            risk = "medium"

        # -----------------------------
        # INTENT TYPE
        # -----------------------------
        if t.endswith("?"):
            intent_type = "question"
        elif t.startswith("enable ") or t.startswith("disable "):
            intent_type = "system"
        elif re.match(r"^[a-z]+$", t):
            intent_type = "general"
        else:
            intent_type = "general"

        # -----------------------------
        # CONTEXT SCORE
        # -----------------------------
        score = 80

        if tone == "aggressive":
            score -= 20
        if risk == "high":
            score -= 30
        if risk == "medium":
            score -= 10

        score = max(0, min(100, score))

        return {
            "context_score": score,
            "tone": tone,
            "risk": risk,
            "intent_type": intent_type
        }
