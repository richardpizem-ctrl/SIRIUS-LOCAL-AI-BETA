# runtime5/kg_router.py

from runtime5.kg_core import KnowledgeGraph
from runtime5.kg_reasoner import KGReasoner
from runtime5.logging_5 import log5
from runtime5.error_handler_5 import ErrorHandler5
from runtime5.health_monitor_5 import HealthMonitor5
from runtime5.system_hooks_5 import SystemHooks5


class KGRouter:
    """
    KG Router 5.x
    - routes intents to KG reasoning
    - uses shared KGReasoner
    - diagnostics + degraded mode awareness
    """

    def __init__(self, kg: KnowledgeGraph, reasoner: KGReasoner = None):
        self.kg = kg
        self.reasoner = reasoner if reasoner is not None else KGReasoner(kg)

        log5("[KGRouter] Initialized KG router 5.x")

    # --------------------------------------------------------
    # ROUTE INTENT
    # --------------------------------------------------------
    def route_intent(self, intent: str):
        """
        Routes intent to KG reasoning or default path.
        """
        def _exec():
            if not intent:
                return "DEFAULT"

            text = str(intent).lower()

            # KG reasoning triggers
            if text.startswith("kg "):
                return "KG_REASONING"

            if text in ("kg-relate", "kg-relations"):
                return "KG_RELATIONS"

            if text.startswith("kg view"):
                return "KG_VIEW"

            return "DEFAULT"

        return ErrorHandler5.safe_execute(
            _exec,
            context=intent,
            fallback="DEFAULT"
        )
