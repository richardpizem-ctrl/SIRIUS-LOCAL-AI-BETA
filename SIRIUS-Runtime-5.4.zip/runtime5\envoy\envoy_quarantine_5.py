import logging
from datetime import datetime
from pathlib import Path
import json

logger = logging.getLogger("EnvoyQuarantine5")

class EnvoyQuarantine5:
    """
    ENVOY karanténa pre Runtime 5.x
    - ukladá blokované alebo rizikové akcie
    - nič nevykonáva
    - čaká na manuálne schválenie OWNER-om
    """

    def __init__(self, quarantine_path: str = "data/envoy_quarantine.json"):
        self.quarantine_path = Path(quarantine_path)
        self.quarantine_path.parent.mkdir(parents=True, exist_ok=True)

        if not self.quarantine_path.exists():
            self.quarantine_path.write_text("[]", encoding="utf-8")

        logger.info("[EnvoyQuarantine5] Initialized")

    def add(self, action: str, identity: str, payload: dict, reason: str):
        """
        Uloží akciu do karantény.
        """
        entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "action": action,
            "identity": identity,
            "payload": payload,
            "reason": reason
        }

        data = json.loads(self.quarantine_path.read_text(encoding="utf-8"))
        data.append(entry)
        self.quarantine_path.write_text(json.dumps(data, indent=4), encoding="utf-8")

        logger.warning(f"[EnvoyQuarantine5] QUARANTINED action={action} identity={identity} reason={reason}")

    def list(self):
        """
        Vráti zoznam všetkých položiek v karanténe.
        """
        return json.loads(self.quarantine_path.read_text(encoding="utf-8"))

    def clear(self):
        """
        Vymaže karanténu.
        """
        self.quarantine_path.write_text("[]", encoding="utf-8")
        logger.info("[EnvoyQuarantine5] Cleared")
