# runtime5/runtime5.py

from runtime5.kg_core import KnowledgeGraph
from runtime5.logging_5 import log5
from runtime5.error_handler_5 import ErrorHandler5
from runtime5.health_monitor_5 import HealthMonitor5

# ⭐ Import RuntimeCore
from runtime5.runtime_core import RuntimeCore


class Runtime5:
    """
    Wrapper orchestrator for Runtime 5.x
    Redirects all processing to RuntimeCore.
    """

    def __init__(self, kg: KnowledgeGraph = None):
        log5("[Runtime5] Initializing wrapper for RuntimeCore")

        # Knowledge Graph (shared)
        self.kg = kg if kg is not None else KnowledgeGraph()

        # ⭐ Create RuntimeCore instance
        self.core = RuntimeCore()

        log5("[Runtime5] RuntimeCore attached.")

    # --------------------------------------------------------
    # PUBLIC SAFE ENTRYPOINT
    # --------------------------------------------------------
    def process(self, text: str):
        """
        Public safe entrypoint.
        Entire pipeline is handled by RuntimeCore.
        """

        def _exec():
            # ⭐ Redirect to RuntimeCore
            result = self.core.process({"input": text})
            HealthMonitor5.record_success()
            return result

        return ErrorHandler5.safe_execute(
            _exec,
            context={"input": text},
            fallback={
                "reasoning": None,
                "workflow": None,
                "error": "Runtime5 wrapper failed.",
                "degraded": HealthMonitor5.is_degraded()
            }
        )
