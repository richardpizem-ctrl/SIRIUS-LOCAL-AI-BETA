import re
import unicodedata
from typing import Dict, Any


class ParserD:
    """
    Parser D – centrálna vrstva:
    - normalizácia textu
    - základná intent klasifikácia
    - extrakcia entít (čísla, percentá, objekty, príkazy)
    """

    def __init__(self):
        self.intent_patterns = {
            "info": [
                r"co je",
                r"vysvetli",
                r"popis",
                r"info",
                r"informacie",
                r"ako funguje",
            ],
            "compare": [
                r"porovnaj",
                r"vs ",
                r"rozdiel medzi",
                r"ktore je lepsie",
            ],
            "list": [
                r"zoznam",
                r"vypis",
                r"ukaz",
                r"moznosti",
            ],
            "command": [
                r"spusti",
                r"zapni",
                r"vypni",
                r"uloz",
                r"otvor",
                r"restartuj",
            ],
            "debug": [
                r"logy",
                r"debug",
                r"chybove hlasky",
                r"stacktrace",
            ],
        }

        # stopwords pre extrakciu objektov
        self.stopwords = {
            "a", "alebo", "ale", "co", "ako", "je", "ta", "to", "sa", "si",
            "porovnaj", "vysvetli", "ukaz", "zoznam", "prosim", "prosím",
            "ahoj", "daj", "mi", "na", "do", "z", "od", "pre", "vs"
        }

    # -----------------------------
    #  NORMALIZÁCIA DOTAZU
    # -----------------------------
    def normalize(self, text: str) -> str:
        if not text:
            return ""

        text = unicodedata.normalize("NFKD", text)
        text = "".join([c for c in text if not unicodedata.combining(c)])
        text = text.lower()
        text = re.sub(r"[^a-z0-9\s]", " ", text)
        text = re.sub(r"\s+", " ", text).strip()

        return text

    # -----------------------------
    #  INTENT KLASIFIKÁCIA
    # -----------------------------
    def classify_intent(self, normalized: str) -> str:
        if not normalized:
            return "unknown"

        for intent, patterns in self.intent_patterns.items():
            for pattern in patterns:
                if pattern in normalized:
                    return intent

        if normalized.startswith(("spusti", "zapni", "vypni", "otvor", "uloz")):
            return "command"

        if normalized.startswith(("co je", "ako funguje", "vysvetli")):
            return "info"

        return "unknown"

    # -----------------------------
    #  ENTITY EXTRACTOR (ROZŠÍRENÝ)
    # -----------------------------
    def extract_entities(self, normalized: str) -> Dict[str, Any]:
        entities: Dict[str, Any] = {}

        if not normalized:
            return entities

        # 1. čísla
        numbers = re.findall(r"\b\d+\b", normalized)
        if numbers:
            entities["numbers"] = [int(n) for n in numbers]

        # 2. percentá
        percents = re.findall(r"\b\d+\s*percent", normalized)
        if percents:
            entities["percents"] = percents

        # 3. jednoduché príkazy
        command_targets = []
        for verb in ["spusti", "zapni", "vypni", "otvor", "uloz", "restartuj"]:
            if verb in normalized:
                parts = normalized.split(verb, 1)
                if len(parts) > 1:
                    target = parts[1].strip()
                    if target:
                        command_targets.append({"verb": verb, "target": target})

        if command_targets:
            entities["commands"] = command_targets

        # 4. extrakcia objektov (produkty, značky, pojmy)
        tokens = normalized.split()
        object_candidates = []

        for t in tokens:
            if len(t) > 2 and t not in self.stopwords and not t.isdigit():
                object_candidates.append(t)

        if object_candidates:
            entities["objects"] = object_candidates

        return entities

    # -----------------------------
    #  HLAVNÁ METÓDA PARSE()
    # -----------------------------
    def parse(self, text: str) -> Dict[str, Any]:
        normalized = self.normalize(text)
        intent = self.classify_intent(normalized)
        entities = self.extract_entities(normalized)

        confidence = 0.0
        if intent != "unknown":
            confidence = 0.6
            if entities:
                confidence = 0.8

        return {
            "raw": text,
            "normalized": normalized,
            "intent": intent,
            "entities": entities,
            "confidence": confidence,
        }
