import logging
from runtime5.security.identity_engine_3_1 import IdentityEngine3_1
from runtime5.security.permission_matrix_5_x import PermissionMatrix5_x
from runtime5.security.time_limits_5_x import TimeLimits5_x

logger = logging.getLogger("SecurityFamily5.x")


class SecurityFamily5_x:
    """
    Bezpečnostná vrstva pre Runtime 5.x
    """

    SAFE_ACTIONS = {
        "kg.neighbors",
        "kg.query",
        "kg.add_fact",
        "kg.add_relation",
        "ENVOY_FETCH",
        "ENVOY_EXECUTE",
        "WORKFLOW_CONTINUE"
    }

    SCHOOL_ACTIONS = {
        "kg.neighbors",
        "kg.query",
        "ocr.analyze",
        "ocr.homework",
        "math.solve",
        "math.steps",
        "language.translate",
        "language.explain",
        "science.explain",
        "school.check",
        "school.task",
        "WORKFLOW_CONTINUE"
    }

    def __init__(self, config_path: str):
        self.identity_engine = IdentityEngine3_1(config_path)
        self.permission_matrix = PermissionMatrix5_x()

        # TIME LIMITS v2
        self.time_limits = TimeLimits5_x({
            "CHILD": {
                "daily_minutes": 120,
                "night_start": 21,
                "night_end": 7,
                "school_mode_limit": 180
            }
        })

        logger.info("[SecurityFamily5.x] Initialized")

    def check(self, action: str, context: dict | None = None) -> str:
        """
        Centrálna bezpečnostná funkcia.
        Vráti: ALLOW / DENY
        """

        context = context or {}
        identity = self.identity_engine.get_identity(context)

        # ---------------------------------------------------------
        # TIME LIMITS ENFORCEMENT (má prioritu nad všetkým)
        # ---------------------------------------------------------
        if self.time_limits.should_block(identity, context.get("school_mode", False)):
            return "DENY"

        # ---------------------------------------------------------
        # SCHOOL MODE v2 → absolútna priorita
        # ---------------------------------------------------------
        if context.get("school_mode", False):
            if action in self.SCHOOL_ACTIONS:
                return "ALLOW"
            return "DENY"

        # ---------------------------------------------------------
        # OWNER → plný prístup
        # ---------------------------------------------------------
        if identity == "OWNER":
            return "ALLOW"

        # ---------------------------------------------------------
        # FAMILY → bezpečné akcie
        # ---------------------------------------------------------
        if identity == "FAMILY":
            if action in self.SAFE_ACTIONS:
                return "ALLOW"
            return "DENY"

        # ---------------------------------------------------------
        # STRANGER → ultra-safe režim
        # ---------------------------------------------------------
        if identity == "STRANGER":
            SAFE_STRANGER = {
                "kg.neighbors",
                "kg.query",
                "WORKFLOW_CONTINUE"
            }
            if action in SAFE_STRANGER:
                return "ALLOW"
            return "DENY"

        # ---------------------------------------------------------
        # GUEST → ešte prísnejší režim
        # ---------------------------------------------------------
        if identity == "GUEST":
            SAFE_GUEST = {
                "kg.neighbors",
                "kg.query"
            }
            if action in SAFE_GUEST:
                return "ALLOW"
            return "DENY"

        # ---------------------------------------------------------
        # Neznáme identity → blokovať
        # ---------------------------------------------------------
        return "DENY"
