# runtime5/self_repair_5.py

from runtime5.logging_5 import log5


class SelfRepair5:
    """
    Základná self-repair vrstva pre Runtime 5.4.
    ŠTANDARDNÁ VERZIA:
    - loguje chyby
    - vie označiť runtime ako 'degraded'
    - vie navrhnúť jednoduchý reset cyklu
    """

    def __init__(self):
        self.degraded = False
        log5("[SelfRepair5] Initialized self-repair layer 5.4")

    def report_error(self, context: str, error: Exception):
        log5(f"[SelfRepair5] ERROR in {context}: {repr(error)}")
        self.degraded = True

    def recover_if_possible(self):
        """
        Základná stratégia:
        - ak je degraded == True → pokus o návrat do normálu
        - v štandardnej verzii len log + reset flagu
        """
        if self.degraded:
            log5("[SelfRepair5] Attempting basic recovery → marking runtime as healthy again.")
            self.degraded = False
            return {"status": "recovered"}

        return {"status": "ok"}

    # ---------------------------------------------------------
    # 🔥 SELF‑REPAIR ZÁKLAD (NOVÉ)
    # ---------------------------------------------------------
    def handle_failure(self, context, reason):
        # Log zásahu
        log5("[SelfRepair5] FAILURE detected → applying SAFE_ROUTE fallback")

        # Nastav fallback route
        context["route"] = "SAFE_ROUTE"
        context["degraded"] = True

        # Zapíš dôvod
        context["self_repair_reason"] = reason

        return context
