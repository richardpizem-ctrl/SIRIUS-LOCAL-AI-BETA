import logging

logger = logging.getLogger("KGAutoLinker5")


class KGAutoLinker5:
    """
    Jednoduchý auto-linker pre KG 5.x

    Cieľ:
    - dopĺňať odvodené relácie
    - udržiavať symetriu / inverzie tam, kde to dáva zmysel
    """

    def __init__(self, kg):
        """
        kg: inštancia KnowledgeGraph5
        """
        self.kg = kg

        # definícia jednoduchých pravidiel
        self.symmetric_relations = {
            "friend_of",
            "connected_to",
            "related_to",
        }

        self.inverse_relations = {
            "parent_of": "child_of",
            "child_of": "parent_of",
            "part_of": "has_part",
            "has_part": "part_of",
            "owns": "owned_by",
            "owned_by": "owns",
            "is_above": "is_below",
            "is_below": "is_above",
        }

    def process_new_relation(self, subject: str, relation: str, obj: str):
        """
        Zavolá sa vždy, keď sa pridá nová relácia do KG.
        Tu môžeme dopĺňať:
        - symetrické relácie
        - inverzné relácie
        """
        logger.info(f"[KGAutoLinker5] process_new_relation {subject} -[{relation}]-> {obj}")

        # symetrické relácie: A -[rel]-> B => B -[rel]-> A
        if relation in self.symmetric_relations:
            self._ensure_relation(obj, relation, subject)

        # inverzné relácie: A -[rel]-> B => B -[inv_rel]-> A
        if relation in self.inverse_relations:
            inv_rel = self.inverse_relations[relation]
            self._ensure_relation(obj, inv_rel, subject)

    def _ensure_relation(self, subject: str, relation: str, obj: str):
        """
        Pridá reláciu len vtedy, ak ešte neexistuje.
        Predpoklad: KG má metódu get_relations(subject) -> list[(subj, rel, obj)]
        """
        try:
            existing = self.kg.get_relations(subject)
        except AttributeError:
            # fallback: ak nemáme get_relations, proste to pridáme
            logger.warning("[KGAutoLinker5] KG nemá get_relations(), pridávam bez kontroly duplicít")
            self.kg.add_relation(subject, relation, obj)
            return

        for (s, r, o) in existing:
            if s == subject and r == relation and o == obj:
                logger.info(f"[KGAutoLinker5] relácia už existuje: {subject} -[{relation}]-> {obj}")
                return

        logger.info(f"[KGAutoLinker5] pridávam odvodenú reláciu: {subject} -[{relation}]-> {obj}")
        self.kg.add_relation(subject, relation, obj)
