import logging
from typing import Any, Dict, List

from runtime5.agent.agent_kg_bridge_5 import AgentKGBridge5

logger = logging.getLogger("KGReasoning5")


class KGReasoning5:
    """
    KG Reasoning Engine pre Runtime 5.x

    Nepristupuje na KG priamo.
    Všetko ide cez:
        AGENT → AgentKGBridge5 → ENVOY → Permission → Router → KG

    Tento modul rieši:
    - dotazy typu: "čo vieme o X?"
    - dotazy typu: "ako súvisí A s B?"
    - jednoduché reasoning nad faktami a reláciami (na úrovni dotazov)
    """

    def __init__(self, config_path: str, identity: str = "OWNER"):
        """
        identity = kto sa pýta (OWNER / FAMILY / CHILD / GUEST)
        """
        self.identity = identity
        self.bridge = AgentKGBridge5(config_path)
        logger.info(f"[KGReasoning5] Initialized for identity={identity}")

    # ----------------------------------------
    # ZÁKLADNÉ DOTAZY
    # ----------------------------------------
    def facts_about(self, subject: str) -> Dict[str, Any]:
        """
        Vráti všetky fakty o danom subjekte.
        """
        query = {
            "type": "facts_about",
            "subject": subject,
        }
        logger.info(f"[KGReasoning5] facts_about subject={subject}")
        return self.bridge.query(self.identity, query)

    def relations_from(self, subject: str) -> Dict[str, Any]:
        """
        Vráti všetky relácie, kde je subjekt = subject.
        """
        query = {
            "type": "relations_from",
            "subject": subject,
        }
        logger.info(f"[KGReasoning5] relations_from subject={subject}")
        return self.bridge.query(self.identity, query)

    def relations_between(self, subject: str, obj: str) -> Dict[str, Any]:
        """
        Vráti všetky relácie medzi subject a object.
        """
        query = {
            "type": "relations_between",
            "subject": subject,
            "object": obj,
        }
        logger.info(f"[KGReasoning5] relations_between subject={subject} object={obj}")
        return self.bridge.query(self.identity, query)

    # ----------------------------------------
    # JEDNODUCHÝ REASONING
    # ----------------------------------------
    def why_related(self, a: str, b: str) -> Dict[str, Any]:
        """
        Pokus o vysvetlenie: prečo sú A a B súvisiace?
        (Na úrovni KG: nájdi cesty / relácie medzi A a B)
        """
        query = {
            "type": "why_related",
            "a": a,
            "b": b,
        }
        logger.info(f"[KGReasoning5] why_related a={a} b={b}")
        return self.bridge.query(self.identity, query)

    def expand_concept(self, concept: str) -> Dict[str, Any]:
        """
        Rozšíri koncept:
        - nájde fakty o ňom
        - nájde relácie z neho
        - vráti to ako jeden balík
        """
        query = {
            "type": "expand_concept",
            "concept": concept,
        }
        logger.info(f"[KGReasoning5] expand_concept concept={concept}")
        return self.bridge.query(self.identity, query)

    # ----------------------------------------
    # RAW QUERY (fallback)
    # ----------------------------------------
    def raw_query(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Priamy dotaz do KG cez ENVOY, ak chceš niečo custom.
        """
        logger.info(f"[KGReasoning5] raw_query payload_keys={list(payload.keys())}")
        return self.bridge.query(self.identity, payload)
