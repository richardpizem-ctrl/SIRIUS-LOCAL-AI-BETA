# runtime5/envoy_step_execute_5.py

from runtime5.logging_5 import log5


class EnvoyStepExecute5:
    """
    ENVOY_EXECUTE – MINIMÁLNA verzia pre Runtime 5.4
    ------------------------------------------------
    - NEVOLÁ sieť
    - NEVOLÁ EnvoyClient5
    - NEVOLÁ PermissionLayer
    - NEUKLADÁ do KG
    - NESKÚŠA generovať žiadne auto-relations
    - NESIAHA na karanténu
    - LEN SIMULUJE vykonanie nad ENVOY_FETCH výstupom

    Cieľ:
    - Workflow dostane "execute_ready"
    - Runtime zostáva stabilný
    - Žiadne vedľajšie efekty
    """

    def __init__(self, runtime):
        self.runtime = runtime

    def execute(self, reasoning_output):
        log5("[ENVOY_EXECUTE] Starting minimal simulated execute step")

        # Normalizovaný objekt z ENVOY_FETCH
        normalized = reasoning_output.get("normalized")
        url = reasoning_output.get("url") or reasoning_output.get("entity")

        # -----------------------------------------------------
        # 1. Ak nemáme normalizovaný objekt → NOOP
        # -----------------------------------------------------
        if not normalized:
            log5("[ENVOY_EXECUTE] No normalized payload → NOOP execute")
            return {
                "status": "execute_noop",
                "url": url,
                "result": None,
                "notes": "ENVOY_EXECUTE minimal: nothing to execute."
            }

        # -----------------------------------------------------
        # 2. Simulované vykonanie
        # -----------------------------------------------------
        log5("[ENVOY_EXECUTE] Simulated execution over normalized payload")

        return {
            "status": "execute_ready",
            "url": url,
            "result": normalized,
            "notes": "ENVOY_EXECUTE minimal: simulated execution completed."
        }
