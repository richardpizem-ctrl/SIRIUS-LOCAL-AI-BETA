from runtime5.workflow_step_registry_5 import WorkflowStepRegistry5
from runtime5.logging_5 import log5
from runtime5.health_monitor_5 import HealthMonitor5
from runtime5.error_handler_5 import ErrorHandler5

# ENVOY steps
from runtime5.envoy_step_execute_5 import EnvoyStepExecute5
from runtime5.envoy_step_fetch_5 import EnvoyStepFetch5

# SYSTEM ACTION step
from runtime5.workflow_step_system_action_5 import WorkflowStepSystemAction5


class WorkflowEngine5:
    """
    Stabilizovaná verzia Workflow Engine 5.x
    """

    def __init__(self, runtime):
        self.runtime = runtime
        self.quarantine = runtime.quarantine

        # ⭐ init_defaults musí dostať runtime
        self.registry = WorkflowStepRegistry5()
        self.registry.init_defaults(runtime)

        # ENVOY kroky
        self.registry.register("ENVOY_FETCH", EnvoyStepFetch5(self.runtime))
        self.registry.register("ENVOY_EXECUTE", EnvoyStepExecute5(self.runtime))

        # SYSTEM_ACTION sa zaregistruje neskôr
        self.system_action_registered = False

        log5("[WorkflowEngine5] Initialized Workflow Engine 5.x")

    # --------------------------------------------------------
    # INTERNAL: ensure SYSTEM_ACTION exists
    # --------------------------------------------------------
    def _ensure_system_action(self):
        if not self.system_action_registered and hasattr(self.runtime, "system_agent"):
            self.registry.register("SYSTEM_ACTION", WorkflowStepSystemAction5(self.runtime))
            self.system_action_registered = True
            log5("[WorkflowEngine5] SYSTEM_ACTION registered")

    # --------------------------------------------------------
    # EXECUTION
    # --------------------------------------------------------
    def execute(self, reasoning_output: dict):
        log5("[WorkflowEngine5] Executing workflow step...")

        # ensure SYSTEM_ACTION exists
        self._ensure_system_action()

        def _exec():

            # --------------------------------------------------------
            # 🔥 WORKFLOW FALLBACK (NOVÉ)
            # --------------------------------------------------------
            if getattr(self.runtime, "self_repair", None) and self.runtime.self_repair.degraded:
                log5("[WorkflowEngine5] Runtime is degraded → forcing SAFE_ROUTE")
                return {
                    "action": "SAFE_ROUTE",
                    "output": None,
                    "notes": "Workflow forced into SAFE_ROUTE due to degraded state.",
                    "degraded": True
                }

            if not isinstance(reasoning_output, dict):
                return {
                    "action": None,
                    "output": None,
                    "error": "Invalid reasoning_output (not a dict).",
                    "degraded": HealthMonitor5.is_degraded()
                }

            route = reasoning_output.get("route")
            mode = reasoning_output.get("mode")

            # --------------------------------------------------------
            # NATIVE KG ROUTE (FINAL)
            # --------------------------------------------------------
            if route == "KG":
                operation = reasoning_output.get("operation")
                entity = reasoning_output.get("entity")
                args = reasoning_output.get("args", {})

                log5(f"[WorkflowEngine5] KG route → operation={operation}, entity={entity!r}")

                if operation in ("kg.neighbors", "kg.query"):
                    result = self.runtime.kg_query.get_related_entities(entity)

                elif operation == "kg.add_fact":
                    value = args.get("value", "")
                    result = self.runtime.kg.add_fact(entity, value)

                elif operation == "kg.add_relation":
                    relation = args.get("relation", "")
                    target = args.get("target", "")
                    result = self.runtime.kg.add_relation(entity, relation, target)

                elif operation == "kg.path":
                    target = args.get("target", "")
                    result = self.runtime.kg_query.shortest_path(entity, target)

                else:
                    result = {"error": f"Unknown KG operation: {operation}"}

                HealthMonitor5.record_success()
                return {
                    "action": "KG",
                    "output": result,
                    "degraded": HealthMonitor5.is_degraded()
                }

            # KG reasoning (legacy)
            if route == "KG_REASONING":
                action = "RETURN_CONTEXT"

            # KG relations → SystemAgent
            elif route in ("KG_RELATE", "KG_RELATIONS"):
                action = "SYSTEM_ACTION"

            # ENVOY pipeline
            elif route == "ENVOY":
                url = reasoning_output.get("url", "")

                if mode == "LEVEL1":
                    decision = self.runtime.permission_layer.policy_engine.evaluate(url)
                    log5(f"[WorkflowEngine5] Permission decision: {decision}")

                    if isinstance(decision, dict):
                        decision_type = decision.get("decision") or decision.get("effect")
                    else:
                        decision_type = None

                    if decision_type in ("allow", "ALLOW"):
                        self.runtime.system_agent.envoy_approve(url)
                        return {
                            "action": "ENVOY_LEVEL1",
                            "status": "approved",
                            "notes": "URL approved automatically.",
                            "degraded": HealthMonitor5.is_degraded()
                        }

                    if decision_type in ("manual", "MANUAL"):
                        self.runtime.system_agent.envoy_pending_add(url)
                        return {
                            "action": "ENVOY_LEVEL1",
                            "status": "pending",
                            "notes": "URL requires manual approval.",
                            "degraded": HealthMonitor5.is_degraded()
                        }

                    if decision_type in ("deny", "DENY"):
                        self.runtime.system_agent.envoy_reject(url)
                        return {
                            "action": "ENVOY_LEVEL1",
                            "status": "denied",
                            "notes": "URL denied by policy.",
                            "degraded": HealthMonitor5.is_degraded()
                        }

                if mode == "FETCH":
                    action = "ENVOY_FETCH"
                elif mode == "EXECUTE":
                    action = "ENVOY_EXECUTE"
                else:
                    action = "ENVOY_FETCH"

            # SYSTEM AGENT (generic)
            elif route == "SYSTEM_AGENT":
                action = "SYSTEM_ACTION"

            # ⭐ SYSTEM ACTION (explicit route)
            elif route == "SYSTEM_ACTION":
                action = "SYSTEM_ACTION"

            # COMPARE ROUTE
            elif route == "COMPARE":
                action = "COMPARE"

            # ⭐ KG-LIGHT (NEW)
            elif route == "KG_LIGHT":
                action = "KG_LIGHT"

            # DEFAULT
            else:
                action = "WORKFLOW_CONTINUE"

            log5(f"[WorkflowEngine5] Selected action: {action}")

            step = self.registry.get_step(action)
            if not step:
                return {
                    "action": action,
                    "output": None,
                    "error": f"Unknown workflow step: {action}",
                    "degraded": HealthMonitor5.is_degraded()
                }

            output = step.execute(reasoning_output)
            log5(f"[WorkflowEngine5] Step output: {output}")

            if action == "ENVOY_FETCH":
                HealthMonitor5.record_success()
                return {
                    "action": action,
                    "output": output,
                    "notes": "ENVOY_FETCH completed (minimal 5.4).",
                    "degraded": HealthMonitor5.is_degraded()
                }

            HealthMonitor5.record_success()

            return {
                "action": action,
                "output": output,
                "degraded": HealthMonitor5.is_degraded()
            }

        return ErrorHandler5.safe_execute(
            _exec,
            context={"reasoning_output": reasoning_output},
            fallback={
                "action": None,
                "output": None,
                "error": "WorkflowEngine5 failed.",
                "degraded": HealthMonitor5.is_degraded()
            }
        )
