import logging

logger = logging.getLogger("PermissionMatrix5_x")

class PermissionMatrix5_x:
    def __init__(self):
        self.matrix = {
            "OWNER": {
                "os_action": "ALLOW",
                "envoy_fetch": "ALLOW",
                "kg_write": "ALLOW",
                "workflow": "ALLOW",
                "vault_access": "ALLOW",
                "runtime_input": "ALLOW",

                # ⭐ KG OPERÁCIE
                "kg.neighbors": "ALLOW",
                "kg.query": "ALLOW",
                "kg.add_fact": "ALLOW",
                "kg.add_relation": "ALLOW",
            },

            "FAMILY": {
                "os_action": "LIMITED",
                "envoy_fetch": "LIMITED",
                "kg_write": "ALLOW",
                "workflow": "LIMITED",
                "vault_access": "READ",
                "runtime_input": "ALLOW",

                # ⭐ KG OPERÁCIE
                "kg.neighbors": "ALLOW",
                "kg.query": "ALLOW",
                "kg.add_fact": "LIMITED",
                "kg.add_relation": "LIMITED",
            },

            "STRANGER": {
                "os_action": "DENY",
                "envoy_fetch": "DENY",
                "kg_write": "DENY",
                "workflow": "DENY",
                "vault_access": "DENY",
                "runtime_input": "DENY",

                # ⭐ KG OPERÁCIE
                "kg.neighbors": "DENY",
                "kg.query": "DENY",
                "kg.add_fact": "DENY",
                "kg.add_relation": "DENY",
            }
        }

        logger.info("[PermissionMatrix5.x] Loaded permission rules")

    def check(self, identity: str, action: str) -> str:
        if identity not in self.matrix:
            logger.warning(f"[PermissionMatrix5.x] Unknown identity: {identity}")
            return "DENY"

        rules = self.matrix[identity]

        if action not in rules:
            logger.warning(f"[PermissionMatrix5.x] Unknown action: {action}")
            return "DENY"

        decision = rules[action]
        logger.debug(f"[PermissionMatrix5_x] {identity} → {action} = {decision}")
        return decision
