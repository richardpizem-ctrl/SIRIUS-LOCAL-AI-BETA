from runtime5.logging_5 import log5
from runtime5.compare_engine_5 import CompareEngine5


class WorkflowCompareStep5:
    """
    Workflow step for COMPARE intent.
    """

    name = "COMPARE"

    def __init__(self):
        self.engine = CompareEngine5()

    def execute(self, payload):
        intent = payload.get("intent")
        entity = payload.get("entity")
        args = payload.get("args", {})

        log5(f"[WorkflowCompareStep5] Executing COMPARE for entity={entity}")

        result = self.engine.compare(entity, args)

        return {
            "status": "ok",
            "result": result,
            "notes": "Compare step executed."
        }
