import logging
from runtime5.envoy.envoy_router_5 import EnvoyRouter5

logger = logging.getLogger("AgentKGBridge5")

class AgentKGBridge5:
    """
    AGENT → ENVOY → KG most pre Runtime 5.x
    AGENT nikdy nevolá KG priamo.
    Všetko ide cez ENVOY router.
    """

    def __init__(self, config_path: str):
        self.router = EnvoyRouter5(config_path)
        logger.info("[AgentKGBridge5] Initialized")

    # -----------------------------
    # KG WRITE
    # -----------------------------
    def add_fact(self, identity: str, subject: str, value: str):
        """
        subject = názov entity (napr. 'sky')
        value   = hodnota faktu (napr. 'blue')
        fact    = názov faktu = subject (jednoduchý model 5.x)
        """
        payload = {
            "subject": subject,   # <-- TOTO JE DÔLEŽITÉ
            "fact": subject,      # jednoduchý model: fact = subject
            "value": value,
            "channel": "LOCAL",
            "source": "AGENT",
            "risk": "LOW"
        }

        return self.router.route("kg.add_fact", identity, payload)

    def add_relation(self, identity: str, subject: str, relation: str, obj: str):
        payload = {
            "subject": subject,
            "relation": relation,
            "object": obj,
            "channel": "LOCAL",
            "source": "AGENT",
            "risk": "LOW"
        }

        return self.router.route("kg.add_relation", identity, payload)

    # -----------------------------
    # KG READ
    # -----------------------------
    def query(self, identity: str, query: dict):
        payload = {
            "query": query,
            "channel": "LOCAL",
            "source": "AGENT",
            "risk": "LOW"
        }

        return self.router.route("kg.query", identity, payload)
